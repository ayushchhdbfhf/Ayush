from highrise.__main__ import *
import time
import traceback
ik = "68e619bb2d5857122119839f"
bot_configs = [
        #("riggedfork6", "BlackjackBot", "695de40259e694ba662c7921", "4904ebbbd729c95e4183441f6fbe902d4260a3bafe6c6c53985f5bd82c273703"),
        #("riggedfork5", "BlackjackBot", "693e3fcb0f39fe1684e8ca02", "0c2349e19ba5672f7bf24775ed57096c4c965a7d5a0f1d0a8b818040357fd7e8"),
        #("riggedfork4", "BlackjackBot", "690a9614bef714e444d2e791", "0d36c294f51177907fdedf8fbfd152ff1cf7cf4324eb6eb24e2315070e6971a4"),
        #("riggedfork3", "BlackjackBot", "695e4389cc0860be27e2464f", "993700be20be494abfb1d6bfa83204fa9a11b75a709621f07699837b62dbf93b"),
        #("riggedfork", "BlackjackBot", "694c2469962c6ae54bb24824", "1719ff4a184e217207168bde0408fcabe7558e67269f8563f876490a23261fdc"),

        #("riggedfork2", "BlackjackBot", "67e4b65e1da4464edd20562f", "e8614e8736afa615f1358c256c27428c95e0454a4860b02baeee1464caf97a5e"),

        #("party", "PARTY", "68a97f4a8e17a1f305ad9c59", "26ed75daf9bb143cd68bb65ae2901d60e2c52a010b01ab2ae3e453c57e89c8c5"),
        ("rparty", "PARTY", "67877ec90429d35f9ab40c08", "1719ff4a184e217207168bde0408fcabe7558e67269f8563f876490a23261fdc"),

        #("party2", "PARTY", "675da438913fd1e368fcff8a", "9f73f179fa5904ab872a1f83ab3010d7bebd537c7f0ca349608e83e052c89d2c"),

        #("party3", "PARTY", "694c2469962c6ae54bb24824", "818b401549eeee30b9484f21a8927598c4c70c39b86d34a3545466c94317e314"),
        #("party4", "PARTY", "6876739b7d0e3a25c497db89", "cd77cb94fd74c5b38ebae4b3f1dcfe8722bf0debf17983b0fffdf210456a9b6a"),
    #("party5", "PARTY", "67e4b65e1da4464edd20562f", "d78c15fdde46534e2e1c9b12301d7732f4b7bd67c6ca74516b80739bdc621956"),
    #("party6", "PARTY", "6936281d1633bf6e3530b75b", "e9cbdd063b02175f261fc7e615163ecdfd23a238f795d81863d801d1cfd9f96e"),
    #("party7", "PARTY", "6964111b89069cedf10a5ff4", "5c43b8ced77be1f25402230eaa85d5c87d8528adc0d5f99605a7df40e1f2b600"),
    #("party8", "PARTY", "695e4389cc0860be27e2464f", "5541ac373e64c1d2450738e177c3c59dd2705d9a62e5e1030e4c174afa2cf0ef"),
    #("party9", "PARTY", "68a014c57b8e41afcbf01093", "7ddfd055b685bfba84eedbaad8e4498a6d3d4768aff57a0b63eef17f1a843481"),
    #("party10", "PARTY", "695e4389cc0860be27e2464f", "a893a351c29cbe4a711ec7a65b00fa2141945edd2d356f91e467214196729b10"),
    #("party11", "PARTY", "6876f57a6d5ee37c44274e51", "a2acfaf88bc30933fc696f12359df9b153c5af2ec009d209d1572d36a0548edc"),
    #("party12", "PARTY", "695de40259e694ba662c7921", "5fb007bd6766c6ea435465c97f6e78933e189376d906abc9281885f15addfa93"),
    #("party13", "PARTY", "695e4389cc0860be27e2464f", "5c6ba7301641a11e30c12d59d3a17107b28830b2192b1a3194cf37abdb68bdd9")

    ]

bots = []
jacks = 0
for bot_file_name, bot_class_name, room_id, bot_token in bot_configs:
    if bot_file_name.startswith("rigged"):
        jacks += 1
    bot = BotDefinition(getattr(import_module(bot_file_name), bot_class_name)(), room_id, bot_token)
    bots.append(bot)
while True:
    try:
        print("TOTAL JACKS: ", jacks)
        arun(main(bots))
    except Exception as e:
        print(f"An exception occurred: {e}")
        traceback.print_exc()
        time.sleep(10)