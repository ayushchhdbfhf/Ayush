import random
import asyncio
import requests
import os
import logging
import sys
from datetime import datetime, timedelta
from highrise.models import User, SessionMetadata, Position
from highrise import BaseBot, CurrencyItem, SessionMetadata, User
from casinodb import wallet, casinodata as casino, bot_location, owners, urls, ids
import random
import logging
from highrise import BaseBot, __main__
from highrise import SessionMetadata
from typing import Dict, List, Tuple, Optional, Any
import traceback

logger = logging.getLogger(__name__)

class BotDefinition:
    def __init__(self, bot: BaseBot, room_id: str, api_token: str):
        self.bot = bot
        self.room_id = room_id
        self.api_token = api_token

class Card:
    """Represents a playing card with a suit and value."""
    SUITS = ["♥", "♦", "♣", "♠"]
    VALUES = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
    
    def __init__(self, suit: str, value: str):
        self.suit = suit
        self.value = value
    
    def __str__(self) -> str:
        return f"{self.value}{self.suit}"
    
    def get_blackjack_value(self) -> int:
        """Get the card's value in blackjack."""
        if self.value in ["J", "Q", "K"]:
            return 10
        elif self.value == "A":
            return 11  # Ace is handled specially in hand evaluation
        else:
            return int(self.value)

class Deck:
    """Represents a deck of cards with controlled odds."""
    def __init__(self):
        self.cards = []
        self.reset()
        self.card_index = 0
        self.shuffle_point = 0
    
    def reset(self):
        """Resets and shuffles the deck with proper randomization."""
        self.cards = [Card(suit, value) for suit in Card.SUITS for value in Card.VALUES]
        # Proper shuffle with multiple passes
        for _ in range(7):
            random.shuffle(self.cards)
        self.card_index = 0
        self.shuffle_point = random.randint(20, 30)  # Shuffle when 20-30 cards remain
    
    def deal(self) -> Card:
        """Deal a single card from the deck with proper deck management."""
        if self.card_index >= len(self.cards) or (len(self.cards) - self.card_index) <= self.shuffle_point:
            self.reset()
        
        card = self.cards[self.card_index]
        self.card_index += 1
        return card
    
    def peek_next_cards(self, count: int = 3) -> List[Card]:
        """Peek at upcoming cards for dealer advantage (not shown to players)."""
        end_index = min(self.card_index + count, len(self.cards))
        return self.cards[self.card_index:end_index]

class BlackjackBot(BaseBot):
    LOCK = asyncio.Lock()
    def __init__(self):
        super().__init__()
        self.username = None
        self.ownername = None
        self.bot_id = None
        self.update_task = None
        self.drawing = False
        self.deck = Deck()
        self.current_table: Dict[str, Any] = {
            "active": False,
            "players": {},
            "bet_timer": None,
            "game_timer": None,
            "dealer_hand": [],
            "dealer_value": 0,
            "dealer_blackjack": False
        }
        self.logger = logger
        
        # Initialize bonuses in casinodata if not exists
        if 'bonuses' not in casino:
            casino['bonuses'] = {}
            
    async def run_bot(self, room_id, token):
        definitions = [BotDefinition(self, room_id, token)]
        await __main__.main(definitions)
        
    async def restart_bot(self, user):
        if not user.username in owners:
            return
        await asyncio.sleep(5)
        os.execv(sys.executable, [sys.executable, 'run.py'] + sys.argv[1:])
    
    async def on_user_join(self, user: User, pos: Position) -> None:
        try:
            await self.highrise.send_whisper(user.id, "♣️ Welcome to the Blackjack Table! ♣️\n\n"
                                             "Purchase [Chips] by tipping the bot, and place your bets with !bet to begin.\n\n"
                                             "Table minimum: 10g\n"
                                             "Table maximum: 10,000g")
            casino['active_players'] += 1
            if user.username not in wallet:
                wallet[user.username] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
                casino['total_players'] += 1
        except: pass
    
    async def on_user_leave(self, user: User) -> None:
        pass

    async def on_message(self, user_id: str, conversation_id: str, is_new_conversation: bool) -> None:
        try:
            if user_id not in ids: 
                ids.append(user_id)
                await self.highrise.send_message(conversation_id, "Your acc is verified.")
        except: pass

    async def copy_outfit(self, user, message):
        try:
            if user.username not in owners:
                return
            target_username = message[6:].strip().lstrip('@')
            response = await self.webapi.get_users(username=target_username, limit=1)
                
            if not response.users:
                await self.highrise.send_whisper(user.id, f"User @{target_username} not found.")
                return
                
            target_user = response.users[0]
            outfit_response = await self.highrise.get_user_outfit(target_user.user_id)
                
            try:
                await self.highrise.set_outfit(outfit=outfit_response.outfit)
                await self.highrise.send_whisper(user.id, f"Successfully copied @{target_user.username}'s complete outfit!")
                return
            except Exception:
                successful_items = []
                failed_items = []
                    
                for item in outfit_response.outfit:
                    try:
                        await self.highrise.set_outfit(outfit=successful_items + [item])
                        successful_items.append(item)
                    except Exception:
                        failed_items.append(item.id.split('-')[-1])
                    
                if failed_items:
                    await self.highrise.send_whisper(user.id, 
                        f"Copied @{target_user.username}'s outfit but skipped {len(failed_items)} items: "
                        f"{', '.join(failed_items[:5])}{'...' if len(failed_items) > 5 else ''}")
                else:
                    await self.highrise.send_whisper(user.id, f"Successfully copied @{target_user.username}'s outfit piece by piece!")
            
        except Exception:
            await self.highrise.send_whisper(user.id, "Failed to copy outfit. Please try again.")

    async def update_players(self):
        try:
            while True:
                try:
                    room_users = (await self.highrise.get_room_users()).content
                    # Filter out self.user from the count
                    casino['active_players'] = len([user for user in room_users 
                                              if user[0].id != self.bot_id])
                    await asyncio.sleep(77)
                except: 
                    continue
        except:
            pass

    async def get_username(self, user_id):
        user_info = await self.webapi.get_user(user_id)
        return user_info.user.username
    
    async def on_start(self, session_metadata: SessionMetadata) -> None:
        try:
            self.username = await self.get_username(session_metadata.user_id)
            self.bot_id = session_metadata.user_id
            self.ownername = await self.get_username(session_metadata.room_info.owner_id)
            print(f"BOT {self.username} has started.")
            if self.ownername:
                if self.ownername not in owners:
                    owners.append(self.ownername)
            if self.update_task:
                self.update_task.cancel()
                await asyncio.sleep(1)
            self.update_task = asyncio.create_task(self.update_players())
            if bot_location:
                await self.highrise.teleport(session_metadata.user_id, Position(**bot_location))
            else:
                await self.highrise.teleport(session_metadata.user_id, Position(15.5, 0.25, 2.5, 'FrontRight'))
        except Exception as e:
            print("Error in on_start:", e)
    
    async def invite_all(self, user):
        if not user.username in owners:
            await self.highrise.send_whisper(user.id, "You cant use this command.")
            return
        if not urls.get('room', None):
            await self.highrise.send_whisper(user.id, "Please set the invite link first by !in <room invite link>")
        try:
            for user_id in ids:
                message_id = f"1_on_1:{user_id}:{self.bot_id}"
                try:
                    await self.highrise.send_message(
                message_id,
                message_type="invite",
                content="Join this room!", 
                room_id=urls.get('room', None))
                    await asyncio.sleep(0.5)
                except:
                    continue
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"error: {e}")
    
    async def set_bot(self, user):
        if not user.username in owners:
            return
        try:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                        bot_location["x"] = pos.x
                        bot_location["y"] = pos.y
                        bot_location["z"] = pos.z
                        bot_location["facing"] = pos.facing
                        await self.highrise.send_whisper(user.id, f"Bot location set to {bot_location}")
                        break
            await self.highrise.walk_to(Position(**bot_location))       
        except Exception as e:
            print("Set bot:", e)
    
    async def bot_wallet(self, user):
        if user.username in owners:
            wallet = await self.highrise.get_wallet()
            for item in wallet.content:
                if item.type == "gold":
                    gold = item.amount
                    await self.highrise.send_whisper(user.id, f"Sir, My current balance is {gold} gold!")
                    return
            await self.highrise.send_whisper(f"Hello, {user.username}! I don't have any gold.")
        else:
            await self.highrise.send_whisper(user.id, "You don't have access to this command")
    
    async def on_chat(self, user: User, message: str) -> None:
        if message.startswith("!users") and user.username in owners:
            try:
                users = len(ids)
                await self.highrise.send_whisper(user.id, f"There are total {users}. Type !invite to invite them.")
            except:
                pass

        if message.startswith("!addall") and user.username in owners:
            try:
                room_users = (await self.highrise.get_room_users()).content
                users_only = [
                u for u, _ in room_users
                if u.id != user.id and u.id != self.bot_id and u.id not in ids
            ]
                fee = 2
                total_cost = (fee) * len(users_only)
                bot_balance = (await self.highrise.get_wallet()).content[0].amount
                if bot_balance < total_cost:
                    await self.highrise.send_whisper(user.id, f"Not enough gold. Need {total_cost}g (incl. fees).")
                    return

                for recipient in users_only:
                    await self.highrise.tip_user(recipient.id, 'gold_bar_1')
                    ids.append(recipient.id)
                message = f"Added {len(users_only)} new users!" if len(users_only) > 0 else "No unique player to be added."
                await self.highrise.send_whisper(user.id, message)
            except:
                pass
        
        if message.startswith("!in "):
            if user.username != self.ownername:
                if user.username != "HAR1ZZ":
                    return
            try:
                url = message.split("!in ")[1]
                room_id = url.split("room?id=")[1].split("&")[0]
                urls['room'] = room_id
                await self.highrise.send_whisper(user.id, f"invite for room id set to {url}")
            except:
                pass

        if message.startswith("!invite"):
            try:
                await self.invite_all(user)
            except Exception as e:
                await self.highrise.send_whisper(user.id, f"Issue: {e}")
        
        if message.startswith("!rem ") and (user.username in owners or user.username == self.ownername):
            try:
                remvip = message.split(" ", 1)[1]
                rem = remvip.replace("@", "")
                if rem in owners:
                    owners.remove(rem)
                    await self.highrise.chat(f"{remvip} removed from ownerz.")
                else:
                    await self.highrise.send_whisper(user.id, f"{rem} not in ownerz.")
            except:
                pass

        if message.startswith("!add ") and (user.username in owners or user.username == self.ownername):
            try:
                vip = message.split(" ", 1)[1]
                allowed = vip.replace("@", "")
                if allowed not in owners:
                    owners.append(allowed)
                    await self.highrise.chat(f"{vip} added to ownerz.")
                else:
                    await self.highrise.chat(f"{vip} already in ownerz.")
            except:
                await self.highrise.send_whisper(user.id, "Nuh uh")
        cmd = message.lower().split()[0] if message else ""
        try:
            if cmd in ("!stay", "!stand", "!s", "!h", "!hit", "!d", "!double", "!bet", "!b") and self.drawing:
                await self.highrise.send_whisper(user.id, "Please wait...")
                return
            if cmd.startswith("!copy"):
                await self.copy_outfit(user, message)
            if cmd == "!bank":
                await self.bot_wallet(user)
            if cmd == "!restart":
                await self.restart_bot(user)
            if cmd == "/set":
                await self.set_bot(user)
            if cmd == "!help":
                await self.show_help(user)
            if cmd == "!info":
                await self.show_info(user)
            elif cmd.startswith("!be") and len(message.split()) > 1:
                await self.handle_bet_command(user, message.split()[1:])
            elif cmd.startswith("!hi"):
                await self.handle_hit_command(user)
            elif cmd.startswith("!sta"):
                await self.handle_stand_command(user)
            elif cmd.startswith("!do"):
                await self.handle_double_command(user)
            elif cmd == "!bal":
                await self.show_balance(user)
            elif cmd == "!cash" and len(message.split()) > 1:
                await self.handle_withdraw(user, message)
            elif cmd == "!leaderboard":
                await self.show_leaderboard()
            elif cmd.startswith("!winner"):
                await self.show_recent_winners(user)
            elif cmd == "!bonus":
                await self.handle_bonus_command(user)
            elif cmd == "!rm":
                await self.handle_remaining_bonus_command(user)
            elif cmd.startswith("!give"):
                await self.handle_give_command(user, message)
        except Exception as e:
            print(f"Command error: {e}")
            await self.highrise.send_whisper(user.id, "Error processing command")

    async def on_tip(self, sender: User, receiver: User, tip: CurrencyItem) -> None:
        if receiver.id != self.bot_id:
            return
        if sender.id not in ids: ids.append(sender.id)
        username = sender.username
        if username not in wallet:
            wallet[username] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
            casino['total_players'] += 1
            
        chips = tip.amount
        wallet[username]["chips"] += chips
        try:
            await self.highrise.send_whisper(sender.id, f"You received [{chips} Balance]")
        except:pass

    def has_active_game(self, user_id: str) -> bool:
        """Check if a user has an active game."""
        return user_id in self.current_table["players"] and self.current_table["players"][user_id]["status"] != "complete"
    
    def calculate_hand_value(self, hand: List[Card], hide: bool = False) -> Tuple[int, bool]:
        """Calculate hand value following classic blackjack rules."""
        value = 0
        num_aces = 0

    # If hide is True and hand has more than one card, only consider the first card
        cards_to_evaluate = hand[:1] if hide and len(hand) > 1 else hand

        for card in cards_to_evaluate:
            val = card.get_blackjack_value()
            if val == 11:
                num_aces += 1
            value += val

    # Adjust for aces if over 21
        while value > 21 and num_aces:
            value -= 10
            num_aces -= 1

    # True blackjack only if exactly 21 with 2 cards (A + 10-value card)
        is_blackjack = (
            not hide and
        value == 21 and len(hand) == 2 and
        ((hand[0].value == 'A' and hand[1].value in ['10', 'J', 'Q', 'K']) or
         (hand[1].value == 'A' and hand[0].value in ['10', 'J', 'Q', 'K']))
    )

        return value, is_blackjack


    def format_hand(self, hand: List[Card], hide_second_card: bool = False) -> str:
        """Format a hand as a string for display."""
        if hide_second_card and len(hand) > 1:
            return f"[{hand[0]}]"
        return " ".join(f"[{str(card)}]" for card in hand)
    
    def get_dealer_decision(self, dealer_hand: List[Card], peek_cards: List[Card]) -> str:
        """Dealer decision with deck-based advantage."""
        dealer_value, _ = self.calculate_hand_value(dealer_hand)
        
        # Classic blackjack rules: dealer stands on 17, hits on 16 or less
        if dealer_value >= 17:
            return "stand"
        elif dealer_value <= 16:
            return "hit"
        
        return "hit"  # Default to hit

    def determine_winner_classic(self, player_hand: List[Card], dealer_hand: List[Card], has_bonus: bool = False) -> str:
        """Determine winner following classic blackjack rules with deck-based odds."""
        player_value, player_blackjack = self.calculate_hand_value(player_hand)
        dealer_value, dealer_blackjack = self.calculate_hand_value(dealer_hand)
        
        # Blackjack cases (highest priority)
        if player_blackjack and not dealer_blackjack:
            return "player_blackjack"
        elif dealer_blackjack and not player_blackjack:
            return "dealer_blackjack"
        elif player_blackjack and dealer_blackjack:
            return "push"
        
        # Bust cases
        if player_value > 21:
            return "dealer"
        elif dealer_value > 21:
            return "player"
        
        # Normal comparison
        if player_value > dealer_value:
            return "player"
        elif dealer_value > player_value:
            return "dealer"
        else:
            return "push"

    async def handle_bet_command(self, user: User, args: List[str]) -> None:
        """Handle the !bet command with table-based betting system."""
        if self.drawing: 
            await self.highrise.send_whisper(user.id,"Please wait...")
            return
        if self.current_table['active']:
            if not self.current_table['bet_timer']:
                await self.highrise.send_whisper(user.id,"Please wait...")
                return
        username = user.username
        user_id = user.id
        
        if not args:
            await self.highrise.send_whisper(user_id, "Please specify a bet amount between 10 and 10000 chips.")
            return

        try:
            bet_amount = int(args[0])
        except ValueError:
            await self.highrise.send_whisper(user_id, "Bet amount must be an integer number.")
            return

        if bet_amount < 10 or bet_amount > 10000:
            await self.highrise.send_whisper(user_id, "Bet amount must be between 10 and 10000 chips.")
            return
        
        if username not in wallet:
            wallet[username] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
            casino['total_players'] += 1

        # Check if player is already on the table (BET INCREASE)
        if user_id in self.current_table["players"]:
            if not self.current_table["bet_timer"]: return
            player_data = self.current_table["players"][user_id]
            current_bet = player_data["bet_amount"]
            
            # Check if trying to decrease bet (not allowed)
            if bet_amount < 0:
                await self.highrise.send_whisper(user_id, f"You can only increase your bet.")
                return
            
            # Check if player has sufficient balance for increased bet (unless owner)
            increase_amount = bet_amount
            if username not in owners:
                if wallet[username]["chips"] <= increase_amount:
                    await self.highrise.send_whisper(user_id, f"Insufficient chips.")
                    return
            
            # Increase the bet amount
            if username not in owners:
                wallet[username]["chips"] -= increase_amount
            wallet[username]["total_wagered"] += increase_amount
            casino['total_bets'] += increase_amount
            
            player_data["bet_amount"] += bet_amount
            indicator = self.get_indicator(username)
            await self.highrise.chat(f"{indicator}@{username} increased bet to [{player_data['bet_amount']} chips]")
            return

        # NEW PLAYER JOINING - Check if table is full
        if len(self.current_table["players"]) >= 6:
            await self.highrise.send_whisper(user_id, "Table is full! Please wait for the next game.")
            return

        # Check balance for new player (unless owner)
        if username not in owners and wallet[username]["chips"] < bet_amount:
            await self.highrise.chat(f"@{username}, you don't have enough chips.")
            await self.highrise.send_whisper(user_id, f"Your balance: {wallet[username]['chips']} chips")
            return

        # Deduct bet immediately (only for non-owners)
        if username not in owners:
            wallet[username]["chips"] -= bet_amount
            wallet[username]["total_wagered"] += bet_amount
            casino['total_bets'] += bet_amount

        # Add player to the table
        self.current_table["players"][user_id] = {
            "username": username,
            "bet_amount": bet_amount,
            "player_hand": [],
            "status": "waiting", # waiting, active, busted, stood, complete
            "doubled": False,
            "has_bonus": self.check_active_bonus(username)
        }

        # If table is NOT active, start a new game
        if not self.current_table["active"]:
            # Start a new table
            self.current_table["active"] = True
            self.current_table["dealer_hand"] = [self.deck.deal(), self.deck.deal()]
            
            indicator = self.get_indicator(username)
            await self.highrise.chat(f"{indicator}@{username} joined with [{bet_amount} chips]")
            await asyncio.sleep(1.5)
            await self.highrise.chat(f"♠️ Game starting.. [⏳ 15 seconds]")
            self.current_table["bet_timer"] = asyncio.create_task(self.start_betting_timer())
        else:
            # Table is already active, just add the player
            indicator = self.get_indicator(username)
            await self.highrise.chat(f"{indicator}@{username} joined with [{bet_amount} chips]")
            
    async def start_betting_timer(self):
        await asyncio.sleep(15)
        self.drawing = True
        await self.highrise.chat("♠️ Drawing cards...")
        self.current_table["bet_timer"] = None
        try:
            await self.start_game_for_table()
        except:
            traceback.print_exc()

    async def start_game_for_table(self):
        if not self.current_table["players"]:
            await self.highrise.chat("No players joined the table. Table disbanded.")
            self.reset_table()
            return

        casino['games_played'] += 1

        # Deal initial cards to all players
        dealer_hand = self.current_table["dealer_hand"]
        value, _ = self.calculate_hand_value(dealer_hand)
        hide = True if value < 21 else False
        dealer_value, dealer_blackjack = self.calculate_hand_value(dealer_hand, hide=hide)
        self.current_table["dealer_value"] = dealer_value
        self.current_table["dealer_blackjack"] = dealer_blackjack
        
        # Check if ALL players have immediate blackjack outcomes
        all_players_immediate = True
        for user_id, player_data in self.current_table["players"].items():
            player_data["player_hand"] = [self.deck.deal(), self.deck.deal()]
            player_value, player_blackjack = self.calculate_hand_value(player_data["player_hand"])

            await self.highrise.chat(
                f"@{player_data['username']} {self.format_hand(player_data['player_hand'])} = [{player_value}]"
            )

            # Check for immediate blackjack
            if player_blackjack or dealer_blackjack:
                player_data["status"] = "waiting_resolution"
            else:
                player_data["status"] = "active"
                all_players_immediate = False
            await asyncio.sleep(1.5)

        if not hide:
            await self.highrise.chat(f"[🎲] Dealer: {self.format_hand(dealer_hand, hide_second_card=hide)} = [{dealer_value}]")
        message = "[🃏] Dealer has Blackjack!" if not hide else f"[🎲] Dealer: {self.format_hand(dealer_hand, hide_second_card=hide)} = [{dealer_value}]"
        await self.highrise.chat(message)
        
        # If all players have immediate outcomes, resolve immediately
        if all_players_immediate:
            for user_id, player_data in self.current_table["players"].items():
                player_value, player_blackjack = self.calculate_hand_value(player_data["player_hand"])
                asyncio.create_task(self.resolve_immediate_blackjack(user_id, player_data, dealer_hand, dealer_value, player_blackjack, dealer_blackjack))
                if len(self.current_table['players']) == 1:
                    self.drawing = False
        else:
            await self.highrise.chat(f"♠️ Type !hit, !stand, !double [⏳ 45 seconds]")
            self.drawing = False
            await asyncio.sleep(1.5)
            # Start game timer for player actions
            self.current_table["game_timer"] = asyncio.create_task(self.start_game_timer())

    async def start_game_timer(self):
        await asyncio.sleep(45)
        await self.highrise.chat("[🎲] Dealer's turn.")
        self.current_table["game_timer"] = None
        await self.dealer_play()

    async def resolve_immediate_blackjack(self, user_id, player_data, dealer_hand, dealer_value, player_blackjack, dealer_blackjack):
        username = player_data["username"]
        bet_amount = player_data["bet_amount"]
        dealer_show = self.format_hand(dealer_hand)
        
        if self.drawing:
            await asyncio.sleep(3.5)
        
        if player_blackjack and not dealer_blackjack:
            winnings = int(bet_amount * 2.5)
            wallet[username]["chips"] += winnings
            wallet[username]["wins"] += 1
            wallet[username]["total_won"] += winnings
            casino['total_wins'] += winnings

            if len(casino['recent_winners']) >= 10:
                casino['recent_winners'].pop(0)
            casino['recent_winners'].append((username, winnings, datetime.now().isoformat()))

            await self.highrise.chat(
                f"[🃏] @{username} has Blackjack!"
            )
            player_data["status"] = "stood"
            
        elif dealer_blackjack and not player_blackjack:
            wallet[username]["losses"] += 1
            await self.highrise.chat(
                f"@{username} loses to BlackJack."
            )
            player_data["status"] = "stood"
            
        else:  # Both have blackjack (push)
            wallet[username]["chips"] += bet_amount
            await self.highrise.chat(f"[🃏] @{username} has Blackjack!")
            await asyncio.sleep(1)
            await self.highrise.chat(
                f"@{username} gets back {bet_amount} chips."
            )
            player_data["status"] = "stood"
        
        # Check if ALL players are done (not just this one)
        all_players_done = True
        for uid, pdata in self.current_table["players"].items():
            if pdata["status"] not in ["complete", "busted", "stood", "black_jack"]:
                all_players_done = False
                break
        
        if all_players_done:
            # Cancel the game timer since the game is already over
            if self.current_table["game_timer"]:
                try:
                    await asyncio.sleep(1)
                    self.current_table["game_timer"].cancel()
                    self.current_table["game_timer"] = None
                except: pass
            asyncio.create_task(self.resolve_all_games())
        
    async def handle_hit_command(self, user: User) -> None:
        """Handle the !hit command to take another card."""
        username = user.username
        user_id = user.id

        if user_id not in self.current_table["players"] or self.current_table["players"][user_id]["status"] != "active":
            message = "Please wait.." if len(self.current_table["players"]) >=1 else "You're not in game, Type !bet 10"
            await self.highrise.send_whisper(user_id, message)
            return

        player_data = self.current_table["players"][user_id]

        if player_data["doubled"]:
            await self.highrise.send_whisper(user_id, "You cannot hit after doubling down.")
            return

        # Apply bonus effect: reduced bust probability
        has_bonus = player_data["has_bonus"]
        current_hand_value, _ = self.calculate_hand_value(player_data["player_hand"])
        
        # Deal a card with bonus consideration
        new_card = self.deck.deal()
        
        # Bonus effect: if player has bonus and is close to busting, slightly favor lower cards
        if has_bonus and current_hand_value >= 12:
            card_value = new_card.get_blackjack_value()
            # Small chance to get a more favorable card when bonus is active
            if card_value > 6 and random.random() < 0.2:  # 30% chance to avoid high cards
                # Try to get a lower card from upcoming cards
                upcoming = self.deck.peek_next_cards(5)
                for card in upcoming:
                    if card.get_blackjack_value() <= 6:
                        new_card = card
                        break

        player_data["player_hand"].append(new_card)
        player_value, _ = self.calculate_hand_value(player_data["player_hand"])

        # Display updated hand
        player_show = self.format_hand(player_data["player_hand"])

        bonus_indicator = self.get_indicator(username)
        message = f"{bonus_indicator}@{username} | B | {player_show} = [{player_value}]" if player_value > 21 else f"{bonus_indicator}@{username} | {player_show} = [{player_value}]"
        if player_value == 21:
            message = f"{bonus_indicator}@{username} | S | {player_show} = [{player_value}]"
        await self.highrise.chat(
            message
        )
        if player_value > 21:
            player_data["status"] = "busted"
            wallet[username]["losses"] += 1
        elif player_value == 21:
            player_data["status"] = "stood"
        await asyncio.sleep(1.5)
        await self.check_all_players_done()

    async def handle_stand_command(self, user: User) -> None:
        """Handle the !stand command to stay."""
        username = user.username
        user_id = user.id

        if user_id not in self.current_table["players"] or self.current_table["players"][user_id]["status"] != "active":
            message = "Please wait.." if len(self.current_table["players"]) >=1 else "You're not in game, Type !bet 10"
            await self.highrise.send_whisper(user_id, message)
            return

        player_data = self.current_table["players"][user_id]
        player_data["status"] = "stood"
        bonus_indicator = self.get_indicator(username)
        await self.highrise.chat(f"{bonus_indicator}@{username} | S | {self.format_hand(player_data['player_hand'])} = [{self.calculate_hand_value(player_data['player_hand'])[0]}]")
        await self.check_all_players_done()

    async def handle_double_command(self, user: User) -> None:
        """Handle the !double command to double down."""
        username = user.username
        user_id = user.id

        if user_id not in self.current_table["players"] or self.current_table["players"][user_id]["status"] != "active":
            message = "Please wait.." if len(self.current_table["players"]) >=1 else "You're not in game, Type !bet 10"
            await self.highrise.send_whisper(user_id, message)
            return

        player_data = self.current_table["players"][user_id]
        bet_amount = player_data["bet_amount"]

        if len(player_data["player_hand"]) != 2:
            await self.highrise.send_whisper(user_id, "You can only double down on your first two cards.")
            return

        if wallet[username]["chips"] < bet_amount:
            if username not in owners:
                await self.highrise.send_whisper(user_id,"You don't have enough chips to double down.")
                await self.highrise.send_whisper(user_id, f"Your balance: {wallet[username]['chips']} chips")
                return

        if username not in owners:
            wallet[username]["chips"] -= bet_amount
        wallet[username]["total_wagered"] += bet_amount
        casino['total_bets'] += bet_amount

        player_data["bet_amount"] *= 2
        player_data["doubled"] = True

        # Deal one card and stand with bonus consideration
        has_bonus = player_data["has_bonus"]
        current_hand_value, _ = self.calculate_hand_value(player_data["player_hand"])
        
        new_card = self.deck.deal()
        
        # Bonus effect for double down
        if has_bonus and current_hand_value >= 9 and current_hand_value <= 11:
            card_value = new_card.get_blackjack_value()
            if card_value > 7 and random.random() < 0.25:  # 25% chance to avoid bad cards
                upcoming = self.deck.peek_next_cards(3)
                for card in upcoming:
                    if card.get_blackjack_value() <= 7:
                        new_card = card
                        break

        player_data["player_hand"].append(new_card)
        player_value, _ = self.calculate_hand_value(player_data["player_hand"])

        player_show = self.format_hand(player_data["player_hand"])
        bonus_indicator = self.get_indicator(username)
        message = f"{bonus_indicator}@{username} | S | {player_show} = [{player_value}]" if player_value <= 21 else f"{bonus_indicator}@{username} | B | {player_show} = [{player_value}]"
        await self.highrise.chat(
            message
        )

        if player_value > 21:
            player_data["status"] = "busted"
            wallet[username]["losses"] += 1
        else:
            player_data["status"] = "stood"
        await self.check_all_players_done()

    async def check_all_players_done(self):
        """Check if all players have completed their turns."""
        # Check if all active players are done (busted, stood, or complete)
        all_done = True
        for user_id, player_data in self.current_table["players"].items():
            if player_data["status"] == "active":
                all_done = False
                break
    
        if all_done:
            if self.current_table["game_timer"]:
                self.current_table["game_timer"].cancel()
            await self.dealer_play()

    async def dealer_play(self):
        dealer_hand = self.current_table["dealer_hand"]
        dealer_value, _ = self.calculate_hand_value(dealer_hand)
        while self.drawing: await asyncio.sleep(1.5)
        await self.highrise.chat(f"[🎲] Dealer: Hidden card revealed: {self.format_hand(dealer_hand).split()[1]}")
        await asyncio.sleep(1.5)
        await self.highrise.chat(f"[🎲] Dealer: {self.format_hand(dealer_hand)} = [{dealer_value}]")

        # Dealer follows classic blackjack rules with slight deck advantage
        while dealer_value < 17:
            await asyncio.sleep(1.5)
            
            # Peek at upcoming cards for slight dealer advantage
            peek_cards = self.deck.peek_next_cards(3)
            favorable_low = any(card.get_blackjack_value() <= 6 for card in peek_cards)
            favorable_high = any(card.get_blackjack_value() >= 10 for card in peek_cards)
            
            new_card = self.deck.deal()
            
            # Dealer advantage: slight bias based on upcoming cards
            if dealer_value == 16 and favorable_low:
                # More likely to hit if favorable low card is coming
                if random.random() < 0.8:  # 80% chance to take the risk
                    dealer_hand.append(new_card)
                else:
                    await self.highrise.chat(f"[🎲] Dealer stands with {dealer_value}")
                    break
            elif dealer_value == 16 and favorable_high:
                # More likely to stand if high card is coming
                if random.random() < 0.3:  # 30% chance to risk bust
                    dealer_hand.append(new_card)
                else:
                    await self.highrise.chat(f"[🎲] Dealer stands with [{dealer_value}]")
                    break
            else:
                # Standard dealer behavior
                dealer_hand.append(new_card)
            
            dealer_value, _ = self.calculate_hand_value(dealer_hand)
            message = f"[🎲] Dealer: | B | {self.format_hand(dealer_hand)} = [{dealer_value}]" if dealer_value > 21 else f"[🎲] Dealer: {self.format_hand(dealer_hand)} = [{dealer_value}]"
            await self.highrise.chat(message)

        self.current_table["dealer_value"] = dealer_value

        await self.resolve_all_games()

    async def resolve_all_games(self):
        dealer_hand = self.current_table["dealer_hand"]
        dealer_value = self.current_table["dealer_value"]

        for user_id, player_data in self.current_table["players"].items():
            # Only skip players who are already complete
            # "stood" players should be processed for final resolution
            if player_data["status"] == "complete":
                continue
                
            username = player_data["username"]
            player_hand = player_data["player_hand"]
            bet_amount = player_data["bet_amount"]
            has_bonus = player_data["has_bonus"]

            # For "stood" players from immediate blackjack, we need to handle them
            # but avoid double-paying (since they were already paid in resolve_immediate_blackjack)
            if player_data["status"] == "stood":
                # Check if this is an immediate blackjack case (already paid)
                player_value, player_blackjack = self.calculate_hand_value(player_hand)
                dealer_value, dealer_blackjack = self.calculate_hand_value(dealer_hand)
                
                if player_blackjack and not dealer_blackjack:
                    # Already paid in resolve_immediate_blackjack, just announce and mark complete
                    await self.highrise.chat(
                        f"{self.get_indicator(username)}@{username} Blackjack wins!")
                    for player_data in self.current_table["players"].values():
                        if player_data["username"] == username:
                            f = player_data["bet_amount"]
                            break
                    w =  int(f * 1.5) + f
                    await self.highrise.chat(f"{self.get_indicator(username)}@{username} received [{w} Balance]")
                    player_data["status"] = "complete"
                    continue
                elif dealer_blackjack and not player_blackjack:
                    # Already handled in resolve_immediate_blackjack, just mark complete
                    player_data["status"] = "complete"
                    continue
                elif player_blackjack and dealer_blackjack:
                    # Push already handled, just mark complete
                    player_data["status"] = "complete"
                    continue
            
            # Normal resolution for non-blackjack cases
            is_bust = True if player_data["status"] == "busted" else False

            result = self.determine_winner_classic(player_hand, dealer_hand, has_bonus)

            if result == "player":
                winnings = bet_amount * 2
                wallet[username]["chips"] += winnings
                wallet[username]["wins"] += 1
                wallet[username]["total_won"] += winnings
                casino['total_wins'] += winnings
                
                if len(casino['recent_winners']) >= 10:
                    casino['recent_winners'].pop(0)
                casino['recent_winners'].append((username, winnings, datetime.now().isoformat()))
                
                bonus_indicator = self.get_indicator(username)
                await self.highrise.chat(
                    f"{bonus_indicator}@{username} you win with [{self.calculate_hand_value(player_hand)[0]}]")
                await self.highrise.chat(f"{bonus_indicator}@{username} received [{winnings} Balance]")
            elif result == "dealer":
                wallet[username]["losses"] += 1
                message = f"@{username} went bust with [{self.calculate_hand_value(player_hand)[0]}]" if is_bust else f"@{username} you lose with [{self.calculate_hand_value(player_hand)[0]}]"
                await self.highrise.chat(message)
            elif result == "push":
                wallet[username]["chips"] += bet_amount
                await self.highrise.chat(f"@{username}, it's a push! You get your {bet_amount} chips back.")
            elif result == "player_blackjack":
                # This should only happen for non-immediate blackjack cases
                winnings = int(bet_amount * 2.5)
                wallet[username]["chips"] += winnings
                wallet[username]["wins"] += 1
                wallet[username]["total_won"] += winnings
                casino['total_wins'] += winnings
                
                if len(casino['recent_winners']) >= 10:
                    casino['recent_winners'].pop(0)
                casino['recent_winners'].append((username, winnings, datetime.now().isoformat()))
                await self.highrise.chat(f"{self.get_indicator(username)}@{username} Blackjack with 21!")
                await self.highrise.chat(f"{self.get_indicator(username)}@{username} received [{winnings} Balance]")
            elif result == "dealer_blackjack":
                wallet[username]["losses"] += 1
                await self.highrise.chat(f"@{username} loses to dealer Blackjack.")
            
            # Mark as complete after processing
            player_data["status"] = "complete"
            await asyncio.sleep(1)
        
        asyncio.create_task(self.reset_table())
        
    async def reset_table(self):
        async with BlackjackBot.LOCK:
        # Only reset deck if it's running low
            if len(self.deck.cards) - self.deck.card_index <= 10:
                self.deck.reset()
            if self.current_table["game_timer"]:
                self.current_table["game_timer"].cancel()
            self.current_table = {
            "active": False,
            "players": {},
            "bet_timer": None,
            "game_timer": None,
            "dealer_hand": [],
            "dealer_value": 0,
            "dealer_blackjack": False
        }
            self.drawing = False
            asyncio.create_task(self.highrise.chat("♠️ Type !bet to start the game."))

    async def show_balance(self, user: User) -> None:
        """Show user's balance via whisper."""
        username = user.username
        if username not in wallet:
            wallet[username] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
        await self.highrise.send_whisper(user.id, f"Your current balance: {wallet[username]['chips']} chips")

    def get_indicator(self, username: str) -> str:
        """Get indicator emoji based on user status."""
        # Crown for owners (highest priority)
        if username in owners:
            return "[👑] "
        
        # Gift for active bonus
        if self.check_active_bonus(username):
            return "[🎁] "
        
        # Diamond for winning more than 5 games
        if username in wallet and wallet[username].get("wins", 0) > 5:
            return "[💎] "
        
        # Hat for having lots of chips
        if username in wallet and wallet[username].get("chips", 0) > 1000:
            return "[🎩] "
        
        return ""  # No indicator

    async def handle_give_command(self, user: User, message: str) -> None:
        """Handle the !give command to send chips to another user."""
        try:
            args = message.split()
            if len(args) < 3:
                await self.highrise.send_whisper(user.id, "Usage: !give @username amount")
                return

            # Extract target username (remove @ symbol if present)
            target_username = args[1].lstrip('@')
            try:
                amount = int(args[2])
            except ValueError:
                await self.highrise.send_whisper(user.id, "Amount must be a number.")
                return

            if amount <= 0:
                await self.highrise.send_whisper(user.id, "Amount must be positive.")
                return

            sender_username = user.username
            
            # Check if sender has permission (owner or sufficient balance)
            if sender_username not in owners:
                if sender_username not in wallet or wallet[sender_username]["chips"] < amount:
                    await self.highrise.send_whisper(user.id, "Insufficient chips!")
                    return

            # Initialize target wallet if needed
            if target_username not in wallet:
                wallet[target_username] = {
                    "chips": 0,
                    "wins": 0,
                    "losses": 0,
                    "last_login": datetime.now().isoformat(),
                    "total_wagered": 0,
                    "total_won": 0
                }
                casino['total_players'] += 1

            # Transfer chips (only deduct from non-owners)
            if sender_username not in owners:
                wallet[sender_username]["chips"] -= amount
            
            wallet[target_username]["chips"] += amount

            indicator = self.get_indicator(sender_username)
            await self.highrise.chat(
                f"{indicator}@{sender_username} gave {amount} chips to @{target_username}"
            )

        except Exception as e:
            print(f"Give command error: {e}")
            await self.highrise.send_whisper(user.id, "Error processing give command")
    
    async def handle_bonus_command(self, user: User) -> None:
        """Handle the !bonus command with 24-hour cooldown."""
        username = user.username
        
        if username not in casino['bonuses']:
            casino['bonuses'][username] = {
                "last_used": None,
                "active_until": None
            }
        
        now = datetime.now()
        user_bonus = casino['bonuses'][username]
        
        # Check if 24 hours have passed since last use
        if user_bonus["last_used"]:
            last_used = datetime.fromisoformat(user_bonus["last_used"])
            time_since_last = now - last_used
            if time_since_last < timedelta(hours=24):
                remaining = timedelta(hours=24) - time_since_last
                hours = int(remaining.total_seconds() // 3600)
                minutes = int((remaining.total_seconds() % 3600) // 60)
                await self.highrise.send_whisper(user.id, f"Bonus cooldown active. Time remaining: {hours}h {minutes}m")
                return
        
        # Activate bonus
        user_bonus["last_used"] = now.isoformat()
        user_bonus["active_until"] = (now + timedelta(minutes=10)).isoformat()
        
        await self.highrise.send_whisper(user.id, "🎁 Bonus activated! Reduced bust probability for 10 minutes.")

    async def handle_remaining_bonus_command(self, user: User) -> None:
        """Handle the !rm command to check remaining bonus time."""
        username = user.username
        
        if username not in casino['bonuses'] or not casino['bonuses'][username]["active_until"]:
            await self.highrise.send_whisper(user.id, "No active bonus. Use !bonus to activate.")
            return
        
        now = datetime.now()
        active_until = datetime.fromisoformat(casino['bonuses'][username]["active_until"])
        
        if now >= active_until:
            await self.highrise.send_whisper(user.id, "Bonus has expired. Use !bonus to activate a new one (24h cooldown).")
            return
        
        remaining = active_until - now
        minutes = int(remaining.total_seconds() // 60)
        seconds = int(remaining.total_seconds() % 60)
        await self.highrise.send_whisper(user.id, f"🎁 Bonus time remaining: {minutes}m {seconds}s")

    def check_active_bonus(self, username: str) -> bool:
        """Check if user has an active bonus."""
        if username not in casino['bonuses'] or not casino['bonuses'][username]["active_until"]:
            return False
        
        now = datetime.now()
        active_until = datetime.fromisoformat(casino['bonuses'][username]["active_until"])
        return now < active_until
    
    async def show_help(self, user: User) -> None:
        """Show help message with all available commands."""
        h1 = ("\n🎰 CASINO COMMANDS 🎰\n"
                     "Game Commands:\n"
                     "!bet <amount> - Join the blackjack table (10-10000 chips)\n"
                     "!hit - Take another card\n"
                     "!stand - Stay with current hand\n"
                     "!double - Double your bet and take one card")
        h2 = ("\nAccount Commands:\n"
        "!bal - Check your chip balance\n"
        "!cash <amount> - Withdraw chips for gold (with standard hr taxes)\n"
        "!give @user 1 - Transfer funds to that player\n"
        "!winners - See recent winners")

        h3 =  ("\nBonus Commands:\n"
               "!bonus - Activate 10-minute bust reduction (24h cooldown)\n"
               "!rm - Check remaining bonus time")
        for i in (h1, h2, h3):
            await self.highrise.send_whisper(user.id, i)
            await asyncio.sleep(1)
        if user.username in owners:
            await self.highrise.send_whisper(user.id, "Owner commands:\n"
                                             "/set - Sets bot location\n"
                                             "!in <room url> - Sets room invite\n"
                                             "invite - Invites all users (check by !users)\n"
                                             "!addall - adds all unique players in invite list")
            await self.highrise.send_whisper(user.id, "\n!copy @user - Copies user's outfit")

    async def show_leaderboard(self) -> None:
        """Show the leaderboard."""
        # Sort players by total won
        sorted_players = sorted(
            [(username, data) for username, data in wallet.items()],
            key=lambda x: x[1]["total_won"],
            reverse=True
        )[:10]
        
        leaderboard_text = "🏆 **TOP PLAYERS** 🏆\n"
        for i, (username, data) in enumerate(sorted_players, 1):
            if data['total_won'] == 0: continue
            leaderboard_text += f"{i}. {username}: {data['total_won']} chips won\n"
        
        await self.highrise.chat(leaderboard_text)

    async def show_recent_winners(self, user) -> None:
        """Show recent winners."""
        if not casino.get('recent_winners'):
            await self.highrise.send_whisper(user.id, "No recent winners yet!")
            return
        
        winners_text = "🎉 RECENT WINNERS 🎉\n"
        for username, amount, timestamp in casino['recent_winners'][-5:]:
            winners_text += f"{username}: {amount} chips\n"
        
        await self.highrise.send_whisper(user.id, winners_text)

    async def handle_withdraw(self, user: User, message: str):
        try:
            args = message.split()
            if len(args) != 2 or not args[1].isdigit():
                await self.highrise.send_whisper(user.id, "Usage: !cash [amount] (Min: 20 chips)")
                return

            chips = int(args[1])
            ps = int(chips * 1.1)
            username = user.username

            if chips < 20:
                await self.highrise.send_whisper(user.id, "Minimum withdrawal: 20 chips.")
                return
                
            if wallet[username]["chips"] < ps:
                await self.highrise.send_whisper(user.id, f"Not enough chips! [Balance: {wallet[username]['chips']} needs {ps}]")
                return

            # Calculate gold after 5% fee
            gold_after_fee = int(chips)
            wallet[username]["chips"] -= ps

            # Prepare gold bars
            denominations = [
                (10000, "gold_bar_10k"),
                (5000, "gold_bar_5000"),
                (1000, "gold_bar_1k"),
                (500, "gold_bar_500"),
                (100, "gold_bar_100"),
                (50, "gold_bar_50"),
                (10, "gold_bar_10"),
                (5, "gold_bar_5"),
                (1, "gold_bar_1")
            ]

            remaining = gold_after_fee
            tip_items = []
            
            for value, bar_type in denominations:
                while remaining >= value and len(tip_items) < 10:
                    tip_items.append(bar_type)
                    remaining -= value

            if tip_items:
                try:
                    await self.highrise.tip_user(user.id, ",".join(tip_items))
                    await self.highrise.chat(f"{self.get_indicator(user.username)}@{user.username} cashed [Golds {chips}g]")
                except Exception as e:
                    print(e)
            else:
                await self.highrise.send_whisper(user.id, "Withdrawal failed - try a larger amount")

        except Exception as e:
            print(f"Withdrawal error: {e}")
            await self.highrise.send_whisper(user.id, "Withdrawal processing failed")

    async def show_info(self, user: User) -> None:
        """Show casino information."""
        info_text = (
            f"🎰 Casino Stats 🎰\n"
            f"Total Players: {casino.get('total_players', 0)}\n"
            f"Active Players: {casino.get('active_players', 0)}\n"
            f"Games Played: {casino.get('games_played', 0)}\n"
            f"Total Bets: {casino.get('total_bets', 0)} chips\n"
            f"Total Wins: {casino.get('total_wins', 0)} chips"
        )
        await self.highrise.send_whisper(user.id, info_text)