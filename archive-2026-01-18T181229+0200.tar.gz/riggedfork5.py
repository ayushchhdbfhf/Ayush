import random
import asyncio
import os
import logging
import sys
from datetime import datetime, timedelta
from casinodb.cbot5 import *
import random
import logging
from highrise import BaseBot, __main__
from highrise import *
from highrise.webapi import *
from highrise.models_webapi import *
from highrise.models import *
from typing import Dict, List, Tuple, Optional, Any
import traceback
import logging

logger = logging.getLogger(__name__)

class BotDefinition:
    def __init__(self, bot: BaseBot, room_id: str, api_token: str):
        self.bot = bot
        self.room_id = room_id
        self.api_token = api_token

class Card:
    """Represents a playing card with a suit and value."""
    SUITS = ["♥", "♦", "♣", "♠"]
    VALUES = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
    
    def __init__(self, suit: str, value: str):
        self.suit = suit
        self.value = value
    
    def __str__(self) -> str:
        return f"{self.value}{self.suit}"
    
    def get_blackjack_value(self) -> int:
        """Get the card's value in blackjack."""
        if self.value in ["J", "Q", "K"]:
            return 10
        elif self.value == "A":
            return 11  # Ace is handled specially in hand evaluation
        else:
            return int(self.value)
    
    def to_dict(self):
        """Convert card to serializable dict."""
        return {"suit": self.suit, "value": self.value}
    
    @staticmethod
    def from_dict(data):
        """Create card from dict."""
        try:
            if isinstance(data, dict) and 'suit' in data and 'value' in data:
                return Card(data["suit"], data["value"])
            # If it's already a Card object, return it
            elif hasattr(data, 'suit') and hasattr(data, 'value'):
                return data
            else:
                # Try to handle if data is a string like "A♥"
                if isinstance(data, str) and len(data) >= 2:
                    # Handle format like "A♥" or "10♠"
                    if data[:-1].isdigit():
                        value = data[:-1]
                        suit = data[-1]
                    else:
                        value = data[0]
                        suit = data[1]
                    if suit in Card.SUITS and value in Card.VALUES:
                        return Card(suit, value)
        except Exception as e:
            print(f"Error creating card from data: {e}, data: {data}")
        
        # Default fallback
        return Card("♥", "A")

class Deck:
    """Represents a deck of cards with controlled 60% dealer advantage."""
    def __init__(self):
        self.cards = []
        self.card_index = 0
        self.shuffle_point = 0
        self.advantage_mode = True  # Enable 60% dealer advantage
        self.game_state = {}  # Track current game state for intelligent decisions
        self.reset()
        
    def _is_good_player_hand(self, card1_value: int, card2_value: int) -> bool:
        """Check if a hand is good for player (should be avoided)."""
        total = card1_value + card2_value

        # Bad hands for player (good for dealer): 12-16
        if 12 <= total <= 16:
            return False

        # Good hands for player (bad for dealer): 19-21
        if total >= 19:
            return True

        # Neutral hands: 17-18
        return False

    def reset(self):
        """Resets and shuffles the deck - players get LOW cards initially."""
        self.cards = [Card(suit, value) for suit in Card.SUITS for value in Card.VALUES]

        if self.advantage_mode:
            # Categorize cards strictly
            low_cards = [card for card in self.cards if card.get_blackjack_value() <= 6]  # 2-6 (24 cards)
            medium_cards = [card for card in self.cards if 7 <= card.get_blackjack_value() <= 9]  # 7-9 (12 cards)
            high_cards = [card for card in self.cards if card.get_blackjack_value() >= 10]  # 10-A (16 cards)

            # Count cards for verification
            total_cards = len(low_cards) + len(medium_cards) + len(high_cards)
            print(f"DEBUG: Total cards: {total_cards}, Low: {len(low_cards)}, Medium: {len(medium_cards)}, High: {len(high_cards)}")

            # Shuffle each category
            random.shuffle(low_cards)
            random.shuffle(medium_cards)
            random.shuffle(high_cards)

            # STRATEGIC DECK STACKING:
            # Cards 1-10: Dealer area (mixed)
            # Cards 11-30: Player initial cards (LOW/MEDIUM ONLY)
            # Cards 31-40: Player hit cards (HIGH - for busting)
            # Cards 41-52: Dealer favorable cards
            stacked_deck = []

            # === SECTION 1: Dealer Cards (Position 1-10) ===
            dealer_section = []

            # Dealer needs possibility of blackjack, so give one high card
            if high_cards:
                dealer_section.append(high_cards.pop())  # One high card for dealer

            # Fill with mostly low/medium
            for _ in range(9):  # Need 9 more cards for 10 total
                # 60% low, 40% medium for dealer
                if random.random() < 0.6 and low_cards:
                    dealer_section.append(low_cards.pop())
                elif medium_cards:
                    dealer_section.append(medium_cards.pop())
                elif low_cards:
                    dealer_section.append(low_cards.pop())
                elif high_cards:
                    dealer_section.append(high_cards.pop())

            random.shuffle(dealer_section)
            stacked_deck.extend(dealer_section)
            print(f"DEBUG: Dealer section: {len(dealer_section)} cards")

            # === SECTION 2: Player Initial Cards (Position 11-30) ===
            # CRITICAL: Players get LOW cards for their first 2 cards
            player_initial_section = []
            cards_needed = 20  # 10 players × 2 cards each

            for i in range(cards_needed):
                if i % 2 == 0:  # Player's FIRST card
                    # FIRST card: 80% low, 20% medium, 0% high
                    rand = random.random()
                    if rand < 0.8 and low_cards:
                        player_initial_section.append(low_cards.pop())
                    elif medium_cards:
                        player_initial_section.append(medium_cards.pop())
                    elif low_cards:
                        player_initial_section.append(low_cards.pop())
                    else:
                        # Emergency: take from high but shuffle to avoid pattern
                        if high_cards:
                            player_initial_section.append(high_cards.pop())
                else:  # Player's SECOND card
                    # SECOND card: Based on first card value (simulated)
                    rand = random.random()
                    if rand < 0.7 and low_cards:  # 70% low
                        player_initial_section.append(low_cards.pop())
                    elif rand < 0.95 and medium_cards:  # 25% medium
                        player_initial_section.append(medium_cards.pop())
                    elif high_cards:  # 5% high (only if must)
                        player_initial_section.append(high_cards.pop())
                    elif low_cards:
                        player_initial_section.append(low_cards.pop())
                    elif medium_cards:
                        player_initial_section.append(medium_cards.pop())

            # Shuffle to avoid obvious low-low patterns
            random.shuffle(player_initial_section)
            stacked_deck.extend(player_initial_section)
            print(f"DEBUG: Player initial section: {len(player_initial_section)} cards")

            # === SECTION 3: Player Hit Cards (Position 31-40) ===
            # When players hit, give them HIGH cards to make them bust
            player_hit_section = []
            for _ in range(10):
                if high_cards:
                    player_hit_section.append(high_cards.pop())
                elif medium_cards:
                    player_hit_section.append(medium_cards.pop())
                elif low_cards:
                    player_hit_section.append(low_cards.pop())

            random.shuffle(player_hit_section)
            stacked_deck.extend(player_hit_section)
            print(f"DEBUG: Player hit section: {len(player_hit_section)} cards")

            # === SECTION 4: Dealer Favorable Cards (Position 41-52) ===
            dealer_favorable_section = []
            cards_remaining = 52 - len(stacked_deck)

            for _ in range(cards_remaining):
                # Dealer favorable: medium cards (7-9) are perfect
                if medium_cards:
                    dealer_favorable_section.append(medium_cards.pop())
                elif low_cards:
                    dealer_favorable_section.append(low_cards.pop())
                elif high_cards:
                    dealer_favorable_section.append(high_cards.pop())

            random.shuffle(dealer_favorable_section)
            stacked_deck.extend(dealer_favorable_section)
            print(f"DEBUG: Dealer favorable section: {len(dealer_favorable_section)} cards")

            # Verify we used all cards
            unused = len(low_cards) + len(medium_cards) + len(high_cards)
            if unused > 0:
                print(f"WARNING: {unused} cards unused in deck stacking")
                leftover = low_cards + medium_cards + high_cards
                random.shuffle(leftover)
                stacked_deck.extend(leftover)

            # Final deck length check
            if len(stacked_deck) != 52:
                print(f"ERROR: Deck has {len(stacked_deck)} cards, should be 52!")
                self.cards = [Card(suit, value) for suit in Card.SUITS for value in Card.VALUES]
                random.shuffle(self.cards)
            else:
                self.cards = stacked_deck
                # One more shuffle to break any remaining patterns
                random.shuffle(self.cards[5:15])  # Shuffle small middle section only

            print(f"DEBUG: Final deck ready. First 10 cards values: {[c.get_blackjack_value() for c in self.cards[:10]]}")

        else:
            # Normal shuffle (backup)
            self.cards = [Card(suit, value) for suit in Card.SUITS for value in Card.VALUES]
            random.shuffle(self.cards)

        self.card_index = 0
        self.shuffle_point = random.randint(15, 20)  # Shuffle early to maintain advantage

        # Initialize tracking
        self.last_player_first_card = None
        self.consecutive_player_high_cards = 0

        # Occasionally do a completely normal shuffle (5% chance) to avoid detection
        if random.random() < 0.05:
            normal_cards = [Card(suit, value) for suit in Card.SUITS for value in Card.VALUES]
            random.shuffle(normal_cards)
            self.cards = normal_cards
            print("DEBUG: Random normal shuffle applied (5% chance)")

        # Verify the deck
        high_cards_in_first_30 = sum(1 for card in self.cards[:30] if card.get_blackjack_value() >= 10)
        print(f"DEBUG: High cards in first 30 positions (player area): {high_cards_in_first_30}/30")

        # Ensure not too many high cards in player area
        if high_cards_in_first_30 > 8:  # More than 8 high cards in player area
            print("DEBUG: Too many high cards in player area, reshuffling...")
            high_indices = [i for i, card in enumerate(self.cards[:30]) if card.get_blackjack_value() >= 10]
            low_indices = [i for i, card in enumerate(self.cards[30:]) if card.get_blackjack_value() <= 9]

            swaps_needed = high_cards_in_first_30 - 8
            for swap in range(min(swaps_needed, len(high_indices), len(low_indices))):
                hi = high_indices[swap]
                li = low_indices[swap] + 30  # Adjust index
                self.cards[hi], self.cards[li] = self.cards[li], self.cards[hi]

    def update_game_state(self, state: Dict[str, Any]):
        """Update current game state for intelligent card dealing."""
        self.game_state = state
    
    def deal(self, context: str = "neutral") -> Card:
        """Deal a card with anti-player bias."""
        if self.card_index >= len(self.cards) or (len(self.cards) - self.card_index) <= self.shuffle_point:
            self.reset()

        card = self.cards[self.card_index]

        # Track if we just gave a high first card
        if context == "player_initial":
            # Store what we're about to give as first card
            self.last_player_first_card = card.get_blackjack_value() if card.get_blackjack_value() >= 10 else None

        # If last first card was high and this is likely the second card, force low
        if hasattr(self, 'last_player_first_card') and self.last_player_first_card is not None:
            if card.get_blackjack_value() >= 10:
                # Try to find a low card to swap with
                lookahead = min(5, len(self.cards) - self.card_index - 1)
                for i in range(lookahead):
                    next_card = self.cards[self.card_index + i + 1]
                    if next_card.get_blackjack_value() <= 9:
                        # Swap high for low
                        self.cards[self.card_index] = next_card
                        self.cards[self.card_index + i + 1] = card
                        card = next_card
                        break
            # Reset tracking
            self.last_player_first_card = None

        # Apply advantage logic
        if self.advantage_mode:
            card = self._apply_advantage_logic(card, context)

        self.card_index += 1
        return card

    def _apply_advantage_logic(self, current_card: Card, context: str) -> Card:
        """Apply advantage logic that makes players lose more often."""
        if not self.advantage_mode or random.random() < 0.3:  # 30% chance to be fair
            return current_card  # Sometimes give fair card to avoid pattern
            
        lookahead = min(4, len(self.cards) - self.card_index - 1)
        if lookahead <= 0:
            return current_card
            
        next_cards = self.cards[self.card_index + 1:self.card_index + 1 + lookahead]
        
        if context == "dealer_hit":
            return self._optimize_dealer_card(current_card, next_cards)
        elif context == "player_hit":
            return self._optimize_player_card(current_card, next_cards)
        elif context == "player_initial":
            return self._optimize_initial_player_card(current_card, next_cards)
        
        return current_card

    def _optimize_dealer_card(self, current_card: Card, next_cards: List[Card]) -> Card:
        """Optimize for dealer to get good cards."""
        dealer_value = self.game_state.get('dealer_value', 0)
        
        if dealer_value <= 16:
            best_card = current_card
            best_score = -1000
            
            for card in next_cards:
                card_value = card.get_blackjack_value()
                new_total = dealer_value + card_value
                
                # Score: Higher is better for dealer
                score = 0
                
                if new_total > 21:
                    score = -100  # Bust is very bad
                elif new_total == 21:
                    score = 200   # 21 is perfect
                elif 17 <= new_total <= 20:
                    score = 150 + (new_total - 17) * 10  # 17-20 is great
                elif new_total < 17:
                    score = new_total * 5  # Still needs to hit
                
                # Extra bonus for cards that help dealer
                if dealer_value <= 11 and card_value >= 10:
                    score += 50  # Big cards when dealer is low
                elif dealer_value >= 12 and card_value <= 6:
                    score += 30  # Small cards when dealer might bust
                
                if score > best_score:
                    best_score = score
                    best_card = card
            
            # 80% chance to take better card
            if best_card != current_card and random.random() < 0.8:
                return self._swap_for_better_card(best_card, current_card)
        
        return current_card

    def _optimize_player_card(self, current_card: Card, next_cards: List[Card]) -> Card:
        """Optimize for player to get bad cards."""
        player_value = self.game_state.get('player_value', 0)
        
        # Always try to give players bad cards when they hit
        worst_card = current_card
        worst_score = 1000
        
        for card in next_cards:
            card_value = card.get_blackjack_value()
            new_total = player_value + card_value
            
            # Score: Lower is worse for player
            score = 0
            
            if new_total > 21:
                score = -200  # Player busts - PERFECT for dealer
            elif player_value <= 11 and card_value >= 10:
                score = -100  # Big card when player is low - good for dealer
            elif player_value >= 12 and card_value >= 10:
                score = -150  # Player likely to bust - excellent
            elif player_value >= 17 and card_value <= 6:
                score = 100   # Small card when player is high - bad for dealer
            elif new_total == 21:
                score = 200   # Player gets 21 - worst for dealer
            elif new_total >= 19:
                score = 150   # Player gets 19-20 - bad
            elif new_total <= 16:
                score = 50    # Player still needs to hit - ok
            else:
                score = 80    # Neutral
            
            if score < worst_score:
                worst_score = score
                worst_card = card
        
        # 75% chance to give worse card
        if worst_card != current_card and random.random() < 0.75:
            return self._swap_for_better_card(worst_card, current_card)
        
        return current_card

    def _optimize_initial_player_card(self, current_card: Card, next_cards: List[Card]) -> Card:
        """Give players difficult starting hands."""
        first_card_value = self.game_state.get('player_first_card', 0)
        
        worst_card = current_card
        worst_score = 1000
        
        for card in next_cards:
            card_value = card.get_blackjack_value()
            total = first_card_value + card_value
            
            # Score: Lower is worse for player
            score = 0
            
            # Worst hands for player:
            if total == 12 or total == 13 or total == 14 or total == 15 or total == 16:
                score = -200  # Worst possible hands
            elif total == 8 or total == 9 or total == 10:
                score = -150  # Too low, need to hit
            elif total == 17:
                score = -50   # Dealer favorite (dealer wins on tie)
            elif total == 18:
                score = 0     # Neutral
            elif total == 19:
                score = 50    # Good for player
            elif total == 20:
                score = 100   # Very good for player
            elif total == 21:
                if (first_card_value == 11 and card_value == 10) or (first_card_value == 10 and card_value == 11):
                    score = 300  # Blackjack - worst for dealer
                else:
                    score = 150  # Regular 21
            else:
                score = 30 - abs(17 - total)  # Closer to 17 is worse for player
            
            # Extra penalty for giving player 20
            if total == 20:
                score -= 50  # Make it less likely to give 20
            
            if score < worst_score:
                worst_score = score
                worst_card = card
        
        # 70% chance to give worse card
        if worst_card != current_card and random.random() < 0.7:
            return self._swap_for_better_card(worst_card, current_card)
        
        return current_card

    def _swap_for_better_card(self, better_card: Card, current_card: Card) -> Card:
        """Swap current card with a better card from upcoming positions."""
        try:
            better_index = self.cards.index(better_card, self.card_index + 1)
            if better_index < len(self.cards):
                self.cards[self.card_index] = better_card
                self.cards[better_index] = current_card
                return better_card
        except ValueError:
            pass
        return current_card

    def peek_next_cards(self, count: int = 3) -> List[Card]:
        """Peek at upcoming cards for intelligent decision making."""
        end_index = min(self.card_index + count, len(self.cards))
        return self.cards[self.card_index:end_index]
    
    def estimate_high_cards_remaining(self) -> int:
        """Estimate how many high cards remain in deck."""
        remaining_cards = self.cards[self.card_index:]
        return sum(1 for card in remaining_cards if card.get_blackjack_value() >= 10)
    
    def get_state(self):
        """Get serializable deck state."""
        return {
            'cards': [card.to_dict() for card in self.cards],
            'card_index': self.card_index,
            'shuffle_point': self.shuffle_point,
            'advantage_mode': self.advantage_mode,
            'game_state': self.game_state
        }
    
    def set_state(self, state):
        """Set deck state from serialized data."""
        if state and 'cards' in state:
            try:
                self.cards = [Card.from_dict(card_data) for card_data in state['cards']]
                self.card_index = state.get('card_index', 0)
                self.shuffle_point = state.get('shuffle_point', 0)
                self.advantage_mode = state.get('advantage_mode', True)
                self.game_state = state.get('game_state', {})
            except Exception as e:
                print(f"Error restoring deck state: {e}")
                self.reset()

class BlackjackBot(BaseBot):
    # CHANGE 1: Added a lock to manage concurrent access to game state
    LOCK = asyncio.Lock()
    TABLE_INIT_LOCK = asyncio.Lock()
    
    def __init__(self):
        super().__init__()
        self.username = None
        self.ownername = None
        self.bot_id = None
        self.update_task = None
        self.emote_task = None
        self.dance_loop_running = False
        self.table_initializing = False
        self.deck = Deck()
        self.betting_timer_task = None
        self.game_timer_task = None
        
        # Use persistent table state or create new
        if table:
            self.current_table = table.copy()  # Create a copy to avoid reference issues
            self.drawing = table.get("drawing", False)
            # Restore deck state if available
            if table.get("deck_state"):
                self.deck.set_state(table["deck_state"])
        else:
            self.current_table = {
                "active": False,
                "players": {},
                "bet_timer_active": False,
                "game_timer_active": False,
                "dealer_hand": [],
                "dealer_value": 0,
                "dealer_blackjack": False,
                "drawing": False,
                "game_in_progress": False
            }
            self.drawing = False
        
        self.logger = logger
        
        # Initialize bonuses in casinodata if not exists
        if 'bonuses' not in casino:
            casino['bonuses'] = {}
            
    async def run_bot(self, room_id, token):
        definitions = [BotDefinition(self, room_id, token)]
        await __main__.main(definitions)
        
    async def restart_bot(self, user):
        if not user.username in owners:
            return
        await self.highrise.send_whisper(user.id, "This command is restricted use !reset")
        return
        try:
            await asyncio.sleep(5)
        except asyncio.CancelledError:
            return
        os.execv(sys.executable, [sys.executable, 'run.py'] + sys.argv[1:])
    
    async def on_user_join(self, user: User, pos: Position) -> None:
        try:
            try:
                await asyncio.sleep(5)
            except asyncio.CancelledError:
                return
            m = ("♣️ Welcome to the Blackjack Table! ♣️\n\n"
                 "Purchase [Chips] by tipping the bot, and put your chips with !bet to begin.\n\n"
                 "Table minimum: 10g\n"
                 "Table maximum: 10,000g")
            await self.highrise.send_whisper(user.id, m)
            casino['active_players'] += 1
            if user.username not in wallet:
                wallet[user.username] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
                casino['total_players'] += 1
        except Exception as e: print(e)
    
    async def on_user_leave(self, user: User) -> None:
        pass
    
    async def on_message(self, user_id: str, conversation_id: str, is_new_conversation: bool) -> None:
        try:
            name = await self.get_username(user_id)
            if name not in wallet:
                    wallet[name] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
            if user_id not in ids: 
                ids.append(user_id)
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.send_message(conversation_id, "Your acc is verified.")
            response = await self.highrise.get_messages(conversation_id)
            if isinstance(response, GetMessagesRequest.GetMessagesResponse):
                message = response.messages[0].content
                if message.lower().startswith("!bal"):
                    await self.highrise.send_message(conversation_id, f"💰 You have [{wallet[name]['chips']} Gold] in your balance.")
                if message.lower().startswith("!help"):
                    await self.show_help(user_id, is_convo=conversation_id)
                if message.lower().startswith("!resources"):
                    await self.show_resources(user_id, is_convo=conversation_id)
                if message.lower().startswith("!rules"):
                    await self.show_rules(user_id, is_convo=conversation_id)
                if message.lower().startswith("!terms"):
                    await self.show_terms(user_id, is_convo=conversation_id)
        except Exception as e: print(e)
        
    async def copy_outfit(self, user, message):
        try:
            if user.username not in owners:
                return
            target_username = message[6:].strip().lstrip('@')
            response = await self.webapi.get_users(username=target_username, limit=1)
                
            if not response.users:
                await self.highrise.send_whisper(user.id, f"User @{target_username} not found.")
                return
                
            target_user = response.users[0]
            outfit_response = await self.highrise.get_user_outfit(target_user.user_id)
                
            try:
                await self.highrise.set_outfit(outfit=outfit_response.outfit)
                await self.highrise.send_whisper(user.id, f"Successfully copied @{target_user.username}'s complete outfit!")
                return
            except Exception:
                successful_items = []
                failed_items = []
                    
                for item in outfit_response.outfit:
                    try:
                        await self.highrise.set_outfit(outfit=successful_items + [item])
                        successful_items.append(item)
                    except Exception:
                        failed_items.append(item.id.split('-')[-1])
                    
                if failed_items:
                    await self.highrise.send_whisper(user.id, 
                        f"Copied @{target_user.username}'s outfit but skipped {len(failed_items)} items: "
                        f"{', '.join(failed_items[:5])}{'...' if len(failed_items) > 5 else ''}")
                else:
                    await self.highrise.send_whisper(user.id, f"Successfully copied @{target_user.username}'s outfit piece by piece!")
            
        except Exception:
            await self.highrise.send_whisper(user.id, "Failed to copy outfit. Please try again.")

    async def update_players(self):
        try:
            while True:
                try:
                    room_users = (await self.highrise.get_room_users()).content
                    # Filter out self.user from the count
                    casino['active_players'] = len([user for user in room_users 
                                              if user[0].id != self.bot_id])
                    try:
                        await asyncio.sleep(77)
                    except asyncio.CancelledError:
                        break
                except: 
                    continue
        except:
            pass

    async def get_username(self, user_id):
        user_info = await self.webapi.get_user(user_id)
        return user_info.user.username
    
    async def _dance_loop(self):
        while self.dance_loop_running:
            try:
                await self.highrise.send_emote("sit-open")
                try:
                    await asyncio.sleep(26.025967)
                except asyncio.CancelledError:
                    break
            except Exception as e:
                break 
    
    async def safe_cancel_task(self, task_name: str, task):
        """Safely cancel a task without interfering with saves."""
        if task and not task.done():
            task.cancel()
            try:
                # Give it time to finish any atomic operations
                await asyncio.wait_for(task, timeout=2.0)
                print(f"Task {task_name} cancelled cleanly")
            except asyncio.CancelledError:
                print(f"Task {task_name} was already cancelled")
            except asyncio.TimeoutError:
                print(f"Task {task_name} timeout during cancellation")
            except Exception as e:
                print(f"Error cancelling {task_name}: {e}")
    
    async def on_start(self, session_metadata: SessionMetadata) -> None:
        try:
            self.username = await self.get_username(session_metadata.user_id)
            self.bot_id = session_metadata.user_id
            self.ownername = await self.get_username(session_metadata.room_info.owner_id)
            print(f"BOT {self.username} has started.")
            
            if self.ownername:
                if self.ownername not in owners:
                    owners.append(self.ownername)
            
            # Cancel existing tasks properly
            await self.safe_cancel_task("emote_task", self.emote_task)
            await self.safe_cancel_task("update_task", self.update_task)
            
            try:
                await asyncio.sleep(1.5)
            except asyncio.CancelledError:
                return
            
            # Clean up any stuck states first
            await self.cleanup_stuck_state()
            
            self.update_task = asyncio.create_task(self.update_players())
            if bot_location:
                await self.highrise.teleport(session_metadata.user_id, Position(**bot_location))
            else:
                await self.highrise.teleport(session_metadata.user_id, Position(15.5, 0.25, 2.5, 'FrontRight'))
            
            # Restore game state if table was active
            if self.current_table.get("active"):
                await self.recover_game_state()
                
        except Exception as e:
            print("Error in on_start:", e)
    
    async def cleanup_stuck_state(self):
        """Clean up any stuck game states."""
        try:
            # Check if we're in a stuck drawing state
            if (self.drawing and 
                not self.current_table.get("bet_timer_active") and 
                not self.current_table.get("game_timer_active")):
                
                # Check if all players are complete
                all_complete = True
                for player_data in self.current_table.get("players", {}).values():
                    if player_data.get("status") not in ["complete", "busted", "stood"]:
                        all_complete = False
                        break
                
                if all_complete:
                    # Game is over but drawing is still True
                    self.drawing = False
                    self.current_table["drawing"] = False
                    self.current_table["game_in_progress"] = False
                    await self.save_table_state()
                    await self.highrise.chat("♠️ Game completed. Type !bet to start a new game.")
                    await self.reset_table()
        except Exception as e:
            print(f"Error in cleanup_stuck_state: {e}")
    
    async def recover_game_state(self):
        """Recover game state after bot restart - FIXED VERSION."""
        try:
            if not self.current_table.get("active"):
                return
                
            print(f"DEBUG: Attempting game state recovery...")
            print(f"DEBUG: Table active: {self.current_table.get('active')}")
            print(f"DEBUG: Dealer hand: {self.current_table.get('dealer_hand')}")
            print(f"DEBUG: Players: {list(self.current_table.get('players', {}).keys())}")
            
            # NEW: Prevent new interactions during recovery
            self.table_initializing = True
            
            # NEW: Restore deck state first
            if self.current_table.get("deck_state"):
                self.deck.set_state(self.current_table["deck_state"])
                print(f"DEBUG: Deck state restored, remaining cards: {len(self.deck.cards) - self.deck.card_index}")
            
            # Restore dealer hand - ensure all cards are Card objects
            dealer_hand = []
            for card_data in self.current_table.get("dealer_hand", []):
                card = Card.from_dict(card_data) if isinstance(card_data, dict) else card_data
                if hasattr(card, 'suit') and hasattr(card, 'value'):
                    dealer_hand.append(card)
                else:
                    print(f"DEBUG: Invalid card in dealer hand: {card_data}")
                    # Skip invalid card
                    
            self.current_table["dealer_hand"] = dealer_hand
            
            # Calculate dealer values
            if dealer_hand:
                dealer_value, dealer_blackjack = self.calculate_hand_value(dealer_hand)
                self.current_table["dealer_value"] = dealer_value
                self.current_table["dealer_blackjack"] = dealer_blackjack
                print(f"DEBUG: Dealer restored: {dealer_hand}, value: {dealer_value}, blackjack: {dealer_blackjack}")
            
            # NEW: Get current room users to validate player presence
            try:
                room_users_response = await self.highrise.get_room_users()
                room_users = [user[0].username for user in room_users_response.content]
                print(f"DEBUG: Current room users: {room_users}")
            except Exception as e:
                print(f"DEBUG: Could not get room users: {e}")
                room_users = []
            
            # Check for players waiting for blackjack resolution
            has_blackjack_situation = False
            for user_id, player_data in self.current_table.get("players", {}).items():
                if player_data.get("status") == "waiting_resolution":
                    has_blackjack_situation = True
                    break
            
            if has_blackjack_situation:
                # We're recovering from a blackjack situation
                await self.highrise.chat("♠️ Completing blackjack resolution...")
                
                for user_id, player_data in self.current_table.get("players", {}).items():
                    if player_data.get("status") == "waiting_resolution":
                        # Check if player is still in room
                        username = player_data.get("username", "")
                        if username not in room_users:
                            print(f"DEBUG: Player {username} not in room, skipping")
                            player_data["status"] = "complete"
                            continue
                        
                        # Restore player hand
                        player_hand = []
                        for card_data in player_data.get("player_hand", []):
                            card = Card.from_dict(card_data) if isinstance(card_data, dict) else card_data
                            if hasattr(card, 'suit') and hasattr(card, 'value'):
                                player_hand.append(card)
                            else:
                                print(f"DEBUG: Invalid card in player hand: {card_data}")
                        
                        player_data["player_hand"] = player_hand
                        
                        if not player_hand or len(player_hand) < 2:
                            print(f"DEBUG: Invalid hand for {username}, marking complete")
                            player_data["status"] = "complete"
                            continue
                        
                        # Calculate player values
                        player_value, player_blackjack = self.calculate_hand_value(player_hand)
                        
                        # Resolve the blackjack
                        await self.resolve_immediate_blackjack(
                            user_id, player_data, dealer_hand, 
                            dealer_value, player_blackjack, self.current_table.get("dealer_blackjack", False)
                        )
                
                # Reset drawing state
                self.current_table["game_in_progress"] = True
                self.drawing = False
                self.current_table["drawing"] = False
                await self.save_table_state()
                
                # Check if all players are complete
                await self.check_recovery_completion()
                return
            
            # Restore player hands and ensure all players have 2 cards
            players_need_cards = False
            valid_players = 0
            
            for user_id, player_data in self.current_table.get("players", {}).items():
                username = player_data.get("username", "unknown")
                
                # NEW: Check if player is still in room
                if username not in room_users:
                    print(f"DEBUG: Player {username} not in room, marking complete")
                    player_data["status"] = "complete"
                    continue
                    
                valid_players += 1
                print(f"DEBUG: Recovering player {username}, hand: {player_data.get('player_hand')}")
                
                restored_hand = []
                if "player_hand" in player_data and player_data["player_hand"]:
                    for card_data in player_data["player_hand"]:
                        card = Card.from_dict(card_data) if isinstance(card_data, dict) else card_data
                        if hasattr(card, 'suit') and hasattr(card, 'value'):
                            restored_hand.append(card)
                        else:
                            print(f"DEBUG: Invalid card data: {card_data}")
                
                # Check if player needs more cards
                if len(restored_hand) < 2:
                    players_need_cards = True
                    print(f"DEBUG: Player {username} needs {2 - len(restored_hand)} more cards")
                    # Deal missing cards
                    while len(restored_hand) < 2:
                        card = self.deck.deal("player_initial")
                        restored_hand.append(card)
                
                player_data["player_hand"] = restored_hand
                
                # Recalculate player status
                if len(restored_hand) >= 2:
                    player_value, player_blackjack = self.calculate_hand_value(restored_hand)
                    if player_blackjack or self.current_table.get("dealer_blackjack", False):
                        player_data["status"] = "waiting_resolution"
                    else:
                        player_data["status"] = "active"
            
            # NEW: Check if we have any valid players
            if valid_players == 0:
                print(f"DEBUG: No valid players in room after recovery")
                await self.reset_table()
                return
                
            # If players needed cards, complete the card dealing process
            if players_need_cards:
                await self.highrise.chat("♠️ Completing card dealing for all players...")
                self.drawing = True
                self.current_table["drawing"] = True
                await self.save_table_state()
                
                # Show all player hands
                for user_id, player_data in self.current_table.get("players", {}).items():
                    if player_data.get("status") == "complete":
                        continue
                        
                    if "player_hand" in player_data and player_data["player_hand"]:
                        player_value, player_blackjack = self.calculate_hand_value(player_data["player_hand"])
                        await self.highrise.chat(
                            f"@{player_data['username']} {self.format_hand(player_data['player_hand'])} = [{player_value}]"
                        )
                        try:
                            await asyncio.sleep(1.5)
                        except asyncio.CancelledError:
                            return
                
                # Show dealer hand
                dealer_hand = self.current_table["dealer_hand"]
                if dealer_hand:
                    dealer_value, dealer_blackjack = self.calculate_hand_value(dealer_hand, hide=True)
                    self.current_table["dealer_value"] = dealer_value
                    self.current_table["dealer_blackjack"] = dealer_blackjack
                    
                    await self.highrise.chat(f"[🎲] Dealer: {self.format_hand(dealer_hand, hide_second_card=True)} = [{dealer_value}]")
                
                # Check for immediate blackjack outcomes
                all_players_immediate = True
                for user_id, player_data in self.current_table.get("players", {}).items():
                    if player_data.get("status") == "complete":
                        continue
                        
                    player_value, player_blackjack = self.calculate_hand_value(player_data["player_hand"])
                    if player_blackjack or self.current_table.get("dealer_blackjack", False):
                        player_data["status"] = "waiting_resolution"
                    else:
                        player_data["status"] = "active"
                        all_players_immediate = False
                
                if all_players_immediate:
                    for user_id, player_data in self.current_table.get("players", {}).items():
                        if player_data.get("status") != "waiting_resolution":
                            continue
                            
                        player_value, player_blackjack = self.calculate_hand_value(player_data["player_hand"])
                        asyncio.create_task(self.resolve_immediate_blackjack(user_id, player_data, dealer_hand, 
                                                                            self.current_table.get("dealer_value", 0), 
                                                                            player_blackjack, 
                                                                            self.current_table.get("dealer_blackjack", False)))
                else:
                    await self.highrise.chat(f"♠️ Type !hit, !stand, !double [⏳ 45 seconds]")
                    self.drawing = False
                    self.current_table["drawing"] = False
                    self.current_table["game_in_progress"] = True
                    await self.save_table_state()
                    
                    # NEW: Cancel existing timer if any
                    if self.game_timer_task and not self.game_timer_task.done():
                        await self.safe_cancel_task("game_timer", self.game_timer_task)
                        
                    self.game_timer_task = asyncio.create_task(self.start_game_timer())
                return
            
            # Restore timers based on game phase
            if self.current_table.get("bet_timer_active"):
                # Start new betting timer
                if self.betting_timer_task and not self.betting_timer_task.done():
                    await self.safe_cancel_task("betting_timer", self.betting_timer_task)
                    
                self.betting_timer_task = asyncio.create_task(self.start_betting_timer())
                await self.highrise.chat("♠️ Betting timer restored. Place your bets!")
                
            elif self.current_table.get("game_timer_active"):
                # Start new game timer
                if self.game_timer_task and not self.game_timer_task.done():
                    await self.safe_cancel_task("game_timer", self.game_timer_task)
                    
                self.game_timer_task = asyncio.create_task(self.start_game_timer())
                await self.highrise.chat("♠️ Game timer restored. Take your actions!")
                
                # Check if all players are already done to proceed to dealer
                await self.check_all_players_done()
            else:
                # Check if we're in a game state but no timers are active
                if (len(self.current_table.get("dealer_hand", [])) >= 2 and 
                    any(len(player_data.get("player_hand", [])) >= 2 for player_data in self.current_table.get("players", {}).values())):
                    
                    # Game is in progress but no timer - check player statuses
                    all_players_done = True
                    for user_id, player_data in self.current_table.get("players", {}).items():
                        if player_data.get("status") == "active":
                            all_players_done = False
                            break
                    
                    if all_players_done:
                        await self.highrise.chat("♠️ All players have completed their turns. Dealer's turn...")
                        await self.dealer_play()
                    else:
                        self.current_table["game_in_progress"] = True
                        
                        # NEW: Cancel existing timer if any
                        if self.game_timer_task and not self.game_timer_task.done():
                            await self.safe_cancel_task("game_timer", self.game_timer_task)
                            
                        self.game_timer_task = asyncio.create_task(self.start_game_timer())
                        await self.highrise.chat("♠️ Game resumed. Take your actions!")
            
            # NEW: Reset initialization flag
            self.table_initializing = False
            
        except Exception as e:
            print(f"Error recovering game state: {e}")
            traceback.print_exc()
            # If recovery fails, reset the table and refund players
            self.table_initializing = False
            await self.emergency_table_reset()
    
    async def check_recovery_completion(self):
        """Check if all players are complete after recovery."""
        try:
            all_complete = True
            for user_id, player_data in self.current_table.get("players", {}).items():
                if player_data.get("status") not in ["complete", "busted"]:
                    all_complete = False
                    break
            
            if all_complete:
                print(f"DEBUG: All players complete after recovery")
                # Cancel any running timers
                if self.game_timer_task and not self.game_timer_task.done():
                    await self.safe_cancel_task("game_timer", self.game_timer_task)
                if self.betting_timer_task and not self.betting_timer_task.done():
                    await self.safe_cancel_task("betting_timer", self.betting_timer_task)
                
                # Short delay then reset
                try:
                    await asyncio.sleep(2)
                except asyncio.CancelledError:
                    return
                await self.reset_table()
        except Exception as e:
            print(f"Error in check_recovery_completion: {e}")
    
    async def emergency_table_reset(self):
        """Emergency reset of table with player refunds."""
        try:
            # Refund all active bets
            for user_id, player_data in self.current_table.get("players", {}).items():
                username = player_data.get("username")
                bet_amount = player_data.get("bet_amount", 0)
                if username and bet_amount > 0 and username in wallet:
                    wallet[username]["chips"] += bet_amount
                    await self.highrise.send_whisper(user_id, f"Emergency refund: {bet_amount} chips returned due to game recovery failure.")
            
            # Reset table
            self.current_table = {
                "active": False,
                "players": {},
                "bet_timer_active": False,
                "game_timer_active": False,
                "dealer_hand": [],
                "dealer_value": 0,
                "dealer_blackjack": False,
                "drawing": False,
                "game_in_progress": False
            }
            self.drawing = False
            table.update(self.current_table)
            await self.highrise.chat("♠️ Table reset due to recovery issues. Place new bets with !bet")
            
        except Exception as e:
            print(f"Error in emergency table reset: {e}")
    
    async def invite_all(self, user):
        if not user.username in owners:
            await self.highrise.send_whisper(user.id, "You cant use this command.")
            return
        if not urls.get('room', None):
            await self.highrise.send_whisper(user.id, "Please set the invite link first by !in <room invite link>")
        try:
            for user_id in ids:
                message_id = f"1_on_1:{user_id}:{self.bot_id}"
                try:
                    await self.highrise.send_message(
                message_id,
                message_type="invite",
                content="Join this room!", 
                room_id=urls.get('room', None))
                    try:
                        await asyncio.sleep(0.5)
                    except asyncio.CancelledError:
                        return
                except:
                    continue
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"error: {e}")
    
    async def set_bot(self, user):
        if not user.username in owners:
            return
        try:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                        bot_location["x"] = pos.x
                        bot_location["y"] = pos.y
                        bot_location["z"] = pos.z
                        bot_location["facing"] = pos.facing
                        await self.highrise.send_whisper(user.id, f"Bot location set to {bot_location}")
                        break
            await self.highrise.walk_to(Position(**bot_location))       
        except Exception as e:
            print("Set bot:", e)
    
    async def bot_wallet(self, user):
        if user.username in owners:
            wallet_balance = await self.highrise.get_wallet()
            for item in wallet_balance.content:
                if item.type == "gold":
                    gold = item.amount
                    await self.highrise.send_whisper(user.id, f"Sir, My current balance is {gold} gold!")
                    return
            await self.highrise.send_whisper(user.id, f"Hello, {user.username}! I don't have any gold.")
        else:
            await self.highrise.send_whisper(user.id, "You don't have access to this command")
    
    async def on_chat(self, user: User, message: str) -> None:
        if message == "!reset" and user.username in owners:
            table = {}
            await self.highrise.chat(f"Table reseted by {user.username}")
        if message.startswith("!users") and user.username in owners:
            try:
                users = len(ids)
                await self.highrise.send_whisper(user.id, f"There are total {users}. Type !invite to invite them.")
            except:
                pass

        if message.startswith("!addall") and user.username in owners:
            try:
                room_users = (await self.highrise.get_room_users()).content
                users_only = [
                u for u, _ in room_users
                if u.id != user.id and u.id != self.bot_id and u.id not in ids
            ]
                fee = 2
                total_cost = (fee) * len(users_only)
                bot_balance = (await self.highrise.get_wallet()).content[0].amount
                if bot_balance < total_cost:
                    await self.highrise.send_whisper(user.id, f"Not enough gold. Need {total_cost}g (incl. fees).")
                    return

                for recipient in users_only:
                    await self.highrise.tip_user(recipient.id, 'gold_bar_1')
                    ids.append(recipient.id)
                message = f"Added {len(users_only)} new users!" if len(users_only) > 0 else "No unique player to be added."
                await self.highrise.send_whisper(user.id, message)
            except:
                pass
        
        if message.startswith("!in "):
            if user.username != self.ownername:
                if user.username != "HAR1ZZ":
                    return
            try:
                url = message.split("!in ")[1]
                room_id = url.split("room?id=")[1].split("&")[0]
                urls['room'] = room_id
                await self.highrise.send_whisper(user.id, f"invite for room id set to {url}")
            except:
                pass

        if message.startswith("!invite"):
            try:
                await self.invite_all(user)
            except Exception as e:
                await self.highrise.send_whisper(user.id, f"Issue: {e}")
        
        if message.startswith("!rem ") and (user.username in owners or user.username == self.ownername):
            try:
                remvip = message.split(" ", 1)[1]
                rem = remvip.replace("@", "")
                if rem in owners:
                    owners.remove(rem)
                    await self.highrise.chat(f"{remvip} removed from ownerz.")
                else:
                    await self.highrise.send_whisper(user.id, f"{rem} not in ownerz.")
            except:
                pass

        if message.startswith("!add ") and (user.username in owners or user.username == self.ownername):
            try:
                vip = message.split(" ", 1)[1]
                allowed = vip.replace("@", "")
                if allowed not in owners:
                    owners.append(allowed)
                    await self.highrise.chat(f"{vip} added to ownerz.")
                else:
                    await self.highrise.chat(f"{vip} already in ownerz.")
            except:
                await self.highrise.send_whisper(user.id, "Nuh uh")
        cmd = message.lower().split()[0] if message else ""
        try:
            # FIX: Prevent game commands when it's dealer's turn or game is not active
            if cmd in ("!stay", "!stand", "!s", "!h", "!hit", "!d", "!double"):
                # Check if dealer is currently playing
                if self.drawing and self.current_table.get("game_in_progress"):
                    # Dealer is playing - don't allow player actions
                    await self.highrise.send_whisper(user.id, "Please wait for dealer's turn to complete.")
                    return
                if self.drawing:
                    await self.highrise.send_whisper(user.id, "Please wait...")
                    return
                    
            if cmd in ("!bet", "!b"):
                if self.drawing:
                    await self.highrise.send_whisper(user.id, "Please wait...")
                    return
                    
            if cmd.startswith("!copy"):
                await self.copy_outfit(user, message)
            if cmd == "!bank":
                await self.bot_wallet(user)
            if cmd == "!restart":
                await self.restart_bot(user)
            if cmd == "/set":
                await self.set_bot(user)
            if cmd == "!help":
                await self.show_help(user)
            if cmd == "!daily":
                await self.handle_daily(user)
            if cmd == "!rank":
                await self.show_rank(user)
            if cmd == "!resources":
                await self.show_resources(user)
            if cmd == "!rules":
                await self.show_rules(user)
            if cmd == "!terms":
                await self.show_terms(user)
            if cmd == "!info":
                await self.show_info(user)
            elif cmd.startswith("!b") and len(message.split()) > 1:
                await self.handle_bet_command(user, message.split()[1:])
            elif cmd.startswith("!h"):
                await self.handle_hit_command(user)
            elif cmd.startswith("!s"):
                await self.handle_stand_command(user)
            elif cmd.startswith("!d"):
                await self.handle_double_command(user)
            elif cmd == "!bal":
                await self.show_balance(user)
            elif cmd == "!cash" and len(message.split()) > 1:
                await self.handle_withdraw(user, message)
            elif cmd == "!leaderboard":
                await self.show_leaderboard(user)
            elif cmd.startswith("!winner"):
                await self.show_recent_winners(user)
            elif cmd == "!bonus":
                await self.handle_bonus_command(user)
            elif cmd == "!rm":
                await self.handle_remaining_bonus_command(user)
            elif cmd.startswith("!give"):
                await self.handle_give_command(user, message)
        except Exception as e:
            print(f"Command error: {e}")
            await self.highrise.send_whisper(user.id, "Error processing command")

    async def on_tip(self, sender: User, receiver: User, tip: CurrencyItem) -> None:
        if receiver.id != self.bot_id:
            return
        if sender.id not in ids: ids.append(sender.id)
        username = sender.username
        if username not in wallet:
            wallet[username] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
            casino['total_players'] += 1
            
        chips = tip.amount
        wallet[username]["chips"] += chips
        try:
            await self.highrise.send_whisper(sender.id, f"You received [{chips} Balance]")
        except:pass
        
    def has_active_game(self, user_id: str) -> bool:
        """Check if a user has an active game."""
        return user_id in self.current_table["players"] and self.current_table["players"][user_id]["status"] != "complete"
    
    def calculate_hand_value(self, hand: List[Card], hide: bool = False) -> Tuple[int, bool]:
        """Calculate hand value following classic blackjack rules."""
        value = 0
        num_aces = 0

        # If hide is True and hand has more than one card, only consider the first card
        cards_to_evaluate = hand[:1] if hide and len(hand) > 1 else hand

        for card in cards_to_evaluate:
            # Ensure card is a Card object - convert if needed
            if isinstance(card, dict):
                # Convert dict to Card object
                card = Card.from_dict(card)
            
            if hasattr(card, 'get_blackjack_value'):
                val = card.get_blackjack_value()
            else:
                # Skip invalid cards
                print(f"Warning: Invalid card in hand: {card}")
                continue
                
            if val == 11:
                num_aces += 1
            value += val

        # Adjust for aces if over 21
        while value > 21 and num_aces:
            value -= 10
            num_aces -= 1

        # True blackjack only if exactly 21 with 2 cards (A + 10-value card)
        # First ensure we have Card objects
        if not hide and len(hand) >= 2:
            card1 = hand[0]
            card2 = hand[1]
            
            # Convert to Card objects if needed
            if isinstance(card1, dict):
                card1 = Card.from_dict(card1)
            if isinstance(card2, dict):
                card2 = Card.from_dict(card2)
            
            is_blackjack = (
                value == 21 and len(hand) == 2 and
                ((card1.value == 'A' and card2.value in ['10', 'J', 'Q', 'K']) or
                 (card2.value == 'A' and card1.value in ['10', 'J', 'Q', 'K']))
            )
        else:
            is_blackjack = False

        return value, is_blackjack

    def format_hand(self, hand: List[Card], hide_second_card: bool = False) -> str:
        """Format a hand as a string for display."""
        if hide_second_card and len(hand) > 1:
            # Handle the first card which might be a dict or Card object
            first_card = hand[0]
            if isinstance(first_card, dict):
                first_card = Card.from_dict(first_card)
            return f"[{first_card}]"
        
        formatted_cards = []
        for card in hand:
            # Convert to Card object if needed
            if isinstance(card, dict):
                card = Card.from_dict(card)
            
            if hasattr(card, 'suit') and hasattr(card, 'value'):
                # It's already a Card object
                formatted_cards.append(f"[{card}]")
            elif isinstance(card, dict) and 'suit' in card and 'value' in card:
                # It's a serialized card dict
                card_obj = Card(card["suit"], card["value"])
                formatted_cards.append(f"[{card_obj}]")
            else:
                # Fallback for unknown formats
                formatted_cards.append("[?]")
        return " ".join(formatted_cards)
    
    def get_dealer_decision(self, dealer_hand: List[Card]) -> str:
        """Dealer decision with 60% advantage using intelligent deck knowledge."""
        # Ensure cards are Card objects
        processed_hand = []
        for card in dealer_hand:
            if isinstance(card, dict):
                processed_hand.append(Card.from_dict(card))
            else:
                processed_hand.append(card)
        
        dealer_value, _ = self.calculate_hand_value(processed_hand)
        
        # Update deck game state
        self.deck.update_game_state({
            'dealer_value': dealer_value,
            'cards_remaining': len(self.deck.cards) - self.deck.card_index
        })
        
        # Standard visible rules
        if dealer_value >= 17:
            return "stand"
        
        # Always hit on lower values (standard)
        return "hit"

    def determine_winner_classic(self, player_hand: List[Card], dealer_hand: List[Card], has_bonus: bool = False) -> str:
        """Determine winner following classic blackjack rules - APPEARS 100% FAIR."""
        # Ensure hands have Card objects
        player_hand_processed = []
        for card in player_hand:
            if isinstance(card, dict):
                player_hand_processed.append(Card.from_dict(card))
            else:
                player_hand_processed.append(card)
        
        dealer_hand_processed = []
        for card in dealer_hand:
            if isinstance(card, dict):
                dealer_hand_processed.append(Card.from_dict(card))
            else:
                dealer_hand_processed.append(card)
        
        player_value, player_blackjack = self.calculate_hand_value(player_hand_processed)
        dealer_value, dealer_blackjack = self.calculate_hand_value(dealer_hand_processed)
        
        # Debug output
        print(f"DEBUG: Player value: {player_value}, Dealer value: {dealer_value}")
        print(f"DEBUG: Player blackjack: {player_blackjack}, Dealer blackjack: {dealer_blackjack}")
        
        # NEVER manipulate these outcomes - would be obvious cheating
        if player_blackjack and not dealer_blackjack:
            print(f"DEBUG: Player has blackjack, dealer doesn't -> player_blackjack")
            return "player_blackjack"
        elif dealer_blackjack and not player_blackjack:
            print(f"DEBUG: Dealer has blackjack, player doesn't -> dealer_blackjack")
            return "dealer_blackjack"
        elif player_blackjack and dealer_blackjack:
            print(f"DEBUG: Both have blackjack -> push")
            return "push"
        
        # Bust cases (also never manipulated)
        if player_value > 21:
            print(f"DEBUG: Player bust with {player_value} -> dealer")
            return "dealer"
        elif dealer_value > 21:
            print(f"DEBUG: Dealer bust with {dealer_value} -> player")
            return "player"
        
        # Normal comparison (appears fair, advantage comes from card sequencing)
        if player_value > dealer_value:
            print(f"DEBUG: Player {player_value} > Dealer {dealer_value} -> player")
            return "player"
        elif dealer_value > player_value:
            print(f"DEBUG: Dealer {dealer_value} > Player {player_value} -> dealer")
            return "dealer"
        else:
            print(f"DEBUG: Player {player_value} == Dealer {dealer_value} -> push")
            return "push"  # Never manipulate pushes
        
    async def handle_bet_command(self, user: User, args: List[str]) -> None:
        """Handle the !bet command with table-based betting system."""
        username = user.username
        user_id = user.id

        # Prevent multiple concurrent bet commands
        if self.table_initializing:
            await self.highrise.send_whisper(user.id, "Table is initializing, please wait...")
            return

        # FIXED: Remove the automatic reset that was causing issues
        # Check if table is active but game is in progress
        if self.current_table['active'] and self.current_table.get("game_in_progress"):
            await self.highrise.send_whisper(user.id, "Game already in progress. Please wait for next round.")
            return

        # Check if table is active but betting timer is not running
        if self.current_table['active'] and not self.current_table.get('bet_timer_active'):
            # Game hasn't started yet, allow joining
            if not self.current_table.get("game_in_progress"):
                # Table is waiting for players, allow this player to join
                pass  # Continue with normal betting process
            else:
                await self.highrise.send_whisper(user.id, "Please wait for the next round.")
                return

        if self.drawing:
            await self.highrise.send_whisper(user.id, "Please wait...")
            return

        if not args:
            await self.highrise.send_whisper(user_id, "Please specify a bet amount between 10 and 10000 chips.")
            return

        try:
            bet_amount = int(args[0])
        except ValueError:
            await self.highrise.send_whisper(user_id, "Bet amount must be an integer number.")
            return

        if bet_amount < 10 or bet_amount > 10000:
            await self.highrise.send_whisper(user_id, "Bet amount must be between 10 and 10000 chips.")
            return

        if username not in wallet:
            wallet[username] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
            casino['total_players'] += 1

        # Check if player is already on the table (BET INCREASE)
        if user_id in self.current_table["players"]:
            if not self.current_table.get("bet_timer_active"):
                return

            # Check if player already has cards
            if len(self.current_table["players"][user_id].get("player_hand", [])) > 0:
                await self.highrise.send_whisper(user.id, "Cannot increase bet after cards are dealt.")
                return

            player_data = self.current_table["players"][user_id]
            current_bet = player_data["bet_amount"]

            # Check if trying to decrease bet (not allowed)
            if bet_amount < 0:
                await self.highrise.send_whisper(user.id, f"You can only increase your bet.")
                return

            # Check if player has sufficient balance for increased bet (unless owner)
            increase_amount = bet_amount
            if username not in owners:
                if wallet[username]["chips"] <= increase_amount:
                    await self.highrise.send_whisper(user.id, f"Insufficient chips.")
                    return

            # Increase the bet amount
            if username not in owners:
                wallet[username]["chips"] -= increase_amount
            wallet[username]["total_wagered"] += increase_amount
            casino['total_bets'] += increase_amount

            player_data["bet_amount"] += bet_amount
            indicator = self.get_indicator(username)
            await self.highrise.chat(f"{indicator}@{username} increased bet to [{player_data['bet_amount']} chips]")
            await self.save_table_state()
            return

        # NEW PLAYER JOINING - Check if table is full
        if len(self.current_table["players"]) >= 15:
            await self.highrise.send_whisper(user_id, "Table is full! Please wait for the next game.")
            return

        # Check balance for new player (unless owner)
        if username not in owners and wallet[username]["chips"] < bet_amount:
            await self.highrise.chat(f"@{username}, you don't have enough chips.")
            await self.highrise.send_whisper(user_id, f"Your balance: {wallet[username]['chips']} chips")
            return

        # Deduct bet immediately (only for non-owners)
        if username not in owners:
            wallet[username]["chips"] -= bet_amount
            wallet[username]["total_wagered"] += bet_amount
            casino['total_bets'] += bet_amount

        # Add player to the table
        self.current_table["players"][user_id] = {
            "username": username,
            "bet_amount": bet_amount,
            "player_hand": [],
            "status": "waiting",  # waiting, active, busted, stood, complete
            "doubled": False,
            "has_bonus": self.check_active_bonus(username)
        }

        # If table is NOT active, start a new game
        if not self.current_table["active"]:
            async with self.TABLE_INIT_LOCK:
                # Double-check after acquiring lock
                if self.current_table["active"]:
                    # Another thread already activated the table
                    indicator = self.get_indicator(username)
                    await self.highrise.chat(f"{indicator}@{username} joined with [{bet_amount} chips]")
                    await self.save_table_state()
                    return

                self.table_initializing = True
                try:
                    # Start a new table
                    self.current_table["active"] = True
                    self.current_table["dealer_hand"] = [self.deck.deal(), self.deck.deal()]

                    indicator = self.get_indicator(username)
                    await self.highrise.chat(f"{indicator}@{username} joined with [{bet_amount} chips]")

                    try:
                        await asyncio.sleep(1.5)
                    except asyncio.CancelledError:
                        return

                    await self.highrise.chat(f"♠️ Game starting.. [⏳ 15 seconds]")

                    # IMPORTANT: Save table state BEFORE starting timer
                    await self.save_table_state()

                    # Cancel any existing timer before starting new one
                    if self.betting_timer_task and not self.betting_timer_task.done():
                        await self.safe_cancel_task("betting_timer", self.betting_timer_task)

                    self.betting_timer_task = asyncio.create_task(self.start_betting_timer())
                finally:
                    self.table_initializing = False
        else:
            # Table is already active, just add the player
            indicator = self.get_indicator(username)
            await self.highrise.chat(f"{indicator}@{username} joined with [{bet_amount} chips]")
            await self.save_table_state()

    async def start_betting_timer(self):
        try:
            # Check if we should start a timer
            if not self.current_table.get("active"):
                print("DEBUG: Table not active, not starting betting timer")
                return

            if not self.current_table.get("players"):
                print("DEBUG: No players, not starting betting timer")
                # Clean up the table if no players
                self.current_table["active"] = False
                await self.save_table_state()
                await self.highrise.chat("No players on table. Table closed.")
                return

            # Check if timer is already running
            if self.current_table.get("bet_timer_active"):
                print("DEBUG: Betting timer already active")
                return

            self.current_table["bet_timer_active"] = True
            table["bet_timer_active"] = True
            await self.save_table_state()
            await asyncio.sleep(15)

            # Check if we're still in a valid state
            if not self.current_table.get("active"):
                print("DEBUG: Table became inactive during betting timer")
                self.current_table["bet_timer_active"] = False
                table["bet_timer_active"] = False
                await self.save_table_state()
                return

            # Check if we still have players
            if not self.current_table.get("players"):
                print("DEBUG: No players left when betting timer completed")
                self.current_table["bet_timer_active"] = False
                table["bet_timer_active"] = False
                self.current_table["active"] = False
                await self.save_table_state()
                await self.highrise.chat("No players on table. Table closed.")
                return

            self.drawing = True
            self.current_table["drawing"] = True
            table["drawing"] = True
            self.current_table["bet_timer_active"] = False
            table["bet_timer_active"] = False
            await self.highrise.chat("♠️ Drawing cards...")
            await self.save_table_state()
            await self.start_game_for_table()

        except asyncio.CancelledError:
            # Timer was cancelled - clean up
            self.current_table["bet_timer_active"] = False
            table["bet_timer_active"] = False
            await self.save_table_state()
            raise

        except Exception as e:
            print(f"Error in betting timer: {e}")
            traceback.print_exc()
            # Ensure cleanup on error
            self.current_table["bet_timer_active"] = False
            table["bet_timer_active"] = False
            await self.save_table_state()

    async def start_game_for_table(self):
        try:
            await asyncio.sleep(0.5)
        except asyncio.CancelledError:
            return

        try:
            # Check if table is still active
            if not self.current_table.get("active"):
                print("DEBUG: Table not active in start_game_for_table")
                return

            # Check if we have players
            if not self.current_table.get("players"):
                print("DEBUG: No players found in start_game_for_table")
                await self.highrise.chat("No players joined the table.")
                # Don't reset, just set inactive
                self.current_table["active"] = False
                await self.save_table_state()
                return

            casino['games_played'] += 1

            # Deal initial cards to all players with subtle disadvantage
            dealer_hand = self.current_table["dealer_hand"]
            value, _ = self.calculate_hand_value(dealer_hand)
            hide = True if value < 21 else False
            dealer_value, dealer_blackjack = self.calculate_hand_value(dealer_hand, hide=hide)
            self.current_table["dealer_value"] = dealer_value
            self.current_table["dealer_blackjack"] = dealer_blackjack

            print(f"DEBUG: Dealer hand value: {dealer_value}, Blackjack: {dealer_blackjack}")

            # Check if ALL players have immediate blackjack outcomes
            all_players_immediate = True
            immediate_resolutions = []

            for user_id, player_data in self.current_table["players"].items():
                # Only deal cards if player doesn't have them already (for recovery)
                if not player_data.get("player_hand") or len(player_data["player_hand"]) == 0:
                    # Deal cards with subtle 60% disadvantage for players
                    first_card = self.deck.deal("neutral")

                    # Update deck state for intelligent second card dealing
                    self.deck.update_game_state({
                        'player_first_card': first_card.get_blackjack_value(),
                        'player_value': 0
                    })

                    second_card = self.deck.deal("player_initial")
                    player_data["player_hand"] = [first_card, second_card]

                player_value, player_blackjack = self.calculate_hand_value(player_data["player_hand"])

                await self.highrise.chat(
                    f"@{player_data['username']} {self.format_hand(player_data['player_hand'])} = [{player_value}]"
                )

                # Check for immediate blackjack
                if player_blackjack or dealer_blackjack:
                    player_data["status"] = "waiting_resolution"
                    immediate_resolutions.append((user_id, player_data, player_blackjack))
                    print(f"DEBUG: {player_data['username']} has immediate blackjack situation")
                else:
                    player_data["status"] = "active"
                    all_players_immediate = False

                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return

            if not hide:
                await self.highrise.chat(f"[🎲] Dealer: {self.format_hand(dealer_hand, hide_second_card=hide)} = [{dealer_value}]")
            message = "[🃏] Dealer has Blackjack!" if not hide else f"[🎲] Dealer: {self.format_hand(dealer_hand, hide_second_card=hide)} = [{dealer_value}]"
            await self.highrise.chat(message)

            # If all players have immediate outcomes, resolve immediately
            if all_players_immediate:
                print(f"DEBUG: All players have immediate blackjack outcomes")
                try:
                    await asyncio.sleep(2)  # Give time for messages to display
                except asyncio.CancelledError:
                    return

                for user_id, player_data, player_blackjack in immediate_resolutions:
                    await self.resolve_immediate_blackjack(user_id, player_data, dealer_hand, dealer_value, player_blackjack, dealer_blackjack)

                # Reset drawing state immediately after blackjack resolution
                self.drawing = False
                self.current_table["drawing"] = False
                self.current_table["game_in_progress"] = False
                await self.save_table_state()

                # Check if all players are complete
                all_complete = all(pdata["status"] == "complete" for pdata in self.current_table["players"].values())
                if all_complete:
                    try:
                        await asyncio.sleep(2)
                    except asyncio.CancelledError:
                        return
                    await self.reset_table()
            else:
                await self.highrise.chat(f"♠️ Type !hit, !stand, !double [⏳ 45 seconds]")
                self.drawing = False
                self.current_table["drawing"] = False
                self.current_table["game_in_progress"] = True

                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return

                # Start game timer for player actions
                await self.save_table_state()

                # Cancel any existing game timer first
                if self.game_timer_task and not self.game_timer_task.done():
                    await self.safe_cancel_task("game_timer", self.game_timer_task)

                self.game_timer_task = asyncio.create_task(self.start_game_timer())

        except Exception as e:
            print(f"ERROR in start_game_for_table: {e}")
            traceback.print_exc()
            await self.highrise.chat("Error starting game. Please try again.")
            # Don't reset table on error

    async def start_game_timer(self):
        try:
            self.current_table["game_timer_active"] = True
            table["game_timer_active"] = True
            await self.save_table_state()
            await asyncio.sleep(45)

            if self.current_table["game_timer_active"]:  # Check if still active
                await self.highrise.chat("[🎲] Dealer's turn.")
                self.current_table["game_timer_active"] = False
                table["game_timer_active"] = False
                await self.save_table_state()
                await self.dealer_play()

        except asyncio.CancelledError:
            # Timer was cancelled - clean up
            self.current_table["game_timer_active"] = False
            table["game_timer_active"] = False
            await self.save_table_state()
            raise

        except Exception as e:
            print(f"Error in game timer: {e}")
            traceback.print_exc()


    async def resolve_immediate_blackjack(self, user_id, player_data, dealer_hand, dealer_value, player_blackjack, dealer_blackjack):
        username = player_data["username"]
        bet_amount = player_data["bet_amount"]
        
        print(f"DEBUG: Resolving immediate blackjack for {username}")
        print(f"DEBUG: Player blackjack: {player_blackjack}, Dealer blackjack: {dealer_blackjack}")
        print(f"DEBUG: Bet amount: {bet_amount}")
        
        if self.drawing:
            try:
                await asyncio.sleep(3.5)
            except asyncio.CancelledError:
                return
        
        if player_blackjack and not dealer_blackjack:
            winnings = int(bet_amount * 2.5)
            wallet[username]["chips"] += winnings
            wallet[username]["wins"] += 1
            wallet[username]["total_won"] += winnings
            casino['total_wins'] += winnings

            if len(casino['recent_winners']) >= 10:
                casino['recent_winners'].pop(0)
            casino['recent_winners'].append((username, winnings, datetime.now().isoformat()))

            await self.highrise.chat(f"[🃏] @{username} has Blackjack!")
            try:
                await asyncio.sleep(1.5)
            except asyncio.CancelledError:
                return
            await self.highrise.chat(f"@{username} wins {winnings} chips! (Blackjack pays 3:2)")
            player_data["status"] = "complete"
            
        elif dealer_blackjack and not player_blackjack:
            wallet[username]["losses"] += 1
            await self.highrise.chat(f"@{username} loses to dealer Blackjack.")
            try:
                await asyncio.sleep(1.5)
            except asyncio.CancelledError:
                return
            await self.highrise.chat(f"@{username} loses {bet_amount} chips.")
            player_data["status"] = "complete"
            
        else:  # Both have blackjack (push)
            wallet[username]["chips"] += bet_amount
            await self.highrise.chat(f"[🃏] @{username} has Blackjack!")
            try:
                await asyncio.sleep(1)
            except asyncio.CancelledError:
                return
            await self.highrise.chat(f"@{username} gets back {bet_amount} chips. (Push)")
            player_data["status"] = "complete"
        
        # Check if ALL players are done (not just this one)
        all_players_done = True
        for uid, pdata in self.current_table["players"].items():
            if pdata["status"] not in ["complete", "busted"]:
                all_players_done = False
                break
        
        print(f"DEBUG: All players done? {all_players_done}")
        
        if all_players_done:
            # Cancel the game timer since the game is already over
            if self.current_table.get("game_timer_active"):
                self.current_table["game_timer_active"] = False
                table["game_timer_active"] = False
                if self.game_timer_task and not self.game_timer_task.done():
                    await self.safe_cancel_task("game_timer", self.game_timer_task)
            
            # Reset drawing state immediately
            self.drawing = False
            self.current_table["drawing"] = False
            self.current_table["game_in_progress"] = False
            
            await self.save_table_state()
            # Reset the table after short delay
            try:
                await asyncio.sleep(1.5)
            except asyncio.CancelledError:
                return
            await self.reset_table()
        
    async def handle_hit_command(self, user: User) -> None:
        """Handle the !hit command with 60% dealer advantage."""
        username = user.username
        user_id = user.id

        if user_id not in self.current_table["players"] or self.current_table["players"][user_id]["status"] != "active":
            message = "Please wait.." if len(self.current_table["players"]) >=1 else "You're not in game, Type !bet 10"
            await self.highrise.send_whisper(user_id, message)
            return

        player_data = self.current_table["players"][user_id]

        if player_data["doubled"]:
            await self.highrise.send_whisper(user_id, "You cannot hit after doubling down.")
            return

        # Update deck state for intelligent card dealing
        current_player_value, _ = self.calculate_hand_value(player_data["player_hand"])
        self.deck.update_game_state({
            'player_value': current_player_value,
            'dealer_value': self.current_table["dealer_value"]
        })

        # Deal a card with 60% dealer advantage
        new_card = self.deck.deal("player_hit")
        player_data["player_hand"].append(new_card)
        player_value, _ = self.calculate_hand_value(player_data["player_hand"])

        # Display updated hand
        player_show = self.format_hand(player_data["player_hand"])

        bonus_indicator = self.get_indicator(username)
        
        message = f"{bonus_indicator}@{username} | B | {player_show} = [{player_value}]" if player_value > 21 else f"{bonus_indicator}@{username} | {player_show} = [{player_value}]"
        if player_value == 21:
            message = f"{bonus_indicator}@{username} | S | {player_show} = [{player_value}]"
        await self.highrise.chat(
            message
        )
        if player_value > 21:
            player_data["status"] = "busted"
            wallet[username]["losses"] += 1
        elif player_value == 21:
            player_data["status"] = "stood"
        try:
            await asyncio.sleep(1.5)
        except asyncio.CancelledError:
            return
        await self.save_table_state()
        await self.check_all_players_done()

    async def handle_stand_command(self, user: User) -> None:
        """Handle the !stand command to stay."""
        username = user.username
        user_id = user.id

        if user_id not in self.current_table["players"] or self.current_table["players"][user_id]["status"] != "active":
            message = "Please wait.." if len(self.current_table["players"]) >=1 else "You're not in game, Type !bet 10"
            await self.highrise.send_whisper(user_id, message)
            return

        player_data = self.current_table["players"][user_id]
        player_data["status"] = "stood"
        bonus_indicator = self.get_indicator(username)
        await self.highrise.chat(f"{bonus_indicator}@{username} | S | {self.format_hand(player_data['player_hand'])} = [{self.calculate_hand_value(player_data['player_hand'])[0]}]")
        await self.save_table_state()
        await self.check_all_players_done()

    async def handle_double_command(self, user: User) -> None:
        """Handle the !double command to double down."""
        username = user.username
        user_id = user.id

        if user_id not in self.current_table["players"] or self.current_table["players"][user_id]["status"] != "active":
            message = "Please wait.." if len(self.current_table["players"]) >=1 else "You're not in game, Type !bet 10"
            await self.highrise.send_whisper(user_id, message)
            return

        player_data = self.current_table["players"][user_id]
        bet_amount = player_data["bet_amount"]

        if len(player_data["player_hand"]) != 2:
            await self.highrise.send_whisper(user_id, "You can only double down on your first two cards.")
            return

        if wallet[username]["chips"] < bet_amount:
            if username not in owners:
                await self.highrise.send_whisper(user_id,"You don't have enough chips to double down.")
                await self.highrise.send_whisper(user_id, f"Your balance: {wallet[username]['chips']} chips")
                return

        # Deduct second bet
        if username not in owners:
            wallet[username]["chips"] -= bet_amount
        wallet[username]["total_wagered"] += bet_amount
        casino['total_bets'] += bet_amount

        player_data["bet_amount"] *= 2
        player_data["doubled"] = True

        # Update deck state
        current_player_value, _ = self.calculate_hand_value(player_data["player_hand"])
        self.deck.update_game_state({
            'player_value': current_player_value,
            'dealer_value': self.current_table["dealer_value"]
        })

        # Deal one card with 60% dealer advantage
        new_card = self.deck.deal("player_hit")
        player_data["player_hand"].append(new_card)
        player_value, _ = self.calculate_hand_value(player_data["player_hand"])

        player_show = self.format_hand(player_data["player_hand"])
        bonus_indicator = self.get_indicator(username)
        message = f"{bonus_indicator}@{username} | S | {player_show} = [{player_value}]" if player_value <= 21 else f"{bonus_indicator}@{username} | B | {player_show} = [{player_value}]"
        await self.highrise.chat(
            message
        )

        if player_value > 21:
            player_data["status"] = "busted"
            wallet[username]["losses"] += 1
        else:
            player_data["status"] = "stood"
        await self.save_table_state()
        await self.check_all_players_done()

    async def check_all_players_done(self):
        """Check if all players have completed their turns."""
        # Check if all active players are done (busted, stood, or complete)
        all_done = True
        for user_id, player_data in self.current_table["players"].items():
            if player_data["status"] == "active":
                all_done = False
                break
    
        if all_done:
            if self.current_table.get("game_timer_active"):
                self.current_table["game_timer_active"] = False
                table["game_timer_active"] = False
                if self.game_timer_task and not self.game_timer_task.done():
                    await self.safe_cancel_task("game_timer", self.game_timer_task)
                await self.save_table_state()
            await self.dealer_play()

    async def dealer_play(self):
        # Ensure dealer hand has Card objects
        dealer_hand = []
        for card in self.current_table["dealer_hand"]:
            if isinstance(card, dict):
                dealer_hand.append(Card.from_dict(card))
            else:
                dealer_hand.append(card)
        
        dealer_value, _ = self.calculate_hand_value(dealer_hand)
        while self.drawing: 
            try:
                await asyncio.sleep(1.5)
            except asyncio.CancelledError:
                return
        await self.highrise.chat(f"[🎲] Dealer: Hidden card revealed: {self.format_hand(dealer_hand).split()[1]}")
        try:
            await asyncio.sleep(1.5)
        except asyncio.CancelledError:
            return
        await self.highrise.chat(f"[🎲] Dealer: {self.format_hand(dealer_hand)} = [{dealer_value}]")

        # Dealer plays with 60% advantage using intelligent decisions
        while dealer_value < 17:
            try:
                await asyncio.sleep(1.5)
            except asyncio.CancelledError:
                return
            
            # Update deck state for intelligent card dealing
            self.deck.update_game_state({
                'dealer_value': dealer_value,
                'cards_remaining': len(self.deck.cards) - self.deck.card_index
            })
            
            # Get dealer decision with 60% advantage
            decision = self.get_dealer_decision(dealer_hand)
            
            if decision == "stand":
                await self.highrise.chat(f"[🎲] Dealer stands with [{dealer_value}]")
                break
            else:
                # Deal card with dealer advantage
                new_card = self.deck.deal("dealer_hit")
                dealer_hand.append(new_card)
                dealer_value, _ = self.calculate_hand_value(dealer_hand)
                
                message = f"[🎲] Dealer: | B | {self.format_hand(dealer_hand)} = [{dealer_value}]" if dealer_value > 21 else f"[🎲] Dealer: {self.format_hand(dealer_hand)} = [{dealer_value}]"
                await self.highrise.chat(message)
                
                # Update the table's dealer hand and value after each card
                self.current_table["dealer_hand"] = dealer_hand
                self.current_table["dealer_value"] = dealer_value
                await self.save_table_state()

        # Final update of the table's dealer hand and value
        self.current_table["dealer_hand"] = dealer_hand
        self.current_table["dealer_value"] = dealer_value
        await self.save_table_state()
        await self.resolve_all_games()

    def get_bonus_multiplier(self, player_hand: List[Card]) -> float:
        """Calculate bonus multiplier for matching number pairs only."""
        if len(player_hand) < 2:
            return 0.0
        
        # Ensure cards are Card objects
        processed_hand = []
        for card in player_hand:
            if isinstance(card, dict):
                processed_hand.append(Card.from_dict(card))
            else:
                processed_hand.append(card)
        
        # Check for pairs (same values only)
        values = [card.value for card in processed_hand]
        
        # Only give bonus for exact same card values
        if values[0] == values[1]:
            if values[0] in ["A", "K", "Q", "J"]:
                # High pair bonus - very rare
                return random.choices([0.5, 1.0, 1.5, 2.0, 2.5, 3.0], 
                            weights=[30, 25, 20, 15, 8, 2])[0]
            else:
                # Regular number pair bonus (2-2, 3-3, 4-4, etc.)
                return random.choices([0.5, 1.0, 1.5, 2.0], 
                            weights=[40, 35, 20, 5])[0]
        
        # No bonus for same suits or any other combinations
        return 0.0
        
    async def resolve_all_games(self):
        print(f"DEBUG: Resolving all games")

        # Ensure dealer hand has Card objects from the current table state
        dealer_hand = []
        for card in self.current_table["dealer_hand"]:
            if isinstance(card, dict):
                dealer_hand.append(Card.from_dict(card))
            else:
                dealer_hand.append(card)

        # Calculate the FINAL dealer value from the complete hand
        dealer_value = self.calculate_hand_value(dealer_hand)[0]
        print(f"DEBUG: FINAL Dealer hand value: {dealer_value}, Hand: {dealer_hand}")

        # NEW: Track all results to announce once
        results_by_player = {}

        for user_id, player_data in self.current_table["players"].items():
            # Only skip players who are already complete
            if player_data["status"] == "complete":
                continue

            username = player_data["username"]
            print(f"DEBUG: Resolving game for {username}")

            # Ensure player hand has Card objects
            player_hand = []
            for card in player_data["player_hand"]:
                if isinstance(card, dict):
                    player_hand.append(Card.from_dict(card))
                else:
                    player_hand.append(card)

            player_value = self.calculate_hand_value(player_hand)[0]
            bet_amount = player_data["bet_amount"]
            has_bonus = player_data["has_bonus"]

            print(f"DEBUG: {username} - Player value: {player_value}, Bet: {bet_amount}")

            bonus_multiplier = 0.0
            if has_bonus and len(player_hand) >= 2:
                bonus_multiplier = self.get_bonus_multiplier(player_hand)
                if bonus_multiplier > 0:
                    bonus_payout = int(bet_amount * bonus_multiplier)

            # Handle players who stood due to immediate blackjack
            if player_data["status"] == "stood":
                player_value, player_blackjack = self.calculate_hand_value(player_hand)
                dealer_value_calc, dealer_blackjack = self.calculate_hand_value(dealer_hand)

                if player_blackjack and not dealer_blackjack:
                    results_by_player[username] = {
                        "type": "blackjack_win",
                        "winnings": int(bet_amount * 2.5),
                        "bonus_payout": bonus_payout if bonus_multiplier > 0 else 0
                    }
                    player_data["status"] = "complete"
                    continue
                elif dealer_blackjack and not player_blackjack:
                    results_by_player[username] = {
                        "type": "dealer_blackjack_loss",
                        "loss": bet_amount,
                        "bonus_payout": bonus_payout if bonus_multiplier > 0 else 0
                    }
                    player_data["status"] = "complete"
                    continue
                elif player_blackjack and dealer_blackjack:
                    results_by_player[username] = {
                        "type": "push_blackjack",
                        "bet_returned": bet_amount,
                        "bonus_payout": bonus_payout if bonus_multiplier > 0 else 0
                    }
                    player_data["status"] = "complete"
                    continue

            # Normal resolution for non-blackjack cases
            result = self.determine_winner_classic(player_hand, dealer_hand, has_bonus)
            print(f"DEBUG: {username} - Game result: {result}")

            if result == "player":
                winnings = bet_amount * 2
                wallet[username]["chips"] += winnings
                wallet[username]["wins"] += 1
                wallet[username]["total_won"] += winnings
                casino['total_wins'] += winnings

                if len(casino['recent_winners']) >= 10:
                    casino['recent_winners'].pop(0)
                casino['recent_winners'].append((username, winnings, datetime.now().isoformat()))

                results_by_player[username] = {
                    "type": "win",
                    "winnings": winnings,
                    "player_value": player_value,
                    "bonus_payout": bonus_payout if bonus_multiplier > 0 else 0
                }

            elif result == "dealer":
                wallet[username]["losses"] += 1
                is_bust = player_data["status"] == "busted"
                results_by_player[username] = {
                    "type": "loss",
                    "loss": bet_amount,
                    "player_value": player_value,
                    "is_bust": is_bust,
                    "bonus_payout": bonus_payout if bonus_multiplier > 0 else 0
                }

            elif result == "push":
                wallet[username]["chips"] += bet_amount
                results_by_player[username] = {
                    "type": "push",
                    "bet_returned": bet_amount,
                    "player_value": player_value,
                    "bonus_payout": bonus_payout if bonus_multiplier > 0 else 0
                }

            elif result == "player_blackjack":
                winnings = int(bet_amount * 2.5)
                wallet[username]["chips"] += winnings
                wallet[username]["wins"] += 1
                wallet[username]["total_won"] += winnings
                casino['total_wins'] += winnings

                if len(casino['recent_winners']) >= 10:
                    casino['recent_winners'].pop(0)
                casino['recent_winners'].append((username, winnings, datetime.now().isoformat()))

                results_by_player[username] = {
                    "type": "blackjack_win",
                    "winnings": winnings,
                    "bonus_payout": bonus_payout if bonus_multiplier > 0 else 0
                }

            elif result == "dealer_blackjack":
                wallet[username]["losses"] += 1
                results_by_player[username] = {
                    "type": "dealer_blackjack_loss",
                    "loss": bet_amount,
                    "bonus_payout": bonus_payout if bonus_multiplier > 0 else 0
                }

            # Mark as complete after processing
            player_data["status"] = "complete"

        # NEW: Announce results once for all players
        for username, result_info in results_by_player.items():
            bonus_indicator = self.get_indicator(username)

            if result_info["type"] == "win":
                await self.highrise.chat(f"{bonus_indicator}@{username} you win with [{result_info['player_value']}]")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.chat(f"@{username} wins {result_info['winnings']} chips!")

            elif result_info["type"] == "loss":
                if result_info.get("is_bust", False):
                    await self.highrise.chat(f"@{username} went bust with [{result_info['player_value']}]")
                else:
                    await self.highrise.chat(f"@{username} you lose with [{result_info['player_value']}]")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.chat(f"@{username} loses {result_info['loss']} chips.")

            elif result_info["type"] == "push":
                await self.highrise.chat(f"@{username}, it's a push! [{result_info['player_value']}]")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.chat(f"@{username} gets back {result_info['bet_returned']} chips.")

            elif result_info["type"] == "blackjack_win":
                await self.highrise.chat(f"{bonus_indicator}@{username} Blackjack with 21!")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.chat(f"@{username} wins {result_info['winnings']} chips!")

            elif result_info["type"] == "dealer_blackjack_loss":
                await self.highrise.chat(f"@{username} loses to dealer Blackjack.")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.chat(f"@{username} loses {result_info['loss']} chips.")

            elif result_info["type"] == "push_blackjack":
                await self.highrise.chat(f"[🃏] @{username} has Blackjack!")
                try:
                    await asyncio.sleep(1)
                except asyncio.CancelledError:
                    return
                await self.highrise.chat(f"@{username} gets back {result_info['bet_returned']} chips. (Push)")

            # Bonus payout if applicable
            if result_info.get("bonus_payout", 0) > 0:
                wallet[username]["chips"] += result_info["bonus_payout"]
                await self.highrise.chat(f"[✨] @{username} got bonus! [{result_info['bonus_payout']} chips]")

            try:
                await asyncio.sleep(1.5)
            except asyncio.CancelledError:
                return

        await self.save_table_state()
        try:
            await asyncio.sleep(1.5)
        except asyncio.CancelledError:
            return
        await self.reset_table()
    
    async def reset_table(self):
        # Add debug logging
        print(f"DEBUG {datetime.now()}: reset_table() called")

        # Prevent double reset
        if not self.current_table.get("active"):
            print("DEBUG: Table already inactive, skipping reset")
            return

        async with BlackjackBot.LOCK:
            # Double-check after acquiring lock
            if not self.current_table.get("active"):
                return

            print(f"DEBUG {datetime.now()}: Actually resetting table")

            # Cancel any running timers
            await self.safe_cancel_task("betting_timer", self.betting_timer_task)
            await self.safe_cancel_task("game_timer", self.game_timer_task)

            # Only reset deck if it's running low
            if len(self.deck.cards) - self.deck.card_index <= 10:
                self.deck.reset()

            # Create new table state
            new_table_state = {
                "active": False,
                "players": {},
                "bet_timer_active": False,
                "game_timer_active": False,
                "dealer_hand": [],
                "dealer_value": 0,
                "dealer_blackjack": False,
                "drawing": False,
                "game_in_progress": False,
                "deck_state": self.deck.get_state()
            }

            # Update both local and global state atomically
            self.current_table = new_table_state
            self.drawing = False

            # ATOMIC update of persistent table
            table.clear()
            table.update(new_table_state)
            globals()['table'] = table

            try:
                await self.highrise.chat("♠️ Type !bet to start the game.")
            except Exception:
                pass  # Bot might be shutting down

    async def save_table_state(self):
        """Save current table state to persistent storage."""
        async with BlackjackBot.LOCK:  # CRITICAL: Make this atomic
            try:
                # Convert card objects to serializable format
                serializable_table = self.current_table.copy()

                # Serialize dealer hand
                dealer_hand = []
                for card in serializable_table.get("dealer_hand", []):
                    if hasattr(card, 'to_dict'):
                        dealer_hand.append(card.to_dict())
                    elif isinstance(card, dict):
                        dealer_hand.append(card)
                    else:
                        # If it's already a Card object but doesn't have to_dict
                        dealer_hand.append({"suit": card.suit, "value": card.value})
                serializable_table["dealer_hand"] = dealer_hand

                # Serialize player hands
                for user_id, player_data in serializable_table.get("players", {}).items():
                    if "player_hand" in player_data:
                        player_hand = []
                        for card in player_data["player_hand"]:
                            if hasattr(card, 'to_dict'):
                                player_hand.append(card.to_dict())
                            elif isinstance(card, dict):
                                player_hand.append(card)
                            else:
                                # If it's already a Card object but doesn't have to_dict
                                player_hand.append({"suit": card.suit, "value": card.value})
                        player_data["player_hand"] = player_hand

                # Save deck state
                serializable_table["deck_state"] = self.deck.get_state()

                # Update persistent table - ATOMIC OPERATION
                table.clear()
                table.update(serializable_table)

                # Also update the global table reference
                globals()['table'] = table

            except asyncio.CancelledError:
                # Don't save partial state if cancelled
                print("save_table_state cancelled - preserving previous state")
                raise
            except Exception as e:
                print(f"Error saving table state: {e}")
                traceback.print_exc()

    async def show_balance(self, user: User) -> None:
        """Show user's balance via whisper."""
        username = user.username
        if username not in wallet:
            wallet[username] = {
                "chips": 0,
                "wins": 0,
                "losses": 0,
                "last_login": datetime.now().isoformat(),
                "total_wagered": 0,
                "total_won": 0
            }
        await self.highrise.send_whisper(user.id, f"Your current balance: {wallet[username]['chips']} chips")

    async def handle_daily(self, user: User) -> None:
        try:
            await asyncio.sleep(1.5)
            tier = self.get_membership(user.username)
            if tier == "standard":
                await self.highrise.send_whisper(user.id, "You dont have any memberships spend more to get one.")
                return
            current_time = datetime.utcnow() 
            last_claim = wallet[user.username].get("last_daily")
            if last_claim:
                last_time = datetime.fromisoformat(last_claim)
                delta = current_time - last_time
                if delta < timedelta(hours=24):
                    # Too soon to claim again
                    remaining = timedelta(hours=24) - delta
                    hours = remaining.seconds // 3600
                    minutes = (remaining.seconds % 3600) // 60
                    await self.highrise.send_whisper(
                        user.id,
                        f"⏳ You can claim your next daily reward in {hours}h {minutes}m."
                    )
                    return
            wallet[user.username]["last_daily"] = current_time.isoformat()
            
            if tier == "gold":
                favor = random.random()
                if favor < 0.30:
                    bal = random.randint(40, 100)
                    wallet[user.username]['chips'] += bal
                    m = f"[👑] Congratulations you've got [{bal} Golds] in your balance."
                    await self.highrise.send_whisper(user.id, m)
                else:
                    m = "Better luck next time!"
                    await self.highrise.send_whisper(user.id, m)

            elif tier == "platinum":
                favor = random.random()
                if favor < 0.35:
                    bal = random.randint(50, 120)
                    wallet[user.username]['chips'] += bal
                    m = f"[💠] Congratulations you've got [{bal} Golds] in your balance."
                    await self.highrise.send_whisper(user.id, m)
                else:
                    m = "Better luck next time!"
                    await self.highrise.send_whisper(user.id, m)
                    
            elif tier == "diamond":
                favor = random.random()
                if favor < 0.40:
                    bal = random.randint(150, 200)
                    wallet[user.username]['chips'] += bal
                    m = f"[💎] Congratulations you've got [{bal} Golds] in your balance."
                    await self.highrise.send_whisper(user.id, m)
                else:
                    m = "Better luck next time!"
                    await self.highrise.send_whisper(user.id, m)
             
            elif tier == "noir":
                favor = random.random()
                if favor < 0.45:
                    bal = random.randint(150, 250)
                    wallet[user.username]['chips'] += bal
                    m = f"[🎩] Congratulations you've got [{bal} Golds] in your balance."
                    await self.highrise.send_whisper(user.id, m)
                else:
                    m = "Better luck next time!"
                    await self.highrise.send_whisper(user.id, m)
        except Exception as e: 
            print(e)
        
       # username => tier
    def get_membership(self, username: str) -> str:
        """Return membership tier based on indicator emoji."""
        indicator = self.get_indicator(username)
        if "[🎩]" in indicator:
            return "noir"
        elif "[💎]" in indicator:
            return "diamond"
        elif "[💠]" in indicator:
            return "platinum"
        elif "[👑]" in indicator:
            return "gold"
        else:
            return "standard"

    def get_indicator(self, username: str) -> str:
        """Get up to two indicator emojis based on user status and activity."""
        indicators = []

    # Sparkle for active bonus — always comes first
        if self.check_active_bonus(username):
            indicators.append("[✨]")

    # Get user data safely
        user_data = wallet.get(username, {})
        total_wagered = user_data.get("total_wagered", 0)

    # Highest tier first: Hat ≥ 800k
        if total_wagered >= 800_000:
            indicators.append("[🎩]")
        elif total_wagered >= 500_000:
            indicators.append("[💎]")
        elif total_wagered >= 250_000:
            indicators.append("[💠]")  # Replaced flower with 💠
        elif username in owners or total_wagered >= 100_000:
            indicators.append("[👑]")

    # Return up to 2 indicators with a space after the last one, or empty string
        return "".join(indicators[:2]) + (" " if indicators else "")


    async def handle_give_command(self, user: User, message: str) -> None:
        """Handle the !give command to send chips to another user."""
        try:
            args = message.split()
            if len(args) < 3:
                await self.highrise.send_whisper(user.id, "Usage: !give @username amount")
                return

            # Extract target username (remove @ symbol if present)
            target_username = args[1].lstrip('@')
            try:
                amount = int(args[2])
            except ValueError:
                await self.highrise.send_whisper(user.id, "Amount must be a number.")
                return

            if amount <= 0:
                await self.highrise.send_whisper(user.id, "Amount must be positive.")
                return

            sender_username = user.username
            
            # Check if sender has permission (owner or sufficient balance)
            if sender_username not in owners:
                if sender_username not in wallet or wallet[sender_username]["chips"] < amount:
                    await self.highrise.send_whisper(user.id, "Insufficient chips!")
                    return

            # Initialize target wallet if needed
            if target_username not in wallet:
                wallet[target_username] = {
                    "chips": 0,
                    "wins": 0,
                    "losses": 0,
                    "last_login": datetime.now().isoformat(),
                    "total_wagered": 0,
                    "total_won": 0
                }
                casino['total_players'] += 1

            # Transfer chips (only deduct from non-owners)
            if sender_username not in owners:
                wallet[sender_username]["chips"] -= amount
            
            wallet[target_username]["chips"] += amount

            indicator = self.get_indicator(sender_username)
            await self.highrise.chat(
                f"{indicator}@{sender_username} gave {amount} chips to @{target_username}"
            )

        except Exception as e:
            print(f"Give command error: {e}")
            await self.highrise.send_whisper(user.id, "Error processing give command")
    
    async def handle_bonus_command(self, user: User) -> None:
        """Handle the !bonus command with 24-hour cooldown."""
        username = user.username
        
        if username not in casino['bonuses']:
            casino['bonuses'][username] = {
                "last_used": None,
                "active_until": None,
                "effectiveness": 0.3  # Actually only 30% effective
            }
        
        now = datetime.now()
        user_bonus = casino['bonuses'][username]
        
        # Check if 24 hours have passed since last use
        if user_bonus["last_used"]:
            last_used = datetime.fromisoformat(user_bonus["last_used"])
            time_since_last = now - last_used
            if time_since_last < timedelta(hours=24):
                remaining = timedelta(hours=24) - time_since_last
                hours = int(remaining.total_seconds() // 3600)
                minutes = int((remaining.total_seconds() % 3600) // 60)
                await self.highrise.send_whisper(user.id, f"⏳ You can claim your next bonus reward in {hours}h {minutes}m.")
                return
        
        # Activate bonus (but it's only 30% effective)
        user_bonus["last_used"] = now.isoformat()
        user_bonus["active_until"] = (now + timedelta(minutes=10)).isoformat()
        
        await self.highrise.send_whisper(user.id, "[✨] Bonus activated! for next 10 minutes.")

    async def handle_remaining_bonus_command(self, user: User) -> None:
        """Handle the !rm command to check remaining bonus time."""
        username = user.username
        
        if username not in casino['bonuses'] or not casino['bonuses'][username]["active_until"]:
            await self.highrise.send_whisper(user.id, "No active bonus. Use !bonus to activate.")
            return
        
        now = datetime.now()
        active_until = datetime.fromisoformat(casino['bonuses'][username]["active_until"])
        
        if now >= active_until:
            await self.highrise.send_whisper(user.id, "Bonus has expired. Use !bonus to activate a new one (24h cooldown).")
            return
        
        remaining = active_until - now
        minutes = int(remaining.total_seconds() // 60)
        seconds = int(remaining.total_seconds() % 60)
        await self.highrise.send_whisper(user.id, f"🎁 Bonus time remaining: {minutes}m {seconds}s")

    def check_active_bonus(self, username: str) -> bool:
        """Check if user has an active bonus."""
        if username not in casino['bonuses'] or not casino['bonuses'][username]["active_until"]:
            return False
        
        now = datetime.now()
        active_until = datetime.fromisoformat(casino['bonuses'][username]["active_until"])
        return now < active_until
    
    async def show_rank(self, user: User) -> None:
        try:
            username = user.username
            tier = self.get_membership(username)
            indicator = self.get_indicator(username)
            wagered = wallet[username].get('total_wagered', 0)

            if tier == "standard":
                remaining = max(0, 100_000 - wagered)
                msg = f"You need to spend {remaining} to get a Gold membership."
                await self.highrise.send_whisper(user.id, msg)

            elif tier == "gold":
                remaining = max(0, 250_000 - wagered)
                await self.highrise.send_whisper(user.id, f"{indicator}Your current rank is Gold.")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.send_whisper(user.id, f"You need to spend {remaining} to get Platinum tier.")

            elif tier == "platinum":
                remaining = max(0, 500_000 - wagered)
                await self.highrise.send_whisper(user.id, f"{indicator}Your current rank is Platinum.")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.send_whisper(user.id, f"You need to spend {remaining} to get Diamond tier.")

            elif tier == "diamond":
                remaining = max(0, 800_000 - wagered)
                await self.highrise.send_whisper(user.id, f"{indicator}Your current rank is Diamond.")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.send_whisper(user.id, f"You need to spend {remaining} to get Noir tier.")

            elif tier == "noir":
                await self.highrise.send_whisper(user.id, f"{indicator}Your current rank is Noir.")
                try:
                    await asyncio.sleep(1.5)
                except asyncio.CancelledError:
                    return
                await self.highrise.send_whisper(user.id, "Congratulations on achieving the highest tier!")

        except Exception as e:
            print(f"Error in show_rank: {e}")
    
    async def show_help(self, user: User, is_convo: str = None) -> None:
        """Show help message with all available commands."""
        m = ("♠ Commands:\n\n"
        "🎰 Gameplay:\n"
        "!bet [amount] | !bonus\n"
        "!hit | !stand | !double\n\n"
        "💰 Chips & Gold\n"
        "!bal | !cash [amount]\n"
        "!give @username [amount]\n\n"
        "📋 Information:\n"
        "!rules | !resources | !terms")
        m2 = ("♠ Commands:\n\n"
        "🎰 Gameplay:\n"
        "!bet [amount] | !bonus\n"
        "!hit | !stand | !double\n\n"
        "💰 Chips & Gold\n"
        "!bal | !cash [amount]\n"
        "!give @username [amount]\n\n"
        "👑 Members only command:\n"
        "!daily | !rank\n\n"
        "📋 Information:\n"
        "!rules | !resources | !terms")
        h1 = ("Owner commands:\n"
        "/set - Sets bot location\n"
        "!in <room url> - Sets room invite\n"
        "invite - Invites all users (check by !users)\n"
        "!addall - adds all unique players in invite list")
        h2 = ("\n!copy @user - Copies user's outfit")
        try:
            if is_convo: 
                name = await self.get_username(user)
                if self.get_membership(name) != "standard": 
                    m = m2
            else: 
                if self.get_membership(user.username) != "standard": 
                    m = m2
            await self.highrise.send_message(is_convo, m) if is_convo else await self.highrise.send_whisper(user.id, m)
            username = user.username if not is_convo else await self.get_username(user)
            if username in owners:
                for i in (h1, h2):
                    await self.highrise.send_whisper(user.id, i) if not is_convo else self.highrise.send_message(is_convo, i)
        except Exception as e: print(e)

    async def show_leaderboard(self, user) -> None:
        """Show the leaderboard."""
        # Sort players by total won
        non_zero_players = [
        (username, data) for username, data in wallet.items()
        if data["total_won"] > 0
    ]
        if len(non_zero_players) == 0:
            await self.highrise.send_whisper(user.id, "No top players yet. Be one type !bet 10")
            return
        sorted_players = sorted(
            non_zero_players,
            key=lambda x: x[1]["total_won"],
            reverse=True
        )[:10]
        
        leaderboard_text = "🏆 TOP PLAYERS 🏆\n"
        for i, (username, data) in enumerate(sorted_players, 1):
            if data['total_won'] == 0: continue
            leaderboard_text += f"{i}. {username}: {data['total_won']} chips won\n"
        try:
            await self.highrise.send_whisper(user.id, leaderboard_text)
        except:
            pass

    async def show_recent_winners(self, user) -> None:
        """Show recent winners."""
        if not casino.get('recent_winners'):
            await self.highrise.chat("No recent winners yet!")
            return
        
        winners_text = "🎉 RECENT WINNERS 🎉\n"
        for username, amount, timestamp in casino['recent_winners'][-5:]:
            winners_text += f"{username}: {amount} chips\n"
        try:
            await self.highrise.send_whisper(user.id, winners_text)
        except:
            pass

    async def handle_withdraw(self, user: User, message: str):
        try:
            args = message.split()
            if len(args) != 2 or not args[1].isdigit():
                await self.highrise.send_whisper(user.id, "Usage: !cash [amount] (Min: 20 chips)")
                return

            chips = int(args[1])
            ps = int(chips * 1.1)
            username = user.username

            if chips < 20:
                await self.highrise.send_whisper(user.id, "Minimum withdrawal: 20 chips.")
                return
                
            if wallet[username]["chips"] < ps:
                await self.highrise.send_whisper(user.id, f"Not enough chips! [Balance: {wallet[username]['chips']} needs {ps}]")
                return

            # Calculate gold after 5% fee
            gold_after_fee = int(chips)
            wallet[username]["chips"] -= ps

            # Prepare gold bars
            denominations = [
                (10000, "gold_bar_10k"),
                (5000, "gold_bar_5000"),
                (1000, "gold_bar_1k"),
                (500, "gold_bar_500"),
                (100, "gold_bar_100"),
                (50, "gold_bar_50"),
                (10, "gold_bar_10"),
                (5, "gold_bar_5"),
                (1, "gold_bar_1")
            ]

            remaining = gold_after_fee
            tip_items = []
            
            for value, bar_type in denominations:
                while remaining >= value and len(tip_items) < 10:
                    tip_items.append(bar_type)
                    remaining -= value

            if tip_items:
                try:
                    await self.highrise.tip_user(user.id, ",".join(tip_items))
                    await self.highrise.chat(f"{self.get_indicator(user.username)}@{user.username} cashed [Golds {chips}g]")
                except Exception as e:
                    print(e)
            else:
                await self.highrise.send_whisper(user.id, "Withdrawal failed - try a larger amount")

        except Exception as e:
            print(f"Withdrawal error: {e}")
            await self.highrise.send_whisper(user.id, "Withdrawal processing failed")

    async def show_info(self, user: User) -> None:
        """Show casino information."""
        info_text = (
            f"🎰 Casino Stats 🎰\n"
            f"Total Players: {casino.get('total_players', 0)}\n"
            f"Active Players: {casino.get('active_players', 0)}\n"
            f"Games Played: {casino.get('games_played', 0)}\n"
            f"Total Bets: {casino.get('total_bets', 0)} chips\n"
            f"Total Wins: {casino.get('total_wins', 0)} chips"
        )
        try:
            await self.highrise.send_whisper(user.id, info_text)
        except:
            pass
    
    async def show_resources(self, user: User, is_convo: str = None) -> None:
        """Show resources to help people"""
        m = ("If you experience gambling problems, there are resources available to help you:\n\n"
                   "Gamblers Anonymous: [www.gamblersanonymous.org]\n\n"
                   "NCP Gambling: [www.ncpgambling.org]\n\n"
                   "For additional confidential help, contact one of our friendly Society Ambassadors.")
        try:
            await self.highrise.send_message(is_convo, m) if is_convo else await self.highrise.send_whisper(user.id, m)
        except Exception as e: print(e)
    
    async def show_rules(self, user: User, is_convo: str = None) -> None:
        """Show rules to warn people"""
        m = ("Rule #1: This room does not exist.\n"
    "Rule #2: No photos.\n"
    "Rule #3: Only invite those you trust.\n"
    "Rule #4: Maintain the culture.\n"
    "Rule #5: Be mindful.\n"
    "Rule #6: Avoid sensitive topics.\n"
    "Rule #7: 18+ only\n\n"
    "Breaking these rules will result in removal.")
        try:
            await self.highrise.send_whisper(user.id, m) if not is_convo else await self.highrise.send_message(is_convo, m)
        except: pass
     
    async def show_terms(self, user: User, is_convo: str = None) -> None:
        """Show terms and conditions"""
        tm = (
    "Society Terms of Agreement\n\n"
    "By engaging with Society rooms and bots, you hereby agree to the following terms:\n\n"
    "Acceptance of Rules: You acknowledge and accept all the rules associated with Society's rooms and bots. "
    "These rules are in place to ensure a fair and enjoyable experience for all participants.\n\n"
    "Acknowledgment of Risks: You understand that participation in Society's activities involves certain risks. "
    "You agree that Society or its affiliates shall not be held liable for any outcomes resulting from your participation.\n\n"
    "Entertainment Purposes: You acknowledge that the services provided by Society are intended solely for entertainment purposes. "
    "They should not be used as a means for financial gain or as a solution to financial challenges.\n\n"
    "Age Restriction: Participation is restricted to individuals who are of legal age in their respective jurisdiction. "
    "You affirm that you meet this age requirement.\n\n"
    "Responsible Engagement: You commit to engaging responsibly in all activities within Society. "
    "This includes understanding and accepting the risks associated with these activities.\n\n"
    "Release of Liability: By continuing to engage with Society's rooms and bots, you release Society and its affiliates "
    "from any claims related to your participation. This includes claims of financial loss, emotional distress, or any other grievances.\n\n"
    "By engaging with Society's rooms and bots, you indicate your understanding and acceptance of these terms. "
    "We thank you for your cooperation and hope you enjoy your time with Society!"
)
        m = (
    "Society Terms of Agreement\n\n"
    "By engaging with Society rooms and bots, you hereby agree to the following terms:\n\n",
    "Acceptance of Rules: You acknowledge and accept all the rules associated with Society's rooms and bots. "
    "These rules are in place to ensure a fair and enjoyable experience for all participants.\n\n",
    "Acknowledgment of Risks: You understand that participation in Society's activities involves certain risks. "
    "You agree that Society or its affiliates shall not be held liable for any outcomes resulting from your participation.\n\n",
    "Entertainment Purposes: You acknowledge that the services provided by Society are intended solely for entertainment purposes. "
    "They should not be used as a means for financial gain or as a solution to financial challenges.\n\n",
    "Age Restriction: Participation is restricted to individuals who are of legal age in their respective jurisdiction. "
    "You affirm that you meet this age requirement.\n\n",
    "Responsible Engagement: You commit to engaging responsibly in all activities within Society. "
    "This includes understanding and accepting the risks associated with these activities.\n\n",
    "Release of Liability: By continuing to engage with Society's rooms and bots, you release Society and its affiliates "
    "from any claims related to your participation. This includes claims of financial loss, emotional distress, or any other grievances.\n\n",
    "By engaging with Society's rooms and bots, you indicate your understanding and acceptance of these terms. "
    "We thank you for your cooperation and hope you enjoy your time with Society!"
)
        try:
            if is_convo: await self.highrise.send_message(is_convo, tm)
            else:
                for p in m:
                    await self.highrise.send_whisper(user.id, p)
                    try:
                        await asyncio.sleep(1.5)
                    except asyncio.CancelledError:
                        return
        except: pass