import sys
import math
import os
import time
from datetime import datetime, timedelta
import asyncio
from highrise import BaseBot, __main__
from highrise.models import User, SessionMetadata, Position
from highrise import *
from highrise.webapi import *
from highrise.models_webapi import *
from highrise.models import *
import random
from datetime import datetime
#from casinodb import  vip_users6 as vip_users, msg6 as msg, promo6 as promo, ownerz6 as ownerz, welcome6 as welcome, vip_loc6 as vip_loc, locations6 as locations, bot_location6 as bot_location, ranges6 as ranges, nicknames6 as nicknames, bad_words6 as bad_words, partyid6 as partyid, lids6 as ids, data6 as data
from casinodb.bot9 import *

emote_dict = {
    '1': ('idle-loop-sitfloor', 22.321055),
    '2': ('idle-enthusiastic', 15.941537),
    '3': ('emote-yes', 2.565001),
    '4': ('emote-wave', 2.690873),
    '5': ('emote-tired', 4.61063),
    '6': ('emote-snowball', 5.230467),
    '7': ('emote-snowangel', 6.218627),
    '8': ('emote-shy', 4.477567),
    '9': ('emote-sad', 5.411073),
    '10': ('emote-no', 2.703034),
    '11': ('emote-model', 6.490173),
    '12': ('emote-laughing', 2.69161),
    '13': ('emote-kiss', 2.387175),
    '14': ('emote-hot', 4.353037),
    '15': ('emote-hello', 2.734844),
    '16': ('emote-greedy', 4.639828),
    '17': ('emote-curtsy', 2.425714),
    '18': ('emote-confused', 8.578827),
    '19': ('emote-charging', 8.025079),
    '20': ('emote-bow', 3.344036),
    '21': ('emoji-thumbsup', 2.702369),
    '22': ('emoji-gagging', 5.500202),
    '23': ('emoji-flex', 2.099351),
    '24': ('emoji-celebrate', 3.412258),
    '25': ('emoji-angry', 5.760023),
    '26': ('dance-tiktok8', 11),
    '27': ('dance-tiktok2', 10.392353),
    '28': ('dance-shoppingcart', 4.316035),
    '29': ('dance-russian', 10.252905),
    '30': ('dance-pennywise', 4.214349),
    '31': ('dance-macarena', 12.214141),
    '32': ('dance-blackpink', 7.150958),
    '33': ('emote-hyped', 7.492423),
    '34': ('dance-jinglebell', 10.958832),
    '35': ('idle-nervous', 21.714221),
    '36': ('idle-toilet', 32.174447),
    '37': ('idle-floating', 27.791175),
    '38': ('dance-zombie', 12.922772),
    '39': ('emote-astronaut', 13.791175),
    '40': ('emote-swordfight', 5.914365),
    '41': ('emote-timejump', 4.007305),
    '42': ('emote-snake', 5.262578),
    '43': ('emote-float', 8.995302),
    '44': ('emote-telekinesis', 10.492032),
    '45': ('dance-pinguin', 11.58291),
    '46': ('dance-creepypuppet', 6.416121),
    '47': ('emote-sleigh', 11.333165),
    '48': ('emote-maniac', 4.906886),
    '49': ('emote-energyball', 7.575354),
    '50': ('emote-superpose', 4.530791),
    '51': ('emote-cute', 6.170464),
    '52': ('idle_singing', 13.791175),
    '53': ('emote-frog', 14.55257),
    '54': ('dance-tiktok9', 11.892918),
    '55': ('dance-weird', 21.556237),
    '56': ('dance-tiktok10', 8.225648),
    '57': ('emote-pose7', 4.655283),
    '58': ('emote-pose8', 4.808806),
    '59': ('idle-dance-casual', 9.079756),
    '60': ('emote-pose1', 2.825795),
    '61': ('emote-pose3', 5.10562),
    '62': ('emote-pose5', 4.621532),
    '63': ('emote-cutey', 3.26032),
    '64': ('emote-punkguitar', 9.365807),
    '65': ('emote-fashionista', 5.606485),
    '66': ('emote-gravity', 8.955966),
    '67': ('dance-icecream', 14.769573),
    '68': ('dance-wrong', 12.422389),
    '69': ('idle-uwu', 24.761968),
    '70': ('idle-dance-tiktok4', 15.500708),
    '71': ('emote-shy2', 4.989278),
    '72': ('dance-anime', 8.46671),
    '73': ('dance-kawai', 10.290789),
    '74': ('idle-wild', 26.422824),
    '75': ('emote-iceskating', 7.299156),
    '76': ('emote-pose6', 5.375124),
    '77': ('emote-celebrationstep', 3.353703),
    '78': ('emote-creepycute', 7.902453),
    '79': ('emote-pose10', 3.989871),
    '80': ('emote-boxer', 5.555702),
    '81': ('emote-headblowup', 11.667537),
    '82': ('emote-pose9', 4.583117),
    '83': ('emote-teleporting', 11.7676),
    '84': ('dance-touch', 11.7),
    '85': ('idle-guitar', 13.229398),
    '86': ('emote-gift', 5.8),
    '87': ('dance-employee', 8),
    '88': ('emote-looping', 8),
    '89': ('emote-kissing-bound', 10),
    '90': ('emote-zombierun', 9.182984),
    '91': ('emote-frustrated', 5.584622),
    '92': ('emote-slap', 2.724945),
    '93': ('emote-shrink', 8.738784),
    '94': ('dance-voguehands', 9.150634),
    '95': ('dance-smoothwalk', 6.690023),
    '96': ('dance-singleladies', 21.191372),
    '97': ('dance-orangejustice', 6.475263),
    '98': ('dance-metal', 15.076377),
    '99': ('dance-handsup', 22.283413),
    '100': ('dance-duckwalk', 11.748784),
    '101': ('dance-aerobics', 8.796402),
    '102': ('dance-sexy', 12.30883),
    '103': ('idle-dance-tiktok7', 12.956484),
    '104': ('sit-relaxed', 29.889858),
    '105': ('sit-open', 26.025963),
    '106': ('emoji-there', 2.059095),
    '107': ('emoji-sneeze', 2.996694),
    '108': ('emoji-smirking', 4.823158),
    '109': ('emoji-sick', 5.070367),
    '110': ('emoji-scared', 3.008487),
    '111': ('emoji-punch', 1.755783),
    '112': ('emoji-pray', 4.503179),
    '113': ('emoji-poop', 4.795735),
    '114': ('emoji-naughty', 4.277602),
    '115': ('emoji-mind-blown', 2.397167),
    '116': ('emoji-lying', 6.313748),
    '117': ('emoji-halo', 5.837754),
    '118': ('emoji-hadoken', 2.723709),
    '119': ('emoji-give-up', 5.407888),
    '120': ('emoji-dizzy', 4.053049),
    '121': ('emoji-crying', 3.696499),
    '122': ('emoji-clapping', 2.161757),
    '123': ('emoji-arrogance', 6.869441),
    '124': ('emoji-ghost', 3.472759),
    '125': ('emoji-eyeroll', 3.020264),
    '126': ('idle-fighter', 17.19123),
    '127': ('emote-wings', 13.134487),
    '128': ('emote-think', 3.691104),
    '129': ('emote-theatrical', 8.591869),
    '130': ('emote-tapdance', 11.057294),
    '131': ('emote-superrun', 6.273226),
    '132': ('emote-superpunch', 3.751054),
    '133': ('emote-sumo', 10.868834),
    '134': ('emote-suckthumb', 4.185944),
    '135': ('emote-splitsdrop', 4.46931),
    '136': ('emote-secrethandshake', 3.879024),
    '137': ('emote-ropepull', 8.769656),
    '138': ('emote-roll', 3.560517),
    '139': ('emote-rofl', 6.314731),
    '140': ('emote-robot', 7.607362),
    '141': ('emote-rainbow', 2.813373),
    '142': ('emote-proposing', 4.27888),
    '143': ('emote-peekaboo', 3.629867),
    '144': ('emote-peace', 5.755004),
    '145': ('emote-panic', 2.850966),
    '146': ('emote-ninjarun', 4.754721),
    '147': ('emote-nightfever', 5.488424),
    '148': ('emote-monster_fail', 4.632708),
    '149': ('emote-levelup', 6.0545),
    '150': ('emote-laughing2', 5.056641),
    '151': ('emote-kicking', 4.867992),
    '152': ('emote-jumpb', 3.584234),
    '153': ('emote-judochop', 2.427442),
    '154': ('emote-jetpack', 16.759457),
    '155': ('emote-hugyourself', 4.992751),
    '156': ('emote-harlemshake', 13.558597),
    '157': ('emote-happy', 3.483462),
    '158': ('emote-handstand', 4.015678),
    '159': ('emote-gordonshuffle', 8.052307),
    '160': ('emote-ghost-idle', 19.570492),
    '161': ('emote-gangnam', 7.275486),
    '162': ('emote-fainting', 18.423499),
    '163': ('emote-fail2', 6.475972),
    '164': ('emote-fail1', 5.617942),
    '165': ('emote-exasperatedb', 2.722748),
    '166': ('emote-exasperated', 2.367483),
    '167': ('emote-elbowbump', 3.799768),
    '168': ('emote-disco', 5.366973),
    '169': ('emote-disappear', 6.195985),
    '170': ('emote-deathdrop', 3.762728),
    '171': ('emote-death2', 4.855549),
    '172': ('emote-death', 6.615967),
    '173': ('emote-dab', 2.717871),
    '174': ('emote-cold', 3.664348),
    '175': ('emote-bunnyhop', 12.380685),
    '176': ('emote-boo', 4.501502),
    '177': ('emote-baseball', 7.254841),
    '178': ('emote-apart', 4.809542),
    '179': ('emote-attention', 4.401206),
    '180': ('emote-hearteyes', 4.034386),
    '181': ('emote-heartfingers', 4.001974),
    '182': ('emote-heartshape', 6.232394),
    '183': ('emote-hug', 3.503262),
    '184': ('emote-embarrassed', 7.414283),
    '185': ('emote-puppet', 16.325823),
    '186': ('idle_zombie', 28.754937),
    '187': ('idle_layingdown2', 21.546653),
    '188': ('idle_layingdown', 24.585168),
    '189': ('idle-sleep', 22.620446),
    '190': ('idle-sad', 24.377214),
    '191': ('idle-posh', 21.851256),
    '192': ('idle-loop-tired', 21.959007),
    '193': ('idle-loop-tapdance', 6.261593),
    '194': ('idle-loop-shy', 16.47449),
    '195': ('idle-loop-sad', 6.052999),
    '196': ('idle-loop-happy', 18.798322),
    '197': ('idle-loop-annoyed', 17.058522),
    '198': ('idle-loop-aerobics', 8.507535),
    '199': ('idle-lookup', 22.339865),
    '200': ('idle-hero', 21.877099),
    '201': ('idle-floorsleeping2', 17.253372),
    '202': ('idle-floorsleeping', 13.935264),
    '203': ('idle-dance-headbobbing', 25.367458),
    '204': ('idle-angry', 25.427848),
    '205': ('dance-hipshake', 12.8),
    '206': ('dance-tiktok11', 11.0),
    '207': ('emote-cutesalute', 3.0),
    '208': ('emote-salute', 3.0),
    '209': ('idle_tough', 18.0),
    '210': ('emote-fail3', 4.2),
    '211': ('emote-theatrical-test', 6.5),
    '212': ('emote-receive-happy', 3.5),
    '213': ('emote-confused2', 8.0),
    '214': ('dance-shuffle', 8.5),
    '215': ('idle-cold', 18.0),
    '216': ('mining-mine', 8.0),
    '217': ('mining-success', 3.5),
    '218': ('fishing-pull', 4.5),
    '219': ('fishing-idle', 15.0),
    '220': ('fishing-cast', 4.0),
    '221': ('fishing-pull-small', 5.0),
    '222': ('dance-fruity', 9.0),
    '223': ('dance-cheerleader', 8.5),
    '224': ('dance-tiktok14', 11.0),
    '225': ('emote-howl', 7.0),
    '226': ('idle-howl', 20.0),
    '227': ('emote-trampoline', 8.0),
    '228': ('emote-launch', 3.5),
    '229': ('emote-stargazer', 6.0),
    '230': ('dance-freshprince', 14.86),
    '231': ("idle-headless", 41.802306),
    '232': ("emote-gooey", 5.819651),
    '233': ("emote-electrified", 5.287880),
    'sit': ('idle-loop-sitfloor', 22.321055),
    'enthused': ('idle-enthusiastic', 15.941537),
    'yes': ('emote-yes', 2.565001),
    'wave': ('emote-wave', 2.690873),
    'tired': ('emote-tired', 4.61063),
    'snowball': ('emote-snowball', 5.230467),
    'snowangel': ('emote-snowangel', 6.218627),
    'shy': ('emote-shy', 4.477567),
    'sad': ('emote-sad', 5.411073),
    'no': ('emote-no', 2.703034),
    'model': ('emote-model', 6.490173),
    'lust': ('emote-lust', 4.655965),
    'laughing': ('emote-laughing', 2.69161),
    'kiss': ('emote-kiss', 2.387175),
    'hot': ('emote-hot', 4.353037),
    'hello': ('emote-hello', 2.734844),
    'greedy': ('emote-greedy', 4.639828),
    'curtsy': ('emote-curtsy', 2.425714),
    'confused': ('emote-confused', 8.578827),
    'charging': ('emote-charging', 8.025079),
    'bow': ('emote-bow', 3.344036),
    'thumb': ('emoji-thumbsup', 2.702369),
    'gagging': ('emoji-gagging', 5.500202),
    'flex': ('emoji-flex', 2.099351),
    'cursing': ('emoji-cursing', 2.382069),
    'celebrate': ('emoji-celebrate', 3.412258),
    'angry': ('emoji-angry', 5.760023),
    'tiktok8': ('dance-tiktok8', 11),
    'tiktok2': ('dance-tiktok2', 10.392353),
    'shoppingcart': ('dance-shoppingcart', 4.316035),
    'russian': ('dance-russian', 10.252905),
    'pennywise': ('dance-pennywise', 1.214349),  # Fixed duration (was 4.214349 in `motes`?)
    'macarena': ('dance-macarena', 12.214141),
    'blackpink': ('dance-blackpink', 7.150958),
    'hyped': ('emote-hyped', 7.492423),
    'jinglebell': ('dance-jinglebell', 10.958832),
    'nervous': ('idle-nervous', 21.714221),
    'toilet': ('idle-toilet', 32.174447),
    'floating': ('idle-floating', 27.791175),
    'zombie': ('dance-zombie', 12.922772),
    'astronaut': ('emote-astronaut', 13.791175),
    'swordfight': ('emote-swordfight', 5.914365),
    'timejump': ('emote-timejump', 4.007305),
    'snake': ('emote-snake', 5.262578),
    'float': ('emote-float', 8.995302),
    'telekinesis': ('emote-telekinesis', 10.492032),
    'pinguin': ('dance-pinguin', 11.58291),
    'creepypuppet': ('dance-creepypuppet', 6.416121),
    'bike': ('emote-sleigh', 11.333165),
    'mani': ('emote-maniac', 4.906886),
    'energyball': ('emote-energyball', 7.575354),
    'superpose': ('emote-superpose', 4.530791),
    'cute': ('emote-cute', 6.170464),
    'tiktok9': ('dance-tiktok9', 11.892918),
    'weird': ('dance-weird', 21.556237),
    'tiktok10': ('dance-tiktok10', 8.225648),
    'pose7': ('emote-pose7', 4.655283),
    'pose8': ('emote-pose8', 4.808806),
    'dance-casual': ('idle-dance-casual', 9.079756),
    'pose1': ('emote-pose1', 2.825795),
    'pose3': ('emote-pose3', 5.10562),
    'pose5': ('emote-pose5', 4.621532),
    'cutey': ('emote-cutey', 3.26032),
    'punk': ('emote-punkguitar', 9.365807),
    'fashion': ('emote-fashionista', 5.606485),
    'gravity': ('emote-gravity', 8.955966),
    'icecream': ('dance-icecream', 14.769573),
    'wrong': ('dance-wrong', 12.422389),
    'uwu': ('idle-uwu', 24.761968),
    'sayso': ('idle-dance-tiktok4', 15.500708),
    'bashful': ('emote-shy2', 4.989278),
    'anime': ('dance-anime', 8.46671),
    'kawai': ('dance-kawai', 10.290789),
    'wild': ('idle-wild', 26.422824),
    'iceskating': ('emote-iceskating', 7.299156),
    'pose6': ('emote-pose6', 5.375124),
    'suii': ('emote-celebrationstep', 3.353703),
    'creepycute': ('emote-creepycute', 7.902453),
    'pose10': ('emote-pose10', 3.989871),
    'boxer': ('emote-boxer', 5.555702),
    'blow': ('emote-headblowup', 11.667537),
    'ditzy': ('emote-pose9', 4.583117),
    'teleporting': ('emote-teleporting', 11.7676),
    'touch': ('dance-touch', 11.7),
    'guitar': ('idle-guitar', 13.229398),
    'gift': ('emote-gift', 5.8),
    'employee': ('dance-employee', 8),
    'looping': ('emote-looping', 8),
    'smooch': ('emote-kissing-bound', 10),
    'camera': ('idle-phone-camera', 14.8),
    'phone': ('emote-phone', 9),
    'knock': ('knocking-screen', 7.5),
    'twerk': ('dance-twerk', 8.7),
    'singing': ('idle_singing', 13.791175),
    'frog': ('emote-frog', 14.55257),
    'zombierun': ('emote-zombierun', 9.182984),
    'frustrated': ('emote-frustrated', 5.584622),
    'slap': ('emote-slap', 2.724945),
    'kawaii': ('emote-kawaiigogo', 10.0),
    'shrink': ('emote-shrink', 8.738784),
    'vogue': ('dance-voguehands', 9.150634),
    'spiritual': ('dance-spiritual', 15.795092),
    'smoothwalk': ('dance-smoothwalk', 6.690023),
    'singleladies': ('dance-singleladies', 21.191372),
    'robotic': ('dance-robotic', 17.814959),
    'orange': ('dance-orangejustice', 6.475263),
    'metal': ('dance-metal', 15.076377),
    'handsup': ('dance-handsup', 22.283413),
    'floss': ('dance-floss', 21.329661),
    'duckwalk': ('dance-duckwalk', 11.748784),
    'breakdance': ('dance-breakdance', 17.623849),
    'aerobics': ('dance-aerobics', 8.796402),
    'sexy': ('dance-sexy', 12.30883),
    'tiktok7': ('idle-dance-tiktok7', 12.956484),  # Fixed key (was 'dance-tiktok7')
    'repose': ('sit-relaxed', 29.889858),
    'laid': ('sit-open', 26.025963),
    'poke': ('emoji-there', 2.059095),
    'sneeze': ('emoji-sneeze', 2.996694),
    'smirking': ('emoji-smirking', 4.823158),
    'sick': ('emoji-sick', 5.070367),
    'scared': ('emoji-scared', 3.008487),
    'punch': ('emoji-punch', 1.755783),
    'pray': ('emoji-pray', 4.503179),
    'stinky': ('emoji-poop', 4.795735),
    'naughty': ('emoji-naughty', 4.277602),
    'mind-blown': ('emoji-mind-blown', 2.397167),
    'lying': ('emoji-lying', 6.313748),
    'halo': ('emoji-halo', 5.837754),
    'hadoken': ('emoji-hadoken', 2.723709),
    'give-up': ('emoji-give-up', 5.407888),
    'dizzy': ('emoji-dizzy', 4.053049),
    'crying': ('emoji-crying', 3.696499),
    'clapping': ('emoji-clapping', 2.161757),
    'arrogance': ('emoji-arrogance', 6.869441),
    'ghosts': ('emoji-ghost', 3.472759),
    'eyeroll': ('emoji-eyeroll', 3.020264),
    'fighter': ('idle-fighter', 17.19123),
    'wings': ('emote-wings', 13.134487),
    'think': ('emote-think', 3.691104),
    'theatrical': ('emote-theatrical', 8.591869),
    'tapdance': ('emote-tapdance', 11.057294),
    'run': ('emote-superrun', 6.273226),
    'superpunch': ('emote-superpunch', 3.751054),
    'sumo': ('emote-sumo', 10.868834),
    'suckthumb': ('emote-suckthumb', 4.185944),
    'split': ('emote-splitsdrop', 4.46931),
    'handshake': ('emote-secrethandshake', 3.879024),
    'ropepull': ('emote-ropepull', 8.769656),  # Fixed key (was 'ropel')
    'roll': ('emote-roll', 3.560517),
    'rofl': ('emote-rofl', 6.314731),
    'robot': ('emote-robot', 7.607362),
    'rainbow': ('emote-rainbow', 2.813373),
    'proposing': ('emote-proposing', 4.27888),
    'peekaboo': ('emote-peekaboo', 3.629867),
    'peace': ('emote-peace', 5.755004),
    'panic': ('emote-panic', 2.850966),
    'ninja': ('emote-ninjarun', 4.754721),
    'nightfever': ('emote-nightfever', 5.488424),
    'monster_fail': ('emote-monster_fail', 4.632708),
    'levelup': ('emote-levelup', 6.0545),
    'laugh': ('emote-laughing2', 5.056641),
    'kick': ('emote-kicking', 4.867992),
    'jumpb': ('emote-jumpb', 3.584234),
    'judochop': ('emote-judochop', 2.427442),
    'jetpack': ('emote-jetpack', 16.759457),
    'hugyourself': ('emote-hugyourself', 4.992751),
    'hero-idle': ('idle-hero', 21.877099),  # Fixed key (was duplicate 'hero')
    'headball': ('emote-headball', 10.073119),
    'harlem': ('emote-harlemshake', 13.558597),
    'happy': ('emote-happy', 3.483462),
    'handstand': ('emote-handstand', 4.015678),
    'graceful': ('emote-graceful', 3.7498),
    'moonwalk': ('emote-gordonshuffle', 8.052307),
    'ghost': ('emote-ghost-idle', 19.570492),
    'gangnam': ('emote-gangnam', 7.275486),
    'frollicking': ('emote-frollicking', 3.700665),
    'faint': ('emote-fainting', 18.423499),
    'fall': ('emote-fail2', 6.475972),
    'falling': ('emote-fail1', 5.617942),
    'exasperatedb': ('emote-exasperatedb', 2.722748),
    'exasperated': ('emote-exasperated', 2.367483),
    'elbowbump': ('emote-elbowbump', 3.799768),
    'disco': ('emote-disco', 5.366973),
    'disappear': ('emote-disappear', 6.195985),
    'deathdrop': ('emote-deathdrop', 3.762728),
    'death2': ('emote-death2', 4.855549),
    'death': ('emote-death', 6.615967),
    'dab': ('emote-dab', 2.717871),
    'cold': ('emote-cold', 3.664348),
    'bunny': ('emote-bunnyhop', 12.380685),
    'boo': ('emote-boo', 4.501502),
    'baseball': ('emote-baseball', 7.254841),
    'apart': ('emote-apart', 4.809542),
    'attention': ('emote-attention', 4.401206),
    'hearteyes': ('emote-hearteyes', 4.034386),
    'heartfingers': ('emote-heartfingers', 4.001974),
    'heartshape': ('emote-heartshape', 6.232394),
    'hug': ('emote-hug', 3.503262),
    'lagughing': ('emote-lagughing', 1.125537),
    'embarrassed': ('emote-embarrassed', 7.414283),
    'puppet': ('emote-puppet', 16.325823),
    'rest': ('sit-idle-cute', 17.062613),
    'zombie-idle': ('idle_zombie', 28.754937),
    'relax': ('idle_layingdown2', 21.546653),
    'attentive': ('idle_layingdown', 24.585168),
    'sleep': ('idle-sleep', 22.620446),
    'pouty': ('idle-sad', 24.377214),
    'posh': ('idle-posh', 21.851256),
    'tired-loop': ('idle-loop-tired', 21.959007),
    'tapdance': ('idle-loop-tapdance', 6.261593),
    'shy-loop': ('idle-loop-shy', 16.47449),
    'sad-loop': ('idle-loop-sad', 6.052999),
    'chilling': ('idle-loop-happy', 18.798322),
    'annoyed': ('idle-loop-annoyed', 17.058522),
    'aerobics-loop': ('idle-loop-aerobics', 8.507535),
    'ponder': ('idle-lookup', 22.339865),
    'relaxing': ('idle-floorsleeping2', 17.253372),
    'cozy': ('idle-floorsleeping', 13.935264),
    'swinging': ('idle-dance-swinging', 13.198551),
    'dance-headbobbing': ('idle-dance-headbobbing', 25.367458),
    'angry-idle': ('idle-angry', 25.427848),  # Fixed key (was duplicate 'angry')
    'call': ('idle-phone-talking', 14.8),
    'phone-camera': ('idle-phone-camera', 14.8),
    'phone-emote': ('emote-phone', 9),  # Fixed key (was duplicate 'phone')
    'knock': ('knocking-screen', 7.5),
    'fresh': ('dance-freshprince', 14.86),
    'twerk': ('dance-twerk', 8.7),
    'headless': ("idle-headless", 41.802306),
    'gooey': ("emote-gooey", 5.819651),
    'electrified': ("emote-electrified", 5.287880),
}

class PARTY(BaseBot):
    def __init__(self):
        super().__init__()
        self.username = None
        self.owner_id = None
        self.owner = None
        self.bot_id = None
        self.quiet = False
        self.emote_task = None
        self.promo_task = None
        self.dance_loop_task = None
        self.users_in_square = []
        self.freeze = {}
        self.active_sos_requests = {}
        self.dance_loop_running = False
        self.auto_tip_task = None
        self.auto_tip_loop = None  # New: actual tipping loop
        self.auto_tip_ammount = 1
        self.auto_tip_time = 600
        self.last_positions = {}
        self.BARS_DICTIONARY = {
            10000: "gold_bar_10k",
            5000: "gold_bar_5000",
            1000: "gold_bar_1k",
            500: "gold_bar_500",
            100: "gold_bar_100",
            50: "gold_bar_50",
            10: "gold_bar_10",
            5: "gold_bar_5",
            1: "gold_bar_1"
        }
        self.FEES_DICTIONARY = {
            10000: 1000,
            5000: 500,
            1000: 100,
            500: 50,
            100: 10,
            50: 5,
            10: 1,
            5: 1,
            1: 1
        }

    async def restart_bot(self):
        await asyncio.sleep(5)
        os.execv(sys.executable, [sys.executable, 'run.py'] + sys.argv[1:])

    async def promo(self):
        while True:
            try:
                for items in promo:
                    await self.highrise.chat(items)
                    await asyncio.sleep(100)
                else:
                    await asyncio.sleep(100)
            except:
                pass
            await asyncio.sleep(300)

    async def _dance_loop(self):
        while self.dance_loop_running:
            try:
                await self.highrise.send_emote("emote-hyped")
                await asyncio.sleep(7.492423 + 0.01)
            except Exception:
                break

    async def _run_auto_tip(self):
        while data["auto_tip"]:
            try:
                amount = int(self.auto_tip_ammount)
                room_users = (await self.highrise.get_room_users()).content
                await self.process_tips(self.username, amount, room_users, is_bulk=True)
            except:
                pass
            await asyncio.sleep(self.auto_tip_time)

    async def monitor_auto_tip(self):
        while True:
            if data["auto_tip"] and self.auto_tip_loop is None:
                self.auto_tip_loop = asyncio.create_task(self._run_auto_tip())
            elif not data["auto_tip"] and self.auto_tip_loop:
                self.auto_tip_loop.cancel()
                try:
                    await self.auto_tip_loop
                except asyncio.CancelledError:
                    pass
                self.auto_tip_loop = None
            await asyncio.sleep(1)

    async def on_start(self, session_metadata: SessionMetadata):
        if "auto_tip" not in data:
            data["auto_tip"] = False
        if "flashed" not in data:
            data["flashed"] = {}
        if "points" not in data:
            data["points"] = {}
        await asyncio.sleep(5)
        try:
            self.username = await self.get_username(session_metadata.user_id)
            self.bot_id = session_metadata.user_id
            self.owner_id = session_metadata.room_info.owner_id
            self.owner = await self.get_username(self.owner_id)
        except Exception as e:
            print("Error in get username, and bot id on start:", e)

        if self.username not in ownerz:
            ownerz.append(self.username)
        if self.owner and self.owner not in ownerz:
            ownerz.append(self.owner)

        async def safe_cancel(task):
            if task:
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass

        await safe_cancel(self.emote_task)
        self.emote_task = asyncio.create_task(self.send_same_random_emote_to_all_users())

        await safe_cancel(self.dance_loop_task)
        self.dance_loop_running = True
        self.dance_loop_task = asyncio.create_task(self._dance_loop())

        await safe_cancel(self.auto_tip_task)
        self.auto_tip_task = asyncio.create_task(self.monitor_auto_tip())

        await safe_cancel(self.promo_task)
        self.promo_task = asyncio.create_task(self.promo())

        try:
            if bot_location:
                await self.highrise.teleport(session_metadata.user_id, Position(**bot_location))
            else:
                await self.highrise.teleport(session_metadata.user_id, Position(15.5, 0.25, 2.5, 'FrontRight'))
        except:
            pass

        print(f"{self.username} is alive.")

    async def send_same_random_emote_to_all_users(self):
        try:
            while True:
                try:
                    if self.users_in_square:
                        all_emote_names = [k for k in emote_dict.keys() if isinstance(k, str)]
                        if all_emote_names:
                            random_emote_name = random.choice(all_emote_names)
                            emote_id, emote_duration = emote_dict.get(random_emote_name, (None, None))
                
                            for user_id in self.users_in_square:
                                await self.highrise.send_emote(emote_id, user_id)  # Use only emote_id
                except:
                    continue
                await asyncio.sleep(10)
        except Exception as e:
            print(f"Error: {e}")
            
    async def invite_all(self, user):
        if not user.username in ownerz:
            await self.highrise.send_whisper(user.id, "You cant use this command.")
            return
        try:
            for user_id in ids:
                message_id = f"1_on_1:{user_id}:{self.bot_id}"
                await self.highrise.send_message(
                message_id,
                message_type="invite",
                content="Join this room!", 
                room_id=partyid[0])
                await asyncio.sleep(0.5)
        except Exception as e:
            await self.highrise.chat(f"error: {e}")

    async def on_user_leave(self, user: User) -> None:
        await asyncio.sleep(1.5)
        try:
            if user.id in self.users_in_square:
                self.users_in_square.remove(user.id)
            if user.username in data["points"] and data["points"][user.username]["join"] is not None:
                join_time = data["points"][user.username]["join"]
                spent = time.time() - join_time
                data["points"][user.username]["total"] += spent
                data["points"][user.username]["join"] = None
        except:
            pass

    async def on_user_move(self, user: User, pos: Position) -> None:
        try:
            if user.username.lower() in self.freeze:
                await self.highrise.teleport(user.id, self.freeze[user.username.lower()])
                return
            if "x1" in ranges and "x2" in ranges and "y" in ranges and "z1" in ranges and "z2" in ranges:
                if ranges["x1"] <= pos.x <= ranges["x2"] and pos.y == ranges["y"] and ranges["z1"] <= pos.z <= ranges["z2"]:
                    if user.id not in self.users_in_square:
                        self.users_in_square.append(user.id)
                        await self.highrise.teleport(user.id, Position(pos.x, pos.y, pos.z))
                else:
                    if user.id in self.users_in_square:
                        self.users_in_square.remove(user.id)
            if not data['flashed'].get(user.username, False):
                return
            def distance(pos1, pos2):
                return math.sqrt((pos1.x - pos2.x)**2 + (pos1.y - pos2.y)**2 + (pos1.z - pos2.z)**2)
            if user.id in self.last_positions:
                last_pos = self.last_positions[user.id]
                if distance(pos, last_pos) >= 7:
                    await self.highrise.teleport(user.id, pos)
            self.last_positions[user.id] = pos
        except:
            pass

    async def on_whisper(self, user: User, message: str) -> None:
        pass
     
    async def sos(self, user_id, reason: str):
        if user_id in self.active_sos_requests:
            conversation_id = f"1_on_1:{user_id}:{self.bot_id}"
            await self.highrise.send_message(conversation_id, "You already have an active SOS request.")
            return
        username = await self.get_username(user_id)
        self.active_sos_requests[user_id] = {
            "victim": username,
            "reason": reason,
            "task": asyncio.create_task(self._sos_loop(user_id, username, reason))
        }
        
    async def _sos_loop(self, victim_id: str, victim_name: str, reason: str):
        try:
            while victim_id in self.active_sos_requests:
                for helper_id in msg:
                    if helper_id == victim_id:
                        continue  # Don't message the victim
                    
                    message_id = f"1_on_1:{helper_id}:{self.bot_id}"
                    try:
                        await self.highrise.send_message(
                            message_id,
                            f"🚨 EMERGENCY: @{victim_name} needs help!\n"
                            f"📝 Reason: {reason}\n"
                            f"✋ Reply '1' to stop alerts"
                        )
                    except Exception as e:
                        print(f"Failed to send SOS to {helper_id}: {e}")
                    await asyncio.sleep(3)  # Rate limiting between messages
                await asyncio.sleep(5)  # Interval between broadcast rounds
        except Exception as e:
            print(f"SOS loop error: {e}")
        finally:
            self.active_sos_requests.pop(victim_id, None)

    async def stop_sos(self, helper_id: str):
        # Find which SOS this helper is responding to
        for victim_id, data in list(self.active_sos_requests.items()):
            if helper_id in msg:
                data["task"].cancel()
                try:
                    await data["task"]
                except asyncio.CancelledError:
                    pass
                
                # Notify the helper
                await self.highrise.send_message(
                    f"1_on_1:{helper_id}:{self.bot_id}",
                    f"✅ SOS alerts stopped for @{data['victim']}"
                )
                
                # Notify the victim
                if victim_id in self.active_sos_requests:
                    del self.active_sos_requests[victim_id]
                    await self.highrise.send_message(
                        f"1_on_1:{victim_id}:{self.bot_id}",
                        "Your SOS alerts have been cancelled by a helper."
                    )
                break

    async def color(self: BaseBot, category: str, color_palette: int):
        outfit = (await self.highrise.get_my_outfit()).outfit
        for outfit_item in outfit:
            item_category = outfit_item.id.split("-")[0]
            if item_category == category:
                try:
                    outfit_item.active_palette = color_palette
                except:
                    await self.highrise.chat(f"The bot isn't using any item from the category '{category}'.")
                    return
        await self.highrise.set_outfit(outfit)
        
    async def equip(self, item_name: str):
        items = (await self.webapi.get_items(item_name=item_name)).items
        if not items:
            await self.highrise.chat(f"Item '{item_name}' not found.")
            return
        
        item = items[0]
        item_id, category = item.item_id, item.category

        inventory = (await self.highrise.get_inventory()).items
        has_item = any(inv_item.id == item_id for inv_item in inventory)

        if not has_item:
            if item.rarity == Rarity.NONE:
                pass
            elif not item.is_purchasable:
                await self.highrise.chat(f"Item '{item_name}' can't be purchased.")
                return
            else:
                try:
                    response = await self.highrise.buy_item(item_id)
                    if response != "success":
                        await self.highrise.chat(f"Failed to purchase item '{item_name}'.")
                        return
                    await self.highrise.chat(f"Item '{item_name}' purchased.")
                except Exception as e:
                    await self.highrise.chat(f"Error purchasing '{item_name}': {e}")
                    return

        new_item = Item(
            type="clothing",
            amount=1,
            id=item_id,
            account_bound=False,
            active_palette=0,
        )

        outfit = (await self.highrise.get_my_outfit()).outfit
        outfit = [
            outfit_item
            for outfit_item in outfit
            if outfit_item.id.split("-")[0][0:4] != category[0:4]
        ]

        if category == "hair_front" and item.link_ids:
            hair_back_id = item.link_ids[0]
            hair_back = Item(
                type="clothing",
                amount=1,
                id=hair_back_id,
                account_bound=False,
                active_palette=0,
            )
            outfit.append(hair_back)
        outfit.append(new_item)
        await self.highrise.set_outfit(outfit)
    async def remove(self: BaseBot, category: str):
        outfit = (await self.highrise.get_my_outfit()).outfit

        for outfit_item in outfit:
            item_category = outfit_item.id.split("-")[0][0:3]
            if item_category == category[0:3]:
                try:
                    outfit.remove(outfit_item)
                except Exception as e:
                     pass
                     return
            await self.highrise.set_outfit(outfit)

    async def on_message(self, user_id: str, conversation_id: str, is_new_conversation: bool) -> None:
        try:
            response = await self.highrise.get_messages(conversation_id)
            if isinstance(response, GetMessagesRequest.GetMessagesResponse):
                message = response.messages[0].content
                if message.startswith("/sos"):
                    reason = message[5:].strip()
                    if len(reason) >= 15:
                        await self.sos(user_id, reason)
                    else:
                        await self.highrise.send_message(conversation_id, "Reason must be at least 15 characters long.")
                if message.strip() == "1" and user_id in msg:
                    await self.stop_sos(user_id)
                if message != "/verify":
                    if user_id not in ids:
                        ids.append(user_id)
                    return
            username = await self.get_username(user_id)
            info = await self.webapi.get_user(user_id)
            joined_at = info.user.joined_at
            if isinstance(joined_at, datetime):
                one_month_ago = datetime.now(joined_at.tzinfo) - timedelta(days=90)
                if joined_at <= one_month_ago:
                    if not username in user_ticket:
                        user_ticket[username] = 3
                        await self.highrise.send_message(conversation_id, "Your account is verified.")
                        await self.highrise.send_message(conversation_id, "You got 3 free tickets")
                        if not user_id in ids:
                            ids.append(user_id)
                else:
                    await self.highrise.send_message(conversation_id, "Sorry, it looks like your account is less than 3 months old, so you cant verify just yet.")
                    await asyncio.sleep(3)
                    await self.highrise.send_message(conversation_id,"We're just trying to keep things fair and avoid alt accounts grabbing free tickets.\nThanks for understanding! ⏳️")
        except Exception as e:
            print(e)
               
    async def loop_emote(self, user: User, emote_name: str) -> None:
        emote_id, emote_duration = self.get_emote_info(emote_name)
        if not emote_id:
            await self.highrise.send_whisper(user.id, "Invalid emote")
            return

        while True:
            room_users = (await self.highrise.get_room_users()).content
            user_in_room = any(room_user.id == user.id for room_user, pos in room_users)

            if not user_in_room:
                break

            try:
                await self.highrise.send_emote(emote_id, user.id)
            except:
                pass

            await asyncio.sleep(emote_duration + 0.1)

    async def loop(self, user: User, emote_name: str) -> None:
        taskgroup = self.highrise.tg
        task_list: list[asyncio.Task] = list(taskgroup._tasks)
        for task in task_list:
            if task.get_name() == user.username:
                task.cancel()
        task = taskgroup.create_task(self.loop_emote(user, emote_name))
        task.set_name(user.username)

    async def stop(self, user: User, message: str) -> None:
        taskgroup = self.highrise.tg
        task_list: list[asyncio.Task] = list(taskgroup._tasks)
        for task in task_list:
            if task.get_name() == user.username:
                task.cancel()
                await self.highrise.send_whisper(user.id, "Emote loop stopped.")

    async def follow(self, user: User, message: str) -> None:
        if user.username not in ownerz:
            return

        target_username = None
        if message.startswith("/follow @"):
            target_username = message[9:].split()[0]  # Extract username correctly

        async def following_loop(self, user: User, target_user: User) -> None:
            while True:
                room_users = (await self.highrise.get_room_users()).content
                target_position = None
                
                for room_user, position in room_users:
                    if room_user.id == target_user.id:
                        target_position = position
                        break
                
                if target_position:
                    if not isinstance(target_position, AnchorPosition):
                        await self.highrise.walk_to(Position(target_position.x + 1, target_position.y, target_position.z))
                
                await asyncio.sleep(0.5)

        taskgroup = self.highrise.tg
        task_list = list(taskgroup._tasks)
        
        for task in task_list:
            if task.get_name() == "following_loop":
                await self.highrise.send_whisper(user.id, "Already following someone")
                return

        target_user = None
        if target_username:
            room_users = (await self.highrise.get_room_users()).content
            for room_user, _ in room_users:
                if room_user.username == target_username:
                    target_user = room_user
                    break
            else:
                await self.highrise.send_whisper(user.id, f"User @{target_username} not found in the room")
                return

        if target_user is None:
            await self.highrise.send_whisper(user.id, "Invalid username")
            return

        taskgroup.create_task(following_loop(self, user, target_user), name="following_loop")
        await self.highrise.chat(f"Following {target_user.username}")
   
    async def stopf(self, user: User, message: str) -> None:
        if user.username not in ownerz:
            await self.highrise.send_whisper(user.id, "You are not able to use this command")
            return

        taskgroup = self.highrise.tg
        task_list = list(taskgroup._tasks)
        for task in task_list:
            if task.get_name() == "following_loop":
                task.cancel()
                await self.highrise.chat(f"Stopping following {user.username}")
                return
        await self.highrise.chat("Not following anyone")

    async def summon(self, user: User, message: str) -> None:
        try:
            command, username = message.split(" ")
        except ValueError:
            await self.highrise.send_whisper(user.id, "Incorrect format, please use /br @username")
            return

        username = username.replace("@", "")
        user_privileges = await self.highrise.get_room_privilege(user.id)
        summoner_is_privileged = user_privileges.moderator or user.username in ownerz
        if not summoner_is_privileged:
            await self.highrise.send_whisper(user.id, "You are not authorized to use /br")
            return
        try:
            room_users = (await self.highrise.get_room_users()).content

            for user_info in room_users:
                if user_info[0].username.lower() == username.lower():
                    target_user_id = user_info[0].id
                    break
            else:
                await self.highrise.send_whisper(user.id, "User not found, please specify a valid user")
                return

        except Exception as e:
            await self.highrise.chat(f"Error fetching room users: {e}")
            return
        try:
            response = await self.highrise.get_room_users()

            for content in response.content:
                if content[0].id == user.id:
                    if isinstance(content[1], Position):
                        your_pos = content[1]
                        break
            else:
                await self.highrise.send_whisper(user.id, f"@{user.username}, you do not have a valid position.")
                return

        except Exception as e:
            await self.highrise.chat(f"Error fetching user position: {e}")
            return
        try:
            await self.highrise.teleport(user_id=target_user_id, dest=your_pos)
        except Exception as e:
            await self.highrise.chat(f"Error teleporting user: {e}")
            return

    async def goto(self, user, message):
        try:
            command, username = message.split(" ")
        except ValueError:
            await self.highrise.chat("Incorrect format, please use /to @username")
            return

        username = username.replace("@", "")

        user_privileges = await self.highrise.get_room_privilege(user.id)

        summoner_is_privileged = user_privileges.moderator or user.username in ownerz

        if not summoner_is_privileged:
            await self.highrise.send_whisper(user.id, "You are not authorized to use /goto")
            return

        room_users = (await self.highrise.get_room_users()).content
        for user_info in room_users:
            if user_info[0].username.lower() == username.lower():
                target_user_id = user_info[0].id
                target_user_position = user_info[1]
                break
        else:
            await self.highrise.chat("User not found, please specify a valid user")
            return

        try:
            await self.highrise.teleport(user_id=user.id, dest=target_user_position)
        except Exception as e:
            await self.highrise.chat(f"Error: {str(e)}.")

    async def send_leaderboard(self):
        if "points" not in data or not data["points"]:
            message = "No data available yet."
            await self.highrise.chat(f"\n🏆 {message}")
            return

        sorted_points = sorted(
            data["points"].items(),
        key=lambda x: x[1]["total"] + (time.time() - x[1]["join"] if x[1]["join"] else 0),
        reverse=True
    )
        top_users = sorted_points[:10]

        leaderboard = "\n🏆 Top 10 Users :"
        for i, (uid, info) in enumerate(top_users, start=1):
            total_seconds = info["total"]
            if info["join"] is not None:
                total_seconds += time.time() - info["join"]

            hours = int(total_seconds // 3600)
            minutes = int((total_seconds % 3600) // 60)
            formatted_time = f"{hours:02d}h {minutes:02d}m"

            leaderboard += f"\n{i}. @{uid}: {formatted_time}"

        await self.highrise.chat(leaderboard)

    def get_user_time(self, username: str) -> str:
        if username not in data["points"]:
            return "00:00"
        total = data["points"][username]["total"]
        if data["points"][username]["join"] is not None:
            total += time.time() - data["points"][username]["join"]

        hours = int(total // 3600)
        minutes = int((total % 3600) // 60)
        return f"{hours:02d}h {minutes:02d}m"

    async def on_chat(self, user: User, message: str) -> None:
        if message.lower().startswith("/info @"):
            if user.username not in ownerz: return
            username = message[7:].strip()
            time = self.get_user_time(username)
            await self.highrise.chat("\n👤 User Info:\n"
            f"⏳ Time spent: {time}")
        if message.lower() == "/status":
            await self.send_leaderboard()
        if message.lower() == "/flash":
            if not data['flashed'].get(user.username, False):
                data["flashed"][user.username] = True
                await self.highrise.send_whisper(user.id, "Flash mode activated.")
            else:
                await self.highrise.send_whisper(user.id, "Flash mode is already activated.")
        if message.lower() == "/sflash":
            if data['flashed'].get(user.username, False):
                data["flashed"][user.username] = False
                await self.highrise.send_whisper(user.id, "Flash mode deactivated.")
            else:
                await self.highrise.send_whisper(user.id, "Flash mode is already deactivated.")
        if message.lower() == "/autotip":
            if user.username not in ownerz:
                return
            if not data.get("auto_tip", False):
                data["auto_tip"] = True
                await self.highrise.chat(
            f"Auto tip activated, delay: {self.auto_tip_time/60} minute(s).")
            else:
                await self.highrise.chat("Auto tip is already activated.")
        if message.lower() == "/offauto":
            if user.username not in ownerz:
                return
            if data.get("auto_tip", False):
                data["auto_tip"] = False
                await self.highrise.chat("Auto tip deactivated.")
            else:
                await self.highrise.chat("Auto tip is already deactivated.")

        if message.lower().startswith("/ammount "):
            if user.username not in ownerz: return
            try:
                num = int(message[9:].strip())
                self.auto_tip_ammount = max(1, num)
                await self.highrise.chat(f"Auto tip ammount set to: {self.auto_tip_ammount}")
            except ValueError:
                self.auto_tip_ammount = 1
                await self.highrise.send_whisper(user.id, "Usage: /ammount 1")
        if message.lower().startswith("/time "):
            if user.username not in ownerz: return
            try:
                parts = message[6:].strip().lower()
                if parts.endswith("min"):
                    minutes = int(parts[:-3])
                    if minutes == 0:
                        await self.highrise.chat("Csnt set delay to 0 minute.")
                        return
                    self.auto_tip_time = minutes * 60
                    await self.highrise.chat(f"Auto tip delay set to {minutes} minute(s)")
            except ValueError:
                await self.highrise.send_whisper(user.id, "Usage: /time 1min")

        if any(word.lower() in message.lower() for word in bad_words) and user.username not in ownerz:
            try:
                await self.highrise.moderate_room(user.id, "kick")
            except Exception as e:
                print(e)
        
        if message.startswith("/url") and user.username in ownerz:
            # Extract the URL from the message
            try:
                url = message.split("/url ")[1]
                room_id = url.split("room?id=")[1].split("&")[0]
                if len(partyid) > 0:
                    partyid.clear()
                    partyid.append(room_id)
                else:
                    partyid.append(room_id)
            except:
                pass

        if message.startswith("/invite"):
            try:
                await self.invite_all(user)
            except Exception as e:
                await self.highrise.chat(f"Issue: {e}")

        if message.startswith("remove"):
            if not user.username in ownerz:
                return
            try:
                parts = message.split()
                if len(parts) == 2:
                    _, category = parts
                    await self.remove(category)
                else:
                    await self.highrise.send_whisper(user.id, "Invalid format. Use: remove [item_name]")
            except:
                pass
            
        if message.startswith("/equip"):
            if not user.username in ownerz:
                return
            try:
                parts = message.split()
                if len(message.split()) >= 2:
                    item_name = message.split(maxsplit=1)[1].strip()  # Get everything after /equip
                    await self.equip(item_name)
                else:
                    await self.highrise.send_whisper(user.id, "Invalid format. Use: /equip [item_name]")
            except:
                pass
            
        if message.startswith("/color"):
            if not user.username in ownerz:
                return
            parts = message.split()
            if len(parts) == 3:
                _, category, color_palette = parts
                try:
                    color_palette = int(color_palette)  # Convert to integer
                    await self.color(category, color_palette)
                except ValueError:
                    await self.highrise.send_whisper(user.id, "The color palette must be a number.")
            else:
                await self.highrise.send_whisper(user.id, "Invalid format. Use: /color [category] [palette_number]")
        
        if message.startswith("/bad ") and user.username in ownerz:
            try:    
                res = message.split(" ", 1)[1]
                if res not in bad_words:
                    bad_words.append(res)
                    await self.highrise.chat("This message is added to bad words.")
                else:
                    await self.highrise.chat("This word is already restricted.")
            except Exception as e:
                print(f"Error in /bad command: {e}")
                
        if message.startswith("/nbad ") and user.username in ownerz:
            try:    
                res = message.split(" ", 1)[1]
                if res in bad_words:
                    bad_words.remove(res)
                    await self.highrise.chat("This message is removed from bad_words.")
                else:
                    await self.highrise.chat("This word is not restricted.")
            except Exception as e:
                print(f"Error in /nbad command: {e}")
        
        if self.is_valid_emote(message.strip().lower()):
            try:
                await self.emote(user, message.strip().lower())
            except Exception as e:
                pass
            
    ##### NEW HANDLERS FUNCTIONS #####
    
        if message.startswith("/nickname ") and user.username in ownerz:
            await self.handle_nickname(message)
        
        if message == "/quiet" and not self.quiet:
            if user.username not in ownerz:
                return
            try:
                await self.handle_quiet()
            except Exception as e:
                print(e)
            
        if message == "/talk" and self.quiet:
            if user.username not in ownerz:
                return
            try:
                await self.handle_talk()
            except Exception as e:
                print(e)
    
        if message.startswith("/freeze "):
            if user.username not in ownerz:
                return
            await self.handle_freeze(message)
        if message.startswith("/free "):
            if user.username not in ownerz:
                return
            await self.handle_unfreeze(message)
    
        if message.lower() == "/come":
            try:
                if user.username not in ownerz:
                    return
                room_users = (await self.highrise.get_room_users()).content
                for room_user, position in room_users:
                    if room_user.id == user.id:
                        user_position = position
                        break
                if type(user_position) != AnchorPosition:
                    await self.highrise.walk_to(Position(user_position.x + 1, user_position.y, user_position.z))
            except Exception as e:
                await self.highrise.send_whisper(user.id, f"Error: {e}")
    
        if message.startswith("/tip "):
            if  not user.username in ownerz:
                return
            await self.handle_tip_command(user, message)
        if message.startswith("/tipall "):
            if  not user.username in ownerz:
                return
            await self.handle_bulk_tip(user, message)

        if message.lower() == "/wallet":
            try:
                if user.username in ownerz:
                    wallet = await self.highrise.get_wallet()
                    for item in wallet.content:
                        if item.type == "gold":
                            gold = item.amount
                            await self.highrise.send_whisper(user.id, f"Sir, My current balance is {gold} gold!")
                            return
                        await self.highrise.send_whisper(f"Hello, {user.username}! I don't have any gold.")
            except:
                pass
            
        if message.lower().startswith("/boost"):
            try:
                if user.username not in ownerz:
                    return
                amount = 1
                parts = message.split()
                if len(parts) > 1 and parts[1].isdigit():
                    amount = int(parts[1])
                elif len(parts) == 2:
                    try:
                        amount = int(parts[1])
                    except ValueError:
                        pass
                response = await self.highrise.buy_room_boost(payment="bot_wallet_only", amount=amount)
                await self.highrise.chat(response)
            except Exception as e:
                print(f"Error buying boost: {e}")

        if message.lower().startswith("/voice"):
            try:
                amount = 1
                parts = message.split()
                if len(parts) > 1 and parts[1].isdigit():
                    amount = int(parts[1])
                for _ in range(amount):
                    response = await self.highrise.buy_voice_time(payment="bot_wallet_only")
                    await self.highrise.chat(response)
                    await asyncio.sleep(1)
    
            except Exception as e:
                print(f"Error buying voice time: {e}")
                
        if message.startswith("/promote "):
            if user.username not in ownerz:
                return
            parts = message.split()
            if len(parts) != 3:
                await self.highrise.send_whisper(user.id, "Invalid promote command format.")
                return
            command, username, role = parts
            if "@" not in username:
                username = username
            else:
                username = username[1:]
            if role.lower() not in ["moderator", "designer"]:
                await self.highrise.chat("Invalid role, please specify a valid role.")
                return
            room_users = (await self.highrise.get_room_users()).content
            for room_user, pos in room_users:
                if room_user.username.lower() == username.lower():
                    user_id = room_user.id
                    break
            if "user_id" not in locals():
                await self.highrise.chat("User not found, please specify a valid user and coordinate")
                return
            permissions = (await self.highrise.get_room_privilege(user_id))
            setattr(permissions, role.lower(), True)
            try:
                await self.highrise.change_room_privilege(user_id, permissions)
                await self.highrise.chat(f"{username} has been promoted to {role}.")
            except Exception as e:
                await self.highrise.chat(f"Error: {e}")
                return
            
        if message.startswith("/demote "):
            if user.username not in ownerz:
                await self.highrise.chat("You do not have permission to use this command.")
                return
            parts = message.split()
            if len(parts) != 3:
                await self.highrise.chat("Invalid demote command format.")
                return
            command, username, role = parts
            if "@" not in username:
                username = username
            else:
                username = username[1:]
            if role.lower() not in ["moderator", "designer"]:
                await self.highrise.chat("Invalid role, please specify a valid role.")
                return
            room_users = (await self.highrise.get_room_users()).content
            for room_user, pos in room_users:
                if room_user.username.lower() == username.lower():
                    user_id = room_user.id
                    break
            if "user_id" not in locals():
                await self.highrise.chat("User not found, please specify a valid user and coordinate")
                return

            permissions = (await self.highrise.get_room_privilege(user_id))
            setattr(permissions, role.lower(), False)
            try:
                await self.highrise.change_room_privilege(user_id, permissions)
                await self.highrise.chat(f"{username} has been demoted from {role}.")
            except Exception as e:
                await self.highrise.chat(f"Error: {e}")
                return

        if message.lower().startswith("/copy "):
            try:
                target_username = message[6:].strip().lstrip('@')
                response = await self.webapi.get_users(username=target_username, limit=1)
                
                if not response.users:
                    await self.highrise.chat(f"User @{target_username} not found.")
                    return
                
                target_user = response.users[0]
                outfit_response = await self.highrise.get_user_outfit(target_user.user_id)
                
                try:
                    await self.highrise.set_outfit(outfit=outfit_response.outfit)
                    await self.highrise.chat(f"Successfully copied @{target_user.username}'s complete outfit!")
                    return
                except Exception:
                    successful_items = []
                    failed_items = []
                    
                    for item in outfit_response.outfit:
                        try:
                            await self.highrise.set_outfit(outfit=successful_items + [item])
                            successful_items.append(item)
                        except Exception:
                            failed_items.append(item.id.split('-')[-1])
                    
                    if failed_items:
                        await self.highrise.chat(
                            f"Copied @{target_user.username}'s outfit but skipped {len(failed_items)} items: "
                            f"{', '.join(failed_items[:5])}{'...' if len(failed_items) > 5 else ''}"
                        )
                    else:
                        await self.highrise.chat(f"Successfully copied @{target_user.username}'s outfit piece by piece!")
            
            except Exception:
                await self.highrise.chat("Failed to copy outfit. Please try again.")

        if message.startswith("/k "):
            if  user.username not in ownerz:
                return

            parts = message.split()
            if len(parts) != 2:
                await self.highrise.chat("Invalid kick command format.")
                return
                
            if "@" not in parts[1]:
                username = parts[1]
            else:
                username = parts[1][1:]
            room_users = (await self.highrise.get_room_users()).content
            for room_user, pos in room_users:
                if room_user.username.lower() == username.lower():
                    user_id = room_user.id
                    break
            if "user_id" not in locals():
                await self.highrise.chat("User not found, please specify a valid user and coordinate")
                return
            try:
                await self.highrise.moderate_room(user_id, "kick")
            except Exception as e:
                await self.highrise.chat(f"{e}")
                return
            await self.highrise.chat(f"{username} has been kicked from the room.")
        
    ##### NEW HANDLERS FUNCTIONS #####
        
    ##### COMMAND HANDLERS FUNCTIONS #####
        
        if message.startswith("/to "):
            await self.goto(user, message)
        
        if message.startswith("/br "):
            await self.summon(user, message)
        
        if message.lower() == "/follow" or message.lower().startswith("/follow @"):
            await self.follow(user, message)
        if message.lower() == "/stopf":
            await self.stopf(user, message)
    ##### ENDS HERE ######
        
        ##### ADDING VIPS ownerz #####
        
        if message.lower() == "owner list" and user.username in ownerz:
            try:
                if ownerz:
                    message_content = ""
                    for idx, user_name in enumerate(ownerz, start=1):
                        item = f"{idx}. {user_name}\n"
                        if len(message_content) + len(item) > 255:
                            await self.highrise.send_whisper(user.id, f"\n{message_content.strip()}")
                            message_content = item
                        else:
                            message_content += item
                    if message_content:
                        await self.highrise.send_whisper(user.id, f"\n{message_content.strip()}")
                else:
                    await self.highrise.send_whisper(user.id, "The ownerz list is empty.")
            except Exception as e:
                print(f"Error in /ownerz command: {e}")
        
        if message.startswith("removeowner ") and user.username in ownerz:
            try:
                remvip = message.split(" ", 1)[1]
                rem = remvip.replace("@", "")
                if rem in ownerz:
                    ownerz.remove(rem)
                    await self.highrise.chat(f"{remvip} removed from ownerz.")
                else:
                    await self.highrise.send_whisper(user.id, f"{rem} not in ownerz.")
            except:
                pass
                
        if message.startswith("addowner ") and user.username in ownerz:
            try:
                vip = message.split(" ", 1)[1]
                allowed = vip.replace("@", "")
                if allowed not in ownerz:
                    ownerz.append(allowed)
                    await self.highrise.chat(f"{vip} added to ownerz.")
                else:
                    await self.highrise.chat(f"{vip} already in ownerz.")
            except:
                await self.highrise.send_whisper(user.id, "Nuh uh")
        
        if message.startswith("/wlc ") and user.username in ownerz:
            try:    
                prom = message.lstrip("/wlc ").strip()
                if prom:
                    if prom not in welcome:
                        welcome.append(prom)
                        await self.highrise.chat("This message has been added to the welcome message list.")
                    else:
                        await self.highrise.chat("This message is already in the welcome message list.")
                else:
                    await self.highrise.chat("Please provide a promotional message after /wlc.")
            except Exception as e:
                print(f"Error in /wlc command: {e}")
                
        if message.startswith("/rwlc ") and user.username in ownerz:
            try:    
                prom = message.lstrip("/rwlc ").strip()
                if prom:
                    if prom in welcome:
                        welcome.remove(prom)
                        await self.highrise.chat("This message is removed from welcome list.")
                    else:
                        await self.highrise.chat("This message is not in welcome list.")
                else:
                    await self.highrise.chat("Please provide a message after /rwlc.")
            except Exception as e:
                print(f"Error in /rwlc command: {e}")

        if message.startswith("/cwlc"):
            try:
                if user.username == "thisuserisded" or user.username == "Ecxlipze" or user.username in ownerz:
                    if promo:
                        welcome.clear()
                        await self.highrise.chat("Cleared welcome message list.")
                    else:
                        await self.highrise.chat("welcome message list is already empty.")
                else:
                    pass
            except:
                pass
                
        ##### ENDS HERE #####
        
        if message == "/restart" and (user.username == "thisuserisded" or user.username == "Ecxlipze" or user.username in ownerz):
            try:
                await self.highrise.send_whisper(user.id, "Restarting the bot...")
                await self.restart_bot()
            except Exception as e:
                print("Error in /restart command: ", e)
        
        if message.lower().lstrip().startswith(( "stop", "0", "/stop")):
            await self.stop(user, message)
        if self.is_valid_emote(message.strip().lower()):
            await self.loop(user, message.strip().lower())
        
        ##### VIP AND MOD AND SETTINGS #####
        
        if message == "setx" and user.username in ownerz:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                    ranges["x1"] = pos.x
                    
                    await self.highrise.send_whisper(user.id,f"x1 set to {pos.x}")
                    break

        if message == "setx2" and user.username in ownerz:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                    ranges["x2"] = pos.x
                    
                    await self.highrise.send_whisper(user.id,f"x2 set to {pos.x}")
                    break

        if message == "setz" and user.username in ownerz:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                    ranges["z1"] = pos.z
                    
                    await self.highrise.send_whisper(user.id,f"z1 set to {pos.z}")
                    break

        if message == "setz2" and user.username in ownerz:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                    ranges["z2"] = pos.z
                    
                    await self.highrise.send_whisper(user.id,f"z2 set to {pos.z}")
                    break
        
        if message == "sety" and user.username in ownerz:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                    ranges["y"] = pos.y
                    
                    await self.highrise.send_whisper(user.id,f"y set to {pos.y}")
                    break

        if message == "!setbot" and user.username in ownerz:
            try:
                room_users = await self.highrise.get_room_users()
                for room_user, pos in room_users.content:
                    if room_user.username == user.username:
                        bot_location["x"] = pos.x
                        bot_location["y"] = pos.y
                        bot_location["z"] = pos.z
                        bot_location["facing"] = pos.facing
                        await self.highrise.send_whisper(user.id, f"Bot location set to {bot_location}")
                        break
                await self.highrise.walk_to(Position(**bot_location))
            except Exception as e:
                print("Set bot:", e)

        if message == "/base" and user.username in ownerz:
            try:
                if bot_location:
                    await self.highrise.walk_to(Position(**bot_location))
            except Exception as e:
                print("Error in /base:", e)
        
        ##### ENDS HERE #####
        
        if message.startswith("/h"):
            try:
                if user.username in ownerz:
                    room_users = (await self.highrise.get_room_users()).content
                    for room_user, _ in room_users:
                        await self.highrise.react("heart", room_user.id)
                    await asyncio.sleep(2)
                else:
                    await self.highrise.send_whisper("This is for VIPs only")
            except: 
                pass
            
        if message.startswith("/hate"):
            hate_percentage = random.randint(1, 100)
            response = "heaven" if hate_percentage < 40 else "hell"
            await self.highrise.chat(f"{user.username} {hate_percentage}% people hates you, you deserve {response}.")
        
        if message.lower().lstrip().startswith(("location", "!location")):
            location_names = [f"• {name}" for name in locations.keys()]
            messages = ["\n".join(location_names[i:i+5]) for i in range(0, len(location_names), 5)]
            for ms in messages:
                await self.highrise.send_whisper(user.id, f"\n{ms}")
                await asyncio.sleep(1)
                
        
        if message.lower().lstrip().startswith(("help", "/help")):

            english_commands = [
                "Type Locations to know all Locations\nType location to go there i.e f1\nType emote name or num from 1-230.\nType /stop or 0 to stop the loop.",
                "Fun commands: /iq, /deathyear, /marriage, /love, /hate.",
                "Useful commands: /br @username, /to @user.\n/status - check leaderboard\n/flash - activate flash mode\n/sflash - deactivates flash mode."
            ]
 
            english_addcommands = [
                "/info @user - Check user's time\n"
                "/autotip - activate auto tip\n"
                "/offauto - deactivates auto tip\n"
                "/time 1min - sets 1 min delay between auto tip.",
                "/ammount 1 - sets ammountfor auto tip\n"
                "Type /url invitelink of room. i.e /url https://highrise....\n"
                "Type /invite - invite all users\n"
                "/freeze @user - Blocks user from moving.",
                "/unfreeze @user - Frees user.\n"
                "/quiet - mute everyone for announcements etc.\n"
                "/talk - unmute everyone.",
                "/tipall amount, /tip @user amount, /tip numberppl amount\n"
                "remove category - remove item from bot\n"
                "/equip item name\n"
                "/color category 1-63 i.e /color body 1.",
                "/bad word - adds word to restricted lists, if someone says word they will be kicked\n"
                "/nbad word - removes word from restricted list",
                "/nickname @user name - sets a custom name for user\n"
                "/come - makes bot walk to you\n"
                "/wallet - checks bot wallet\n"
                "/boost or /boost 1 to n - boost room n times",
                "/voice or /voice to buy mic time\n"
                "/promote @user designer or moderator\n"
                "/demote @user designer or moderator\n"
                "/copy @user - copy user's items to wear (only free ones)",
                "/k @user - kicks user\n"
                "/br @user - summons user\n"
                "/to @user - teleport to user\n"
                "/follow or /follow @user - bot follows user (stop with `/stopf`)",
                "owner list - prints owners\n"
                "vip list - prints VIPs"
            ]

            command_list = english_commands + english_addcommands if user.username in ownerz else english_commands

            for cmd in command_list:
                try:
                    await self.highrise.send_whisper(user.id, f"\n{cmd}")
                    await asyncio.sleep(1.5)
                except Exception as e:
                    print(cmd, f"Reason: {e}")
                    continue
        
        if message == "/cvip":
            if user.username in ownerz:
                try:
                    vip_users.clear()
                    await self.highrise.send_whisper(user.id, "Vip list cleared.")
                except:
                    pass
                
        if message.lower() == "vip list" and user.username in ownerz:
            try:
                if vip_users:
                    message_content = ""
                    for idx, user_name in enumerate(vip_users, start=1):
                        item = f"{idx}. {user_name}\n"
                        if len(message_content) + len(item) > 255:
                            await self.highrise.send_whisper(user.id, f"\n{message_content.strip()}")
                            message_content = item
                        else:
                            message_content += item
                    if message_content:
                        await self.highrise.send_whisper(user.id, f"\n{message_content.strip()}")
                else:
                    await self.highrise.send_whisper(user.id, "The vip list is empty.")
            except Exception as e:
                print(f"Error in /vipz command: {e}")
                await self.highrise.send_whisper(user.id, "Error checking the queue.")
        
        if message.startswith("removevip ") and user.username in ownerz:
            try:
                current_date = datetime.now().strftime("%d/%m/%Y")
                remvip = message.split(" ", 1)[1]
                rem = remvip.replace("@", "")
                if rem in vip_users:
                    vip_users.remove(rem)
                    await self.highrise.chat(f"{remvip} removed from vip.")
                    for user_id in msg:
                        message_id = f"1_on_1:{user_id}:{self.bot_id}"
                        try:
                            await self.highrise.send_message(message_id, f"User {remvip} removed from vip on {current_date}, Was removed by @{user.username}")
                            await asyncio.sleep(1)
                        except Exception as e:
                            await self.highrise.chat(f"Failed to send message to {user_id}: {e}")
                            print("Error in sending msg in addvip:", e)
                else:
                    await self.highrise.send_whisper(user.id, f"{rem} not a vip.")
            except:
                pass
                
        if message.startswith("addvip ") and user.username in ownerz:
            try:
                current_date = datetime.now().strftime("%d/%m/%Y")
                vip = message.split(" ", 1)[1]
                allowed = vip.replace("@", "")
                if allowed not in vip_users:
                    vip_users.append(allowed)
                    await self.highrise.chat(f"{vip} added to vip.")
                    for user_id in msg:
                        message_id = f"1_on_1:{user_id}:{self.bot_id}"
                        try:
                            await self.highrise.send_message(message_id, f"User {vip} got their vip on {current_date}, Was added by @{user.username}")
                            await asyncio.sleep(1)
                        except Exception as e:
                            await self.highrise.chat(f"Failed to send message to {user_id}: {e}")
                            print("Error in sending msg in addvip:", e)
                else:
                    await self.highrise.chat(f"{vip} already a vip.")
            except:
                await self.highrise.send_whisper(user.id, "Nuh uh")

        if message.startswith("/cmsg") and user.username in ownerz:
            try:
                if msg:
                    msg.clear()
                    await self.highrise.chat("Message list is cleared.")
                else:
                    await self.highrise.chat("Message list is already empty.")
            except:
                print("Error in /cmsg:", e)

        if message.startswith("/rmsg ") and user.username in ownerz:
            try:
                user = message.split(" ", 1)[1]
                username = user.replace("@", "")
                room_users = (await self.highrise.get_room_users()).content
                user_id = None
                for user in room_users:
                    if user[0].username.lower() == username.lower():
                        user_id = user[0].id
                        break
                if user_id is None:
                    await self.highrise.send_whisper(user.id,"User not found in room.")
                    return
                if user_id in msg:
                    msg.remove(user_id)
                    await self.highrise.chat(f"User @{username} is removed from message list.")
                else:
                    await self.highrise.chat("User is not in list.")
            except Exception as e:
                    print("Error in /rmsg:", e)

        if message.startswith("/msg ") and user.username in ownerz:
            try:
                user = message.split(" ", 1)[1]
                username = user.replace("@", "")
                room_users = (await self.highrise.get_room_users()).content
                user_id = None
                for user in room_users:
                    if user[0].username.lower() == username.lower():
                        user_id = user[0].id
                        break
                if user_id is None:
                    await self.highrise.send_whisper(user.id,"User not found in room.")
                    return
                if user_id not in msg:
                    msg.append(user_id)
                    await self.highrise.chat(f"User @{username} is added to message list.")
                else:
                    await self.highrise.chat("User is already in list.")
            except Exception as e:
                    print("Error in /msg:", e)

        if message.startswith("/promo ") and user.username in ownerz:
            try:    
                prom = message.lstrip("/promo ").strip()
                if prom:
                    if prom not in promo:
                        promo.append(prom)
                        await self.highrise.chat("This message has been added to the promo list.")
                    else:
                        await self.highrise.chat("This message is already in the promo list.")
                else:
                    await self.highrise.chat("Please provide a promotional message after /promo.")
            except Exception as e:
                print(f"Error in /promo command: {e}")
                
        if message.startswith("/rpromo ") and user.username in ownerz:
            try:    
                prom = message.lstrip("/promo ").strip()
                if prom:
                    if prom in promo:
                        promo.remove(prom)
                        await self.highrise.chat("This message is removed from promo list.")
                    else:
                        await self.highrise.chat("This message is not in promo list.")
                else:
                    await self.highrise.chat("Please provide a promotional message after /promo.")
            except Exception as e:
                print(f"Error in /rpromo command: {e}")

        if message.startswith("/cpromo"):
            try:
                if user.username in ownerz:
                    if promo:
                        promo.clear()
                        await self.highrise.chat("Cleared promo list.")
                    else:
                        await self.highrise.chat("Promo list is already empty.")
                else:
                    pass
            except:
                pass

        if message.startswith("/withdraw ") and user.username in ownerz:
            try:
                parts = message.split(" ")
                if len(parts) != 2:
                    await self.highrise.send_whisper(user.id, "\nUsage: /withdraw [number].")
                    return
                try:
                    amount = int(parts[1])
                except:
                    await self.highrise.send_whisper(user.id, "Dont use decimals and floats only use integars [number].")
                    return
                bot_wallet = await self.highrise.get_wallet()
                bot_amount = bot_wallet.content[0].amount
                if bot_amount <= amount:
                    await self.highrise.send_whisper(user.id, "Sir, i dont have enough balance.")
                    return
                """Possible values are: "gold_bar_1",
            "gold_bar_5", "gold_bar_10", "gold_bar_50", 
            "gold_bar_100", "gold_bar_500", 
            "gold_bar_1k", "gold_bar_5000", "gold_bar_10k" """
                bars_dictionary = {10000: "gold_bar_10k", 
                               5000: "gold_bar_5000",
                               1000: "gold_bar_1k",
                               500: "gold_bar_500",
                               100: "gold_bar_100",
                               50: "gold_bar_50",
                               10: "gold_bar_10",
                               5: "gold_bar_5",
                               1: "gold_bar_1"}
                fees_dictionary = {10000: 1000,
                               5000: 500,
                               1000: 100,
                               500: 50,
                               100: 10,
                               50: 5,
                               10: 1,
                               5: 1,
                               1: 1}
                tip = []
                total = 0
                for bar in bars_dictionary:
                    if amount >= bar:
                        bar_amount = amount // bar
                        amount = amount % bar
                        for i in range(bar_amount):
                            tip.append(bars_dictionary[bar])
                            total = bar+fees_dictionary[bar]
                if total > bot_amount:
                    await self.highrise.send_whisper(user.id, "Sir, i dont have enough funds.")
                    return
                tip_string = ",".join(tip)
                await self.highrise.tip_user(user.id, tip_string)
            except Exception as e:
                print("Error in /withdraw:", e)
        
        if message.startswith("/love"):
            love_percentage = random.randint(1, 100)
            await self.highrise.chat(f"@{user.username} Only {love_percentage}% people loves you.")
    
        if message.startswith("/marriage"):
            marriage_year = random.randint(2024, 2070)
            await self.highrise.chat(f"{user.username} enjoy your life till {marriage_year} 😁")
        
        if message.startswith("/iq"):
            iq_level = random.randint(90, 130)
            await self.highrise.chat(f"{user.username} your iq is :{iq_level}")
    
        if message.startswith("/deathyear"):
            death_year = random.randint(2024, 2080)
            await self.highrise.chat(f"{user.username} enjoy your life till {death_year} 😬")
        
        if message.startswith("/rloc ") and user.username in ownerz:
            location_name = message.split()[1]
            if location_name in locations:
                locations.pop(location_name, None)
                await self.highrise.chat(f"Removed location named '{location_name}'.")
            else:
                await self.highrise.send_whisper(user.id, f"No location found with name '{location_name}'.")
        
        if message.startswith("/set ") and user.username in ownerz:
            location_name = message.split()[1]
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                    locations[location_name] = f"{pos.x},{pos.y},{pos.z}"
                    await self.highrise.send_whisper(user.id, f"{location_name} set to {pos.x},{pos.y},{pos.z}")
                    break
        
        if message.lower().startswith("/setvip") and user.username in ownerz:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                    vip_loc['vip'] = (pos.x, pos.y, pos.z)
                    await self.highrise.chat(f"New VIP location set to: {pos.x},{pos.y},{pos.z}")
                    break
                
        if message.lower().startswith("/setmod") and user.username in ownerz:
            room_users = await self.highrise.get_room_users()
            for room_user, pos in room_users.content:
                if room_user.username == user.username:
                    vip_loc['mod'] = (pos.x, pos.y, pos.z)
                    await self.highrise.chat(f"New VIP location set to: {pos.x},{pos.y},{pos.z}")
                    break
        
        if message.lower() in ["tele mod", "tele vip"]:
            coordinates = vip_loc.get("mod" if message.lower() == "tele mod" else "vip")
            if coordinates and ((message.lower() == "tele mod" and (await self.highrise.get_room_privilege(user.id)).moderator) 
            or user.username in ownerz 
            or (message.lower() == "tele vip" and user.username in vip_users)):
                await self.highrise.teleport(user.id, Position(*coordinates))
        
        if message.lower().lstrip() in locations:
            try:
                location = locations[message.lower().lstrip()]
                x, y, z = map(float, location.split(","))
                await self.highrise.teleport(user.id, Position(x, y, z))
            except ValueError:
                print(f"Error: Invalid coordinates for location '{message}'")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")
    
        if message.lower().lstrip().startswith("tele ") and user.username in ownerz: 
            if "@" in message:
                try: 
                    await self.teleporter(message)
                except:
                    pass
    
    async def handle_tip_command(self, user, message):
        try:
            parts = message.split()
            if len(parts) < 3:
                await self.highrise.chat("Usage: /tip @user 100g OR /tip 5 100g")
                return

            room_users = (await self.highrise.get_room_users()).content

            # Extract only valid users (exclude sender, owners, and bot)
            users_only = [
                u for u, _ in room_users
                if u.id != user.id and u.username.lower() not in ownerz and u.id != self.bot_id
            ]

            if parts[1].startswith("@"):
                username = parts[1][1:]
                amount = int(parts[2].rstrip('g'))
                target_user = next((u for u in users_only if u.username == username), None)
                if username in ownerz:
                    await self.highrise.send_whisper(user.id,f"{username} is an owner. Cant tip owners" )
                    return
                if not target_user:
                    await self.highrise.chat(f"User @{username} not found")
                    return
                await self.process_tips(user.id, amount, [target_user])
            else:
                num_users = int(parts[1])
                amount = int(parts[2].rstrip('g'))
                random.shuffle(users_only)
                selected_users = users_only[:num_users]
                if not selected_users:
                    await self.highrise.chat("No eligible users to tip.")
                    return
                await self.process_tips(user.id, amount, selected_users)

        except Exception as e:
            await self.highrise.chat("Invalid command. Usage: /tip @user 100g OR /tip 5 100g")
            print(f"Tip command error: {e}")

    async def handle_bulk_tip(self, user, message):
        try:
            amount = int(message.split(" ")[1])
            room_users = (await self.highrise.get_room_users()).content
            await self.process_tips(user.username, amount, room_users, is_bulk=True)
        except Exception as e:
            await self.highrise.chat("Usage: /tipall <amount>")
            await self.highrise.chat(e)
            print(e)

    async def process_tips(self, sender_id, amount, recipients, is_bulk=False):
        tip_bars = []
        remaining = amount
        for bar_value in sorted(self.BARS_DICTIONARY.keys(), reverse=True):
            while remaining >= bar_value:
                tip_bars.append(self.BARS_DICTIONARY[bar_value])
                remaining -= bar_value
        if remaining != 0:
            await self.highrise.chat("Invalid amount. Use 1,5,10,50,100,500,1k,5k,10k.")
            return

        fee = self.FEES_DICTIONARY.get(amount, 1)
        total_cost = (amount + fee) * len(recipients)
        bot_balance = (await self.highrise.get_wallet()).content[0].amount

        if bot_balance < total_cost:
            await self.highrise.chat(f"Not enough gold. Need {total_cost}g.")
            return
        count = 0
        for recipient in recipients:
            name = recipient[0].username if is_bulk else recipient.username
            if name in ownerz: continue
            user_id = recipient[0].id if is_bulk else recipient.id
            await self.highrise.tip_user(user_id, ",".join(tip_bars))
            count += 1
            if user_id not in ids:
                ids.append(user_id)
        if is_bulk:
            await self.highrise.chat(f"Tipped {count} users {amount}g each!")
        else:
            recipient_name = recipients[0].username if len(recipients) == 1 else f"{len(recipients)} users"
            await self.highrise.chat(f"Tipped {recipient_name} {amount}g.")
    
    async def handle_freeze(self, message):
        try:
            target = message.split()[1]
            if not target.startswith("@"):
                return

            username = target[1:]
            room_users = (await self.highrise.get_room_users()).content

            for room_user, pos in room_users:
                if room_user.username.lower() == username.lower():
                    self.freeze[room_user.username.lower()] = pos
                    await self.highrise.chat(f"Froze @{room_user.username}")
                    return

            await self.highrise.chat(f"User @{username} not found")

        except Exception as e:
            print(f"Freeze error: {e}")

    async def handle_unfreeze(self, message):
        try:
            target = message.split()[1]
            if not target.startswith("@"):
                return

            username = target[1:]
            if username.lower() in self.freeze:
                del self.freeze[username.lower()]
                await self.highrise.chat(f"Unfroze @{username}")
            else:
                await self.highrise.chat(f"@{username} was not frozen")

        except Exception as e:
            print(f"Unfreeze error: {e}")
    
    async def handle_nickname(self, message):
        try:
            parts = message.split(maxsplit=2)  # Split into 3 parts max
            if len(parts) < 3:
                await self.highrise.chat("Usage: /nickname @username NewNickname")
                return

            target = parts[1]
            if not target.startswith("@"):
                return

            username = target[1:]
            new_nick = parts[2].strip()

            nicknames[username.lower()] = new_nick
            await self.highrise.chat(f"Nickname set: @{username} → {new_nick}")

        except Exception as e:
            print(f"Nickname error: {e}")
            await self.highrise.chat("Error setting nickname")
    
    async def handle_quiet(self):
        if self.quiet:
            return
            
        self.quiet = True
        room_users = (await self.highrise.get_room_users()).content
        
        for room_user, _ in room_users:
            username = room_user.username.lower()
            
            # Skip muting these users
            if (username in [o.lower() for o in ownerz] or 
                username == self.username.lower()):
                continue
                
            # Check privileges
            try:
                priv = await self.highrise.get_room_privilege(room_user.id)
                if priv in ["moderator", "designer"]:
                    continue
            except:
                continue
                
            # Mute for 1 hour
            await self.highrise.moderate_room(room_user.id, "mute", 3600)
        
        await self.highrise.chat("🔇 Quiet mode activated for 1 hour")

    async def handle_talk(self):
        if not self.quiet:
            return
            
        room_users = (await self.highrise.get_room_users()).content
        
        for room_user, _ in room_users:
            username = room_user.username.lower()
            
            # Skip unmuting these users (they were never muted)
            if (username in [o.lower() for o in ownerz] or 
                username == self.username.lower()):
                continue
                
            # Check privileges
            try:
                priv = await self.highrise.get_room_privilege(room_user.id)
                if priv in ["moderator", "designer"]:
                    continue
            except:
                continue
                
            # Unmute by setting 1-second mute
            await self.highrise.moderate_room(room_user.id, "mute", 1)
        
        self.quiet = False
        await self.highrise.chat("🔊 Quiet mode deactivated")

    async def teleporter(self, message: str) -> None:
        try:
            parts = message.split(" ")
            if len(parts) != 3:
                raise ValueError("Incorrect format")
            command, username, destination = parts
        except ValueError:
            return

        username = username.replace("@", "")
        room_users = (await self.highrise.get_room_users()).content
        user_id = None
        for user in room_users:
            if user[0].username.lower() == username.lower():
                user_id = user[0].id
                break

        if user_id is None:
            await self.highrise.chat("User not found")
            return

        coordinate = vip_loc.get(destination) or locations.get(destination) or destination

        try:
            if isinstance(coordinate, str):
                x, y, z = map(float, coordinate.split(","))
            elif isinstance(coordinate, list) or isinstance(coordinate, tuple):
                x, y, z = map(float, coordinate)
            else:
                raise ValueError
        except ValueError:
            await self.highrise.chat("Coordinate not found or incorrect format, please use x,y,z")
            return

        await self.highrise.teleport(user_id=user_id, dest=Position(x, y, z))
    
    async def emote(self, user: User, message: str) -> None:
        try:
            emote_name, target = message.split(" ")
            target = target.lstrip("@")
        except ValueError:
            return

        emote_id, emote_duration = self.get_emote_info(emote_name)
        if not emote_id:
            return

        if target.lower() == "all" and user.username in ownerz:
            room_users = (await self.highrise.get_room_users()).content
            for room_user, _ in room_users:
                if room_user.id in [user.id for user, _ in room_users]:
                    try:
                        await self.highrise.send_emote(emote_id, room_user.id)
                    except Exception as e:
                        print(e)
        else:
            user_info = await self.webapi.get_users(username=target)
            if user_info.total == 0:

                return

            user_id = user_info.users[0].user_id
            try:
                await self.highrise.send_emote(emote_id, user_id)
            except:
                pass

    async def on_user_join(self, user: User, pos: Position) -> None:
        await asyncio.sleep(1.5)
        if user.id in self.last_positions:
            await asyncio.sleep(0.5)
            await self.highrise.teleport(user.id, self.last_positions[user.id])
        try:
            if user.id in self.users_in_square:
                self.users_in_square.remove(user.id)
        except:
            pass
        if user.username not in data["points"]:
            data["points"][user.username] = {"join": None, "total": 0.0}
        if data["points"][user.username]["join"] is None:
            data["points"][user.username]["join"] = time.time()

        if user.username == "thisuserisded":
            await asyncio.sleep(1)
            await self.highrise.chat("\n █░█ ▄▀█ █ █░░\n █▀█ █▀█ █ █▄▄")
            await self.highrise.send_emote("emote-salute")
            await self.highrise.chat(f"MASTER!!! {user.username}\n🗽🗽🗽🗽🗽🗽🗽🗽🗽🗽🗽🗽🗽")
            return

        if user.username != "thisuserisded":
            wm = [
            'welcome to the room!',
            'welcome cutie!',
            'thanks for joining us🥹',
            'welcome to our room and invite your friends.',
            'glad to see you here.',
            'welcome to my heart.',
            ]
            rwm = random.choice(wm)
        try:
            name = nicknames.get(user.username.lower(), user.username)
            await self.highrise.chat(f"\n👤 {name} joined the chat. ")
            await self.highrise.send_whisper(user.id, f"Hey {name}\n{rwm}")
            await asyncio.sleep(1.5)
            await self.highrise.react("heart", user.id)
            await self.highrise.send_emote("emote-curtsy", user.id)
            await asyncio.sleep(1)
            for item in welcome:
                await self.highrise.send_whisper(user.id, f"\n{item}")
                await asyncio.sleep(1.5)
        except:
            pass
          
    async def get_username(self, user_id):
        user_info = await self.webapi.get_user(user_id)
        return user_info.user.username

    async def on_moderate(
        self,
        moderator_id: str,
        target_user_id: str,
        moderation_type: Literal["kick", "mute", "unmute", "ban", "unban"],
        duration: int | None,
    ) -> None:
        pass
            
    async def on_tip(self, sender: User, receiver: User, tip: CurrencyItem | Item) -> None:
        try:
            if tip.amount == 1000 and receiver.username == self.username:
                current_date = datetime.now().strftime("%d/%m/%Y")
                day = datetime.now().strftime("%d")
                if sender.username in vip_users:
                    await self.highrise.send_whisper(user.id, "Your vip period has been extended. Thanks for tipping gold. <3")
                    for user_id in msg:
                        message_id = f"1_on_1:{user_id}:{self.bot_id}"
                        try:
                            await self.highrise.send_message(message_id, f"User @{sender.username} tipped 1000g on {current_date}.")
                            await asyncio.sleep(1)
                        except Exception as e:
                            print("Error in sending msg abt tip:", e)

                else:
                    vip_users.append(sender.username)
                    await self.highrise.send_whisper(user.id, "Youre added to vip users. If you face any error pm owner. Enjoy <3")
                    await self.highrise.send_whisper(user.id, f"\n*NOTE*: your vip is started from {current_date}, Make sure to renew your vip before {get_ordinal(day)} of next month.")
                    for user_id in msg:
                        message_id = f"1_on_1:{user_id}:{self.bot_id}"
                        try:
                            await self.highrise.send_message(message_id, f"User @{sender.username} got their vip on {current_date}.")
                            await asyncio.sleep(1)
                        except Exception as e:
                            print("Error in sending msg abt tip:", e)
            else:
                pass
        except Exception as e:
            print(e)
            await self.highrise.send_whisper(sender.id, f"Error occurred: {e}. ")

    def get_emote_info(self, emote_name):
        return emote_dict.get(emote_name.lower(), (None, None))

    def is_valid_emote(self, emote_name):
        return emote_name in emote_dict